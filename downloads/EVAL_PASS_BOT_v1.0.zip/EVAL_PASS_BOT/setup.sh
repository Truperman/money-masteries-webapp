#!/bin/bash
# One-time setup. Run with:  bash setup.sh
cd "$(dirname "$0")"

echo
echo "================================================"
echo "  EVAL PASS BOT - Setup"
echo "================================================"
echo

# --- Python check -------------------------------------------------
if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: Python 3 is not installed."
  echo "Install it from https://www.python.org/downloads/ then run this again."
  exit 1
fi

PYV=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
PYOK=$(python3 -c 'import sys; print(1 if sys.version_info >= (3,9) else 0)')
if [ "$PYOK" != "1" ]; then
  echo "ERROR: Python $PYV found, but 3.9 or newer is required."
  exit 1
fi
echo "Python $PYV found."
echo

# --- Environment --------------------------------------------------
echo "Creating a private Python environment (this takes a minute)..."
python3 -m venv .venv || { echo "Could not create environment."; exit 1; }
.venv/bin/python -m pip install --quiet --upgrade pip
.venv/bin/python -m pip install --quiet -r requirements.txt || {
  echo "Package install failed. Check your internet connection."; exit 1; }
echo "Packages installed."
echo

# --- Self test ----------------------------------------------------
echo "Running self-tests..."
.venv/bin/python tests/test_rules.py | tail -1
.venv/bin/python tests/test_orderflow.py | tail -1
echo

# --- Credentials --------------------------------------------------
if [ -f .env ] && ! grep -q "PUT_YOUR" .env 2>/dev/null; then
  echo "Credentials already saved. Leaving them alone."
  echo "(Delete the .env file and run setup again to change them.)"
else
  echo "================================================"
  echo "  Your Topstep credentials"
  echo "================================================"
  echo
  echo "Get these from TopstepX -> Settings -> API tab."
  echo "They are saved only on this computer, in a file called .env"
  echo

  printf "TopstepX username: "
  read -r TS_USER
  printf "API key: "
  read -r TS_KEY

  if [ -z "$TS_USER" ] || [ -z "$TS_KEY" ]; then
    echo
    echo "Both are required. Run 'bash setup.sh' again when you have them."
    exit 1
  fi

  cat > .env <<ENVEOF
TOPSTEP_USERNAME=$TS_USER
TOPSTEP_API_KEY=$TS_KEY
ENVEOF
  chmod 600 .env
  echo
  echo "Saved."
fi

echo
echo "================================================"
echo "  Setup complete"
echo "================================================"
echo
echo "To start the bot in SAFE MODE (no real orders):"
echo
echo "    bash go.sh"
echo
