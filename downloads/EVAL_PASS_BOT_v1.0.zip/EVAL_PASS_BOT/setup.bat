@echo off
REM One-time setup. Double-click this file.
cd /d "%~dp0"
echo.
echo ================================================
echo   Topstep Trading Bot - Setup
echo ================================================
echo.

python --version >/dev/null 2>&1
if errorlevel 1 (
  echo ERROR: Python is not installed, or was not added to PATH.
  echo Install it from https://www.python.org/downloads/
  echo During install, TICK the box "Add Python to PATH".
  pause
  exit /b 1
)

echo Creating a private Python environment...
python -m venv .venv
if errorlevel 1 ( echo Could not create environment. & pause & exit /b 1 )

echo Installing packages, please wait...
.venv\Scripts\python -m pip install --quiet --upgrade pip
.venv\Scripts\python -m pip install --quiet -r requirements.txt
if errorlevel 1 ( echo Package install failed. Check your internet. & pause & exit /b 1 )

echo Running self-tests...
.venv\Scripts\python tests\test_rules.py
.venv\Scripts\python tests\test_orderflow.py
echo.

if exist .env (
  findstr /C:"PUT_YOUR" .env >/dev/null 2>&1
  if errorlevel 1 (
    echo Credentials already saved. Leaving them alone.
    goto done
  )
)

echo ================================================
echo   Your Topstep credentials
echo ================================================
echo.
echo Get these from TopstepX - Settings - API tab.
echo They are saved only on this computer.
echo.
set /p TS_USER="TopstepX username: "
set /p TS_KEY="API key: "

if "%TS_USER%"=="" ( echo Username is required. & pause & exit /b 1 )
if "%TS_KEY%"=="" ( echo API key is required. & pause & exit /b 1 )

>.env echo TOPSTEP_USERNAME=%TS_USER%
>>.env echo TOPSTEP_API_KEY=%TS_KEY%
echo.
echo Saved.

:done
echo.
echo ================================================
echo   Setup complete
echo ================================================
echo.
echo To start the bot in SAFE MODE, double-click:  go.bat
echo.
pause
