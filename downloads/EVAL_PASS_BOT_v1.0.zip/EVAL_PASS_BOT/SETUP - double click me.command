#!/bin/bash
# macOS runs .command files in Terminal when double-clicked.
cd "$(dirname "$0")"

# Bring the Terminal window forward and give it a clean start.
printf '\033[8;40;80t'
clear

cat <<'BANNER'
================================================================
   EVAL PASS BOT  -  FIRST TIME SETUP
================================================================

  This will:
    1. Set up the software it needs
    2. Ask you for your Topstep username and API key
    3. Save them on this computer only

  You need your API key first. Get it from:
    TopstepX  ->  Settings (gear)  ->  API tab

  If you do not have it yet, close this window and come back.

================================================================

BANNER

printf "Press RETURN to begin, or close this window to cancel: "
read -r _

bash setup.sh

echo
echo "================================================================"
printf "Press RETURN to close this window: "
read -r _
