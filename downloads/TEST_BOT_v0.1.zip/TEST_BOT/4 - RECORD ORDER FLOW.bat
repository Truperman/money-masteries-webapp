@echo off
cd /d "%~dp0"
echo TEST BOT - STEP 4 - RECORD ORDER FLOW
echo.
if not exist .venv ( echo Run file number 1 first. & pause & exit /b 1 )
.venv\Scripts\python record_flow.py --symbol MES --out data\flow
echo.
pause
