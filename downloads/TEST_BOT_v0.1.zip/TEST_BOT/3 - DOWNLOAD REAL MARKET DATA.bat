@echo off
cd /d "%~dp0"
echo TEST BOT - STEP 3 - GET REAL DATA
echo.
if not exist .venv ( echo Run file number 1 first. & pause & exit /b 1 )
.venv\Scripts\python fetch_data.py --days 365 --out mes_1min.csv
echo.
pause
