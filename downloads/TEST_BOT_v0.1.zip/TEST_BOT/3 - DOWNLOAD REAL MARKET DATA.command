#!/bin/bash
cd "$(dirname "$0")"
clear
cat <<'BANNER'
================================================================
   TEST BOT  -  STEP 3  -  GET REAL DATA
================================================================
  Downloads one year of real MES price history from Topstep.

  Needs your API key (step 1). After this finishes, run step 2
  again - it will automatically use the real data instead of
  test data, and THAT result actually means something.
================================================================

BANNER
bash getdata.sh
echo
printf "Press RETURN to close this window: "
read -r _
