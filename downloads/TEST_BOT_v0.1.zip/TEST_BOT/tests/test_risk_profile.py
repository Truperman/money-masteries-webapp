"""
Tests for the volume profile (location filter) and the risk layer.

The risk tests matter most. A volume profile that is slightly wrong costs
you a mediocre trade; a risk layer that is wrong costs you the account.
"""

import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from flowbot.profile import (  # noqa: E402
    SessionContext,
    build_profile,
    build_profile_from_trades,
)
from flowbot.risk import (  # noqa: E402
    PERSONAL,
    PROP_50K,
    PROP_100K,
    Halt,
    RiskConfig,
    RiskState,
)


def make_bars(prices_volumes):
    rows = []
    for i, (p, v) in enumerate(prices_volumes):
        rows.append({
            "open": p, "high": p + 0.5, "low": p - 0.5, "close": p, "volume": v,
        })
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------
# Volume profile
# ----------------------------------------------------------------------

def test_poc_is_the_most_traded_price():
    """Pile volume at 5010; the POC must land there."""
    bars = make_bars([(5000, 10), (5005, 20), (5010, 500), (5015, 20), (5020, 10)])
    p = build_profile(bars, row_size_ticks=4)
    assert p is not None
    assert abs(p.poc - 5010) <= 1.5, f"POC was {p.poc}"


def test_value_area_contains_target_share():
    bars = make_bars([(5000 + i, 100 + (50 if 8 <= i <= 12 else 0)) for i in range(21)])
    p = build_profile(bars, row_size_ticks=4, value_area_pct=0.70)
    inside = p.volumes[(p.prices >= p.val) & (p.prices <= p.vah)].sum()
    share = inside / p.total_volume
    assert 0.65 <= share <= 0.90, f"value area captured {share:.0%}"


def test_value_area_brackets_the_poc():
    bars = make_bars([(5000 + i, 100 + (400 if i == 10 else 0)) for i in range(21)])
    p = build_profile(bars)
    assert p.val <= p.poc <= p.vah


def test_position_labels():
    bars = make_bars([(5000 + i, 100 + (400 if i == 10 else 0)) for i in range(21)])
    p = build_profile(bars)
    assert p.position(p.vah + 10) == "above_value"
    assert p.position(p.val - 10) == "below_value"
    assert p.position(p.poc) == "at_poc"
    assert p.is_inside_value((p.val + p.vah) / 2)


def test_lvn_found_in_a_volume_gap():
    """A trough between two peaks must be detected as a low volume node."""
    vols = [500, 400, 20, 15, 25, 400, 500]
    bars = make_bars([(5000 + i * 2, v) for i, v in enumerate(vols)])
    p = build_profile(bars, row_size_ticks=4, lvn_threshold=0.30)
    assert len(p.lvns) > 0, "no LVN found in an obvious gap"
    assert any(5003 <= x <= 5010 for x in p.lvns), f"LVNs at {p.lvns}"


def test_nearest_level_gates_on_tolerance():
    bars = make_bars([(5000 + i, 100 + (400 if i == 10 else 0)) for i in range(21)])
    p = build_profile(bars)
    assert p.nearest_level(p.poc + 0.25, tolerance=2.0) is not None
    assert p.nearest_level(p.poc + 500, tolerance=2.0) is None, \
        "far from every level must return None — this is the location gate"


def test_profile_from_trades_beats_uniform_assumption():
    """Trade-based profile puts volume exactly where it traded."""
    trades = pd.DataFrame({
        "price": [5000.0] * 5 + [5010.0] * 100 + [5020.0] * 5,
        "size": [1] * 110,
    })
    p = build_profile_from_trades(trades, row_size_ticks=4)
    assert p is not None
    assert abs(p.poc - 5010) <= 1.0, f"POC was {p.poc}"


def test_empty_and_degenerate_input():
    assert build_profile(pd.DataFrame()) is None
    assert build_profile_from_trades(pd.DataFrame()) is None
    flat = make_bars([(5000, 0), (5000, 0)])
    assert build_profile(flat) is None, "zero volume must not divide by zero"


def test_session_context_balanced_vs_imbalanced():
    bars = make_bars([(5000 + i, 100 + (400 if i == 10 else 0)) for i in range(21)])
    p = build_profile(bars)

    inside = SessionContext(p, vwap=p.poc, cvd=100, opening_price=p.poc,
                            current_price=p.poc)
    assert inside.is_balanced

    outside = SessionContext(p, vwap=p.poc, cvd=100, opening_price=p.poc,
                             current_price=p.vah + 20)
    assert not outside.is_balanced


def test_bias_requires_vwap_and_cvd_to_agree():
    bars = make_bars([(5000 + i, 100) for i in range(21)])
    p = build_profile(bars)
    assert SessionContext(p, 5010, 500, 5010, 5015).bias == 1
    assert SessionContext(p, 5010, -500, 5010, 5005).bias == -1
    assert SessionContext(p, 5010, -500, 5010, 5015).bias == 0, \
        "price up but selling pressure = no bias, not a long"


# ----------------------------------------------------------------------
# Risk layer — the 2% rule
# ----------------------------------------------------------------------

def test_two_percent_hard_cap_matches_the_spec():
    assert PROP_50K.hard_daily_loss == 1_000.0, "2% of $50K"
    assert PROP_100K.hard_daily_loss == 2_000.0, "2% of $100K"


def test_hard_cap_halts_trading():
    s = RiskState(PROP_50K)
    s.start_day("d1")
    now = datetime(2026, 3, 2, 10, 0)
    s.day_pnl = -1_000.0
    assert s.check(now) is Halt.HARD_DAILY_LOSS


def test_soft_stop_fires_first():
    """A normal bad day should end at the soft stop, far from the wall."""
    s = RiskState(PROP_50K)
    s.start_day("d1")
    now = datetime(2026, 3, 2, 10, 0)
    s.day_pnl = -260.0                      # past $250 soft, far from $1,000
    assert s.check(now) is Halt.SOFT_DAILY_LOSS


def test_consecutive_losses_trigger_timeout():
    s = RiskState(PROP_50K)
    s.start_day("d1")
    t = datetime(2026, 3, 2, 10, 0)
    for i in range(3):
        s.on_trade_closed(-50, t + timedelta(minutes=i))
    assert s.check(t + timedelta(minutes=5)) is Halt.LOSS_STREAK

    # The 30 minutes runs from the THIRD loss (t+2), not the first, so the
    # gate is still shut at t+31 and opens at t+32.
    assert s.check(t + timedelta(minutes=31)) is Halt.LOSS_STREAK
    assert s.check(t + timedelta(minutes=33)) is Halt.NONE


def test_a_win_resets_the_loss_streak():
    s = RiskState(PROP_50K)
    s.start_day("d1")
    t = datetime(2026, 3, 2, 10, 0)
    s.on_trade_closed(-50, t)
    s.on_trade_closed(-50, t)
    s.on_trade_closed(+120, t)
    assert s.consecutive_losses == 0
    assert s.check(t) is Halt.NONE


def test_grade_scales_risk():
    s = RiskState(PROP_50K)
    s.start_day("d1")
    a = s.risk_for_trade("A")
    b = s.risk_for_trade("B")
    c = s.risk_for_trade("C")
    assert a == 125.0, "0.25% of $50K"
    assert b == a * 0.5
    assert c == a * 0.25


def test_profit_protection_cuts_size():
    s = RiskState(PROP_50K)
    s.start_day("d1")
    full = s.risk_for_trade("A")
    s.day_pnl = PROP_50K.base_risk * 2      # +2R banked
    assert s.risk_for_trade("A") == full * 0.5


def test_losing_days_cut_size():
    s = RiskState(PROP_50K)
    s.start_day("d1")
    full = s.risk_for_trade("A")
    s.losing_days = 2
    assert s.risk_for_trade("A") == full * 0.5


def test_reductions_compound():
    """B grade + two losing days + profit banked should stack, not override."""
    s = RiskState(PROP_50K)
    s.start_day("d1")
    base = PROP_50K.base_risk
    s.day_pnl = base * 2
    s.losing_days = 2
    expected = base * 0.5 * 0.5 * 0.5
    assert abs(s.risk_for_trade("B") - expected) < 1e-9


def test_risk_never_exceeds_remaining_daily_room():
    s = RiskState(PROP_50K)
    s.start_day("d1")
    s.day_pnl = -200.0                      # $50 left of the $250 soft budget
    assert s.risk_for_trade("A") <= 50.0


def test_buffer_clamp_shrinks_size_near_the_floor():
    s = RiskState(PROP_50K)
    s.start_day("d1")
    s.equity_high = 50_000.0
    full = s.risk_for_trade("A", equity=50_000.0)
    near = s.risk_for_trade("A", equity=48_300.0)   # $300 above the floor
    assert near < full
    assert near <= 300 * PROP_50K.max_buffer_fraction_per_trade + 1e-9


def test_drawdown_floor_halts_before_breach():
    s = RiskState(PROP_50K)
    s.start_day("d1")
    s.equity_high = 50_000.0
    now = datetime(2026, 3, 2, 10, 0)
    assert s.check(now, equity=48_050.0) is Halt.DRAWDOWN_FLOOR


def test_personal_account_has_no_buffer_clamp():
    s = RiskState(PERSONAL)
    s.start_day("d1")
    now = datetime(2026, 3, 2, 10, 0)
    # Deep drawdown that would trip the prop floor is fine here.
    assert s.check(now, equity=40_000.0) is Halt.NONE
    assert s.risk_for_trade("A", equity=40_000.0) > 0


def test_config_validation_flags_the_buffer_danger():
    """The 2% rule on a prop account should produce an explicit warning."""
    warnings = PROP_50K.validate()
    assert any("drawdown buffer" in w for w in warnings), warnings
    joined = " ".join(warnings)
    assert "50%" in joined or "2.0 such days" in joined


def test_validation_catches_inverted_stops():
    bad = RiskConfig(account_size=50_000, hard_daily_loss_pct=0.005,
                     soft_daily_loss_pct=0.02)
    assert any("never fire" in w for w in bad.validate())


def test_new_day_resets_state():
    s = RiskState(PROP_50K)
    s.start_day("d1")
    t = datetime(2026, 3, 2, 10, 0)
    s.on_trade_closed(-300, t)
    assert s.check(t) is not Halt.NONE
    s.start_day("d2")
    assert s.day_pnl == 0.0
    assert s.check(t) is Halt.NONE
    assert s.losing_days == 1, "the losing day was recorded"


if __name__ == "__main__":
    import traceback

    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    for t in tests:
        try:
            t()
            print(f"  PASS  {t.__name__}")
        except Exception:
            failed += 1
            print(f"  FAIL  {t.__name__}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
