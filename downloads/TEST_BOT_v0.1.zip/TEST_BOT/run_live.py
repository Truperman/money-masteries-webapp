#!/usr/bin/env python3
"""
TEST BOT — live session runner.

SAFE MODE IS THE DEFAULT. Real orders require --live AND a typed
confirmation. There is no config setting that arms it silently.

    python3 run_live.py              # safe mode, no orders sent
    python3 run_live.py --live       # real orders, prompts first

Every minute it pulls fresh bars, rebuilds the volume profile, runs the
three filters, and routes any setup through the risk layer. The risk layer
can refuse, and its refusal is final.
"""

from __future__ import annotations

import argparse
import logging
import os
import signal
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd

from flowbot.risk import PRESETS, Halt, RiskState
from flowbot.strategy import StrategyConfig, TestBotStrategy

log = logging.getLogger("test_bot")
_running = True

API_BASE = os.environ.get("PROJECTX_BASE_URL", "https://api.topstepx.com")
TICK_SIZE = 0.25
TICK_VALUE = 1.25


def _stop(signum, frame):
    global _running
    _running = False
    print("\nstopping — flattening any open position...")


def load_env(path: Path = Path(".env")) -> None:
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, _, v = line.partition("=")
            os.environ.setdefault(k.strip(), v.strip().strip("'\""))


def friendly_error(exc: Exception) -> None:
    text = str(exc).lower()
    print("\n" + "=" * 64)
    if any(w in text for w in ("proxy", "connection", "timed out",
                              "resolution", "max retries")):
        print("  Could not reach Topstep's servers.")
        print("=" * 64)
        print("\n  - Are you connected to the internet?")
        print("  - Are you on a VPN? Turn it off. Topstep blocks VPNs and")
        print("    their rules prohibit trading through one.")
    elif any(w in text for w in ("auth", "401", "403", "unauthorized")):
        print("  Topstep rejected your login.")
        print("=" * 64)
        print("\n  - Is TOPSTEP_USERNAME your TopstepX username (not email)?")
        print("  - Was the API key copied completely, no spaces?")
        print("  - Is your API subscription active?")
        print("      TopstepX -> Settings -> API tab")
        print("\n  To re-enter them: delete the .env file, run setup again.")
    else:
        print("  Could not start.")
        print("=" * 64)
        print(f"\n  {exc}")
    print("\n" + "=" * 64 + "\n")


class Client:
    """Minimal ProjectX client."""

    def __init__(self, username: str, api_key: str):
        self.username = username
        self.api_key = api_key
        self._token = None
        self._token_ts = 0.0
        self.account_id = None
        self.contract_id = None

    def token(self) -> str:
        import requests
        if self._token and (time.time() - self._token_ts) < 3000:
            return self._token
        r = requests.post(f"{API_BASE}/api/Auth/loginKey",
                          json={"userName": self.username, "apiKey": self.api_key},
                          timeout=20)
        r.raise_for_status()
        d = r.json()
        if not d.get("success"):
            raise RuntimeError(f"auth failed: {d.get('errorMessage')}")
        self._token, self._token_ts = d["token"], time.time()
        return self._token

    def headers(self) -> dict:
        return {"Authorization": f"Bearer {self.token()}",
                "Content-Type": "application/json"}

    def accounts(self) -> list:
        import requests
        r = requests.post(f"{API_BASE}/api/Account/search",
                          json={"onlyActiveAccounts": True},
                          headers=self.headers(), timeout=20)
        r.raise_for_status()
        return r.json().get("accounts", [])

    def find_contract(self, symbol: str) -> dict:
        import requests
        r = requests.post(f"{API_BASE}/api/Contract/search",
                          json={"searchText": symbol, "live": False},
                          headers=self.headers(), timeout=20)
        r.raise_for_status()
        cs = r.json().get("contracts", [])
        if not cs:
            raise RuntimeError(f"no contract for {symbol}")
        return ([c for c in cs if c.get("activeContract")] or cs)[0]

    def bars(self, minutes: int = 400) -> pd.DataFrame:
        import requests
        from zoneinfo import ZoneInfo
        end = datetime.now(timezone.utc)
        start = end - timedelta(minutes=minutes + 120)
        r = requests.post(
            f"{API_BASE}/api/History/retrieveBars",
            json={"contractId": self.contract_id, "live": False,
                  "startTime": start.strftime("%Y-%m-%dT%H:%M:%SZ"),
                  "endTime": end.strftime("%Y-%m-%dT%H:%M:%SZ"),
                  "unit": 2, "unitNumber": 1, "limit": 20000,
                  "includePartialBar": False},
            headers=self.headers(), timeout=45)
        r.raise_for_status()
        d = r.json()
        if not d.get("success"):
            raise RuntimeError(f"retrieveBars: {d}")

        central = ZoneInfo("America/Chicago")
        rows = []
        for b in d.get("bars", []):
            ts = datetime.fromisoformat(b["t"].replace("Z", "+00:00"))
            rows.append({"timestamp": ts.astimezone(central).replace(tzinfo=None),
                         "open": b["o"], "high": b["h"], "low": b["l"],
                         "close": b["c"], "volume": b["v"]})
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows).set_index("timestamp").sort_index()
        df["session"] = [t.date() if t.time() < datetime.min.time().replace(hour=17)
                         else (t + timedelta(days=1)).date() for t in df.index]
        return df

    def place(self, side: int, size: int, stop_ticks: int, target_ticks: int,
              dry_run: bool) -> dict:
        import requests
        payload = {
            "accountId": int(self.account_id),
            "contractId": self.contract_id,
            "type": 2, "side": side, "size": int(size),
            "stopLossBracket": {"ticks": int(stop_ticks), "type": 4},
            "takeProfitBracket": {"ticks": int(target_ticks), "type": 1},
        }
        if dry_run:
            log.info("SAFE MODE — would send: %s", payload)
            return {"success": True, "dryRun": True}
        r = requests.post(f"{API_BASE}/api/Order/place", json=payload,
                          headers=self.headers(), timeout=20)
        r.raise_for_status()
        return r.json()

    def flatten(self, dry_run: bool) -> dict:
        import requests
        if dry_run:
            return {"success": True, "dryRun": True}
        r = requests.post(f"{API_BASE}/api/Position/closeContract",
                          json={"accountId": int(self.account_id),
                                "contractId": self.contract_id},
                          headers=self.headers(), timeout=20)
        r.raise_for_status()
        return r.json()


def confirm_live() -> bool:
    print("\n" + "=" * 68)
    print("  LIVE MODE — real orders will be sent to your Topstep account.")
    print("  Orders placed via the API are final. No review, no reversal.")
    print("")
    print("  TEST BOT has NOT been validated on real market data.")
    print("  Its edge is unknown. You are risking a paid evaluation on it.")
    print("=" * 68)
    ans = input('\nType exactly: I understand this trades real money\n> ')
    return ans.strip() == "I understand this trades real money"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--preset", default="prop_50k", choices=list(PRESETS.keys()))
    ap.add_argument("--symbol", default="MES")
    ap.add_argument("--live", action="store_true")
    ap.add_argument("--poll", type=float, default=20.0)
    ap.add_argument("--log", default="logs/test_bot.log")
    args = ap.parse_args()

    signal.signal(signal.SIGINT, _stop)
    Path(args.log).parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-7s %(message)s",
        handlers=[logging.StreamHandler(sys.stdout),
                  logging.FileHandler(args.log)])
    load_env()

    user = os.environ.get("TOPSTEP_USERNAME", "")
    key = os.environ.get("TOPSTEP_API_KEY", "")
    if not user or not key:
        raise SystemExit(
            "No credentials found.\n"
            "Run the setup first so it can ask for your username and API key.")

    dry_run = True
    if args.live:
        dry_run = not confirm_live()
        if dry_run:
            print("Not confirmed — staying in SAFE MODE.")

    client = Client(user, key)
    try:
        client.token()
        accts = client.accounts()
        if not accts:
            raise SystemExit("No active accounts. Is your Combine active?")
        client.account_id = accts[0]["id"]
        contract = client.find_contract(args.symbol)
        client.contract_id = contract["id"]
    except SystemExit:
        raise
    except Exception as exc:
        friendly_error(exc)
        raise SystemExit(1)

    risk_cfg = PRESETS[args.preset]
    risk = RiskState(risk_cfg)
    strat = TestBotStrategy(StrategyConfig())
    equity = float(accts[0].get("balance") or risk_cfg.account_size)

    log.info("=" * 60)
    log.info("%s", "SAFE MODE — no orders will be sent" if dry_run else "*** LIVE ***")
    log.info("account %s   balance %.2f", client.account_id, equity)
    log.info("contract %s (%s)", client.contract_id, contract.get("description"))
    log.info("preset %s   2%% cap $%.0f   soft stop $%.0f   per trade $%.0f",
             args.preset, risk_cfg.hard_daily_loss,
             risk_cfg.soft_daily_loss, risk_cfg.base_risk)
    for w in risk_cfg.validate():
        log.warning("! %s", w)
    log.info("=" * 60)

    last_bar = None
    session = None

    while _running:
        try:
            df = client.bars()
            if df.empty:
                time.sleep(args.poll)
                continue

            bar = df.iloc[-1]
            ts = df.index[-1]

            if df["session"].iloc[-1] != session:
                session = df["session"].iloc[-1]
                strat.start_session(session)
                risk.start_day(session)
                log.info("--- session %s ---", session)

            if ts != last_bar:
                last_bar = ts
                now = datetime.now()
                halt = risk.check(now, equity=equity)

                if halt is not Halt.NONE:
                    log.info("standing down: %s | %s", halt.value, risk.snapshot())
                else:
                    setup = strat.on_bar(ts, bar, df)
                    if setup is None:
                        if strat.last_reasons:
                            log.debug("no trade: %s", "; ".join(strat.last_reasons))
                    else:
                        risk_dollars = risk.risk_for_trade(setup.grade, equity=equity)
                        stop_ticks = round(setup.risk_points / TICK_SIZE)
                        target_ticks = round(
                            abs(setup.target_price - setup.entry_price) / TICK_SIZE)
                        contracts = 0
                        if stop_ticks > 0 and risk_dollars > 0:
                            contracts = int(risk_dollars // (stop_ticks * TICK_VALUE))
                            contracts = max(min(contracts, 50), 0)

                        log.info(
                            "SETUP %s grade=%s %s @ %.2f | stop %d ticks | "
                            "target %d ticks | R:R %.1f | size %d | %s",
                            setup.kind, setup.grade,
                            "LONG" if setup.is_long else "SHORT",
                            setup.entry_price, stop_ticks, target_ticks,
                            setup.reward_risk, contracts,
                            "; ".join(setup.reasons))

                        if contracts > 0:
                            res = client.place(
                                0 if setup.is_long else 1, contracts,
                                stop_ticks, target_ticks, dry_run)
                            log.info("order: %s", res)
                        else:
                            log.info("size clamped to zero by the risk layer")

            time.sleep(args.poll)

        except KeyboardInterrupt:
            break
        except Exception as exc:
            log.exception("loop error: %s", exc)
            time.sleep(min(args.poll * 3, 60))

    try:
        client.flatten(dry_run)
        log.info("flattened")
    except Exception as exc:
        log.error("flatten FAILED — check your platform manually: %s", exc)

    log.info("session ended. %s", risk.snapshot())


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
