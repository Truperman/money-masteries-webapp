#!/bin/bash
cd "$(dirname "$0")"
clear
cat <<'BANNER'
================================================================
   TEST BOT  -  STEP 4  -  RECORD ORDER FLOW
================================================================
  Records live order flow while the market is open.

  Topstep does not sell historical order flow, so the only way
  to get it is to capture it yourself. Every day you do not run
  this is a day of data gone forever.

  Run it during market hours. Stop with CONTROL + C.
================================================================

BANNER
bash record.sh
echo
printf "Press RETURN to close this window: "
read -r _
