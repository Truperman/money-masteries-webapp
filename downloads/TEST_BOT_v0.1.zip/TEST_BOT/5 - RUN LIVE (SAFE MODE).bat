@echo off
cd /d "%~dp0"
echo TEST BOT - STEP 5 - SAFE MODE
echo.
if not exist .venv ( echo Run file number 1 first. & pause & exit /b 1 )
.venv\Scripts\python run_live.py
echo.
pause
