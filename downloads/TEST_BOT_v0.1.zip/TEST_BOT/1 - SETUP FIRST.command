#!/bin/bash
cd "$(dirname "$0")"
clear
cat <<'BANNER'
================================================================
   TEST BOT  -  STEP 1  -  AUTOMATIC SETUP
================================================================
  This finds or installs Python, sets everything up, opens the
  Topstep page for your API key, grabs it from your clipboard,
  and checks it works.

  Your key is saved only on this computer.
================================================================

BANNER
bash setup.sh
echo
printf "Press RETURN to close this window: "
read -r _
