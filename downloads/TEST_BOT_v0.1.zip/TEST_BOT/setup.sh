#!/bin/bash
# Bootstrap. Handles the case where Python does not exist yet, then hands
# off to setup_wizard.py which does the real work.
cd "$(dirname "$0")"

PY=""
for c in python3 python3.12 python3.11 python3.10 python3.9 python; do
  if command -v "$c" >/dev/null 2>&1; then
    if "$c" -c 'import sys; sys.exit(0 if sys.version_info>=(3,9) else 1)' 2>/dev/null; then
      PY="$c"; break
    fi
  fi
done

if [ -z "$PY" ]; then
  echo
  echo "================================================================"
  echo "   Python is not installed (or is too old)"
  echo "================================================================"
  echo
  echo "  The bot needs Python 3.9 or newer. It is free and safe."
  echo

  if command -v brew >/dev/null 2>&1; then
    echo "  Homebrew is on this Mac, so I can install it for you."
    echo
    printf "  Install Python now? (Y/n): "
    read -r ans
    case "$ans" in
      [Nn]*) ;;
      *)
        echo
        echo "  Installing, this takes a few minutes..."
        brew install python@3.12 && {
          echo
          echo "  Done. Starting setup..."
          exec bash "$0"
        }
        ;;
    esac
  fi

  echo "  Opening the download page in your browser..."
  if command -v open >/dev/null 2>&1; then
    open "https://www.python.org/downloads/"
  elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "https://www.python.org/downloads/"
  fi
  echo
  echo "  Install it, then double-click this file again."
  echo
  exit 1
fi

exec "$PY" setup_wizard.py
