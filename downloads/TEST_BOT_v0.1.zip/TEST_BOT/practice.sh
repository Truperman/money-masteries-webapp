#!/bin/bash
cd "$(dirname "$0")"
if [ ! -d .venv ]; then echo "Run setup first."; exit 1; fi
if [ -f mes_1min.csv ]; then
  echo "Found mes_1min.csv - practicing on REAL data."
  .venv/bin/python practice.py --csv mes_1min.csv "$@"
else
  echo "No real data file found - practicing on TEST data."
  echo "(Results mean nothing about profit. Get real data with step 3.)"
  echo
  .venv/bin/python practice.py --days 120 --windows 3 "$@"
fi
