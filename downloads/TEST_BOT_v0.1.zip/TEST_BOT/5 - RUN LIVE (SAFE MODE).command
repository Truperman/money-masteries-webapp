#!/bin/bash
cd "$(dirname "$0")"
clear
cat <<'BANNER'
================================================================
   TEST BOT  -  STEP 5  -  RUN IN SAFE MODE
================================================================
  Connects to your real Topstep account, watches the market and
  logs every trade it WOULD make.

  It does NOT send any orders. Nothing is at risk.

  To stop: hold CONTROL and press C.
  Do NOT just close this window.
================================================================

BANNER
bash go.sh
echo
printf "Press RETURN to close this window: "
read -r _
