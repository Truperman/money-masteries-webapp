#!/bin/bash
cd "$(dirname "$0")"
clear
cat <<'BANNER'
================================================================
   TEST BOT  -  STEP 2  -  PRACTICE
================================================================
  Runs the bot over historical data and reports whether it made
  money, whether that could be luck, and whether the result holds
  up on data it was not tuned on.

  No account is touched. No orders. Nothing at risk.
  This takes a few minutes.
================================================================

BANNER
bash practice.sh
echo
printf "Press RETURN to close this window: "
read -r _
