#!/usr/bin/env python3
"""
TEST BOT — practice run on historical data.

    python3 practice.py                    # synthetic data, pipeline check
    python3 practice.py --csv mes_1min.csv # REAL data, the one that counts

Runs three things, in increasing order of how much you should trust them:

  1. A straight backtest — did it make money on this history?
  2. A permutation test — could that have happened by chance?
  3. Walk-forward analysis — does the edge survive on data the optimiser
     never saw?

Only the third answers "is this real". The first two are diagnostics.
"""

from __future__ import annotations

import argparse
import sys

import pandas as pd

from flowbot.data import SyntheticConfig, load_csv, synthetic
from flowbot.profile import build_profile
from flowbot.risk import PRESETS, RiskState
from flowbot.strategy import StrategyConfig, TestBotStrategy
from flowbot.walkforward import grid, permutation_test, walk_forward

pd.set_option("display.width", 200)

TICK_SIZE = 0.25
TICK_VALUE = 1.25          # MES
COMMISSION = 0.37          # per side, per contract
SLIPPAGE_TICKS = 1.0


def run_backtest(df: pd.DataFrame, params: dict | None = None,
                 preset: str = "prop_50k") -> dict:
    """
    Bar-by-bar run of TEST BOT with the full risk layer.

    Pessimistic on purpose: entries fill at the next bar's open, stops fill
    at the stop or worse, and when a bar contains both the stop and the
    target the STOP is assumed to hit first.
    """
    params = params or {}
    cfg = StrategyConfig()
    for k, v in params.items():
        if hasattr(cfg, k):
            setattr(cfg, k, v)

    strat = TestBotStrategy(cfg)
    risk_cfg = PRESETS[preset]
    risk = RiskState(risk_cfg)

    equity = risk_cfg.account_size
    trades, pnls = [], []
    position = None
    pending = None
    session = None
    slip = SLIPPAGE_TICKS * TICK_SIZE

    bars = list(df.itertuples())

    for i, bar in enumerate(bars):
        ts = bar.Index.to_pydatetime()

        if bar.session != session:
            session = bar.session
            strat.start_session(session)
            risk.start_day(session)
            pending = None

        # --- manage an open position ---------------------------------
        if position is not None:
            exit_px, reason = None, ""
            if position["is_long"]:
                if bar.low <= position["stop"]:
                    exit_px = min(position["stop"], bar.open) - slip
                    reason = "stop"
                elif bar.high >= position["target"]:
                    exit_px = max(position["target"], bar.open) - slip
                    reason = "target"
            else:
                if bar.high >= position["stop"]:
                    exit_px = max(position["stop"], bar.open) + slip
                    reason = "stop"
                elif bar.low <= position["target"]:
                    exit_px = min(position["target"], bar.open) + slip
                    reason = "target"

            if exit_px is None and ts.time() >= cfg.session_end:
                exit_px, reason = float(bar.close), "session_end"

            if exit_px is not None:
                d = 1 if position["is_long"] else -1
                ticks = (exit_px - position["entry"]) / TICK_SIZE * d
                pnl = (ticks * TICK_VALUE * position["contracts"]
                       - 2 * COMMISSION * position["contracts"])
                equity += pnl
                risk.on_trade_closed(pnl, ts)
                pnls.append(pnl)
                trades.append({**position, "exit": exit_px, "pnl": pnl,
                               "reason": reason, "exit_time": ts})
                position = None

        # --- fill a pending entry ------------------------------------
        if position is None and pending is not None:
            halt = risk.check(ts, equity=equity)
            if halt.name == "NONE":
                s = pending
                entry = bar.open + (slip if s.is_long else -slip)
                risk_dollars = risk.risk_for_trade(s.grade, equity=equity)
                stop_ticks = abs(entry - s.stop_price) / TICK_SIZE
                if stop_ticks > 0 and risk_dollars > 0:
                    contracts = int(risk_dollars // (stop_ticks * TICK_VALUE))
                    contracts = max(min(contracts, 50), 0)
                    if contracts > 0:
                        position = {
                            "is_long": s.is_long, "entry": entry,
                            "stop": s.stop_price, "target": s.target_price,
                            "contracts": contracts, "grade": s.grade,
                            "kind": s.kind, "entry_time": ts,
                        }
            pending = None

        # --- ask for a new signal ------------------------------------
        if position is None and pending is None:
            if risk.check(ts, equity=equity).name == "NONE":
                hist = df.iloc[max(0, i - 300): i + 1]
                setup = strat.on_bar(bar.Index, bar, hist)
                if setup is not None and i + 1 < len(bars):
                    pending = setup

    wins = [p for p in pnls if p > 0]
    losses = [p for p in pnls if p <= 0]
    gross_w = sum(wins)
    gross_l = abs(sum(losses))

    return {
        "n_trades": len(pnls),
        "net_profit": round(sum(pnls), 2),
        "win_rate": round(len(wins) / len(pnls), 4) if pnls else 0.0,
        "avg_win": round(gross_w / len(wins), 2) if wins else 0.0,
        "avg_loss": round(-gross_l / len(losses), 2) if losses else 0.0,
        "profit_factor": round(gross_w / gross_l, 2) if gross_l > 0 else 0.0,
        "expectancy": round(sum(pnls) / len(pnls), 2) if pnls else 0.0,
        "max_dd": round(_max_drawdown(pnls), 2),
        "_pnls": pnls,
        "_trades": trades,
    }


def _max_drawdown(pnls) -> float:
    if not pnls:
        return 0.0
    eq = pd.Series(pnls).cumsum()
    return float((eq - eq.cummax()).min())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", help="real intraday MES bars")
    ap.add_argument("--days", type=int, default=250)
    ap.add_argument("--preset", default="prop_50k", choices=list(PRESETS.keys()))
    ap.add_argument("--windows", type=int, default=5)
    args = ap.parse_args()

    if args.csv:
        df = load_csv(args.csv)
        label = f"REAL DATA — {args.csv}"
        real = True
    else:
        df = synthetic(SyntheticConfig(n_days=args.days, seed=20260822))
        label = "SYNTHETIC DATA — pipeline check only, proves nothing about edge"
        real = False

    rng = df.groupby("session").agg(hi=("high", "max"), lo=("low", "min"))
    print(f"\n{'=' * 70}\nTEST BOT — practice run\n{'=' * 70}")
    print(f"{label}")
    print(f"bars {len(df):,}   sessions {df.session.nunique()}   "
          f"median daily range {(rng.hi - rng.lo).median():.1f} pts")

    cfgv = PRESETS[args.preset]
    print(f"\nrisk preset: {args.preset}")
    for w in cfgv.validate():
        print(f"  ! {w}")
    print(f"  hard 2% cap ${cfgv.hard_daily_loss:,.0f} / "
          f"soft stop ${cfgv.soft_daily_loss:,.0f} / "
          f"per trade ${cfgv.base_risk:,.0f}")

    # ---- 1. straight backtest --------------------------------------
    print(f"\n{'=' * 70}\n1. BACKTEST\n{'=' * 70}")
    res = run_backtest(df, preset=args.preset)
    for k in ("n_trades", "win_rate", "avg_win", "avg_loss", "expectancy",
              "profit_factor", "net_profit", "max_dd"):
        print(f"  {k:<15} {res[k]}")

    if res["n_trades"] == 0:
        print("\n  No trades. The three filters are strict by design — on this")
        print("  data nothing satisfied direction + location + aggression.")
        return

    # ---- 2. permutation test ---------------------------------------
    print(f"\n{'=' * 70}\n2. PERMUTATION TEST — could this be luck?\n{'=' * 70}")
    perm = permutation_test(res["net_profit"], res["_pnls"])
    for k, v in perm.items():
        print(f"  {k:<15} {v}")
    if not perm["significant"]:
        print("\n  Not distinguishable from random. Same trades with shuffled")
        print("  signs produce this result often enough to matter.")

    # ---- 3. walk-forward -------------------------------------------
    print(f"\n{'=' * 70}\n3. WALK-FORWARD — does it survive unseen data?\n{'=' * 70}")
    param_grid = grid(
        stop_atr_mult=[0.75, 1.0, 1.5],
        target_r=[1.5, 2.0, 3.0],
        level_tolerance_atr=[0.3, 0.5],
    )
    print(f"  {len(param_grid)} parameter combinations, "
          f"{args.windows} windows\n")

    try:
        wf = walk_forward(
            df, param_grid,
            lambda d, p: run_backtest(d, p, preset=args.preset),
            metric="net_profit", n_windows=args.windows, min_trades=5,
        )
        print()
        print(wf.report())
    except ValueError as e:
        print(f"  Cannot run walk-forward: {e}")

    if not real:
        print("\n" + "!" * 70)
        print("  REMINDER: this was synthetic data. It shows the pipeline")
        print("  runs end to end. It says NOTHING about whether TEST BOT")
        print("  makes money. Re-run with --csv and real MES bars.")
        print("!" * 70)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
