"""
TEST BOT strategy — Direction, Location, Aggression.

Implements the three-filter funnel from Fabio Valentini's method. A trade
requires all three filters to agree. Each filter can only VETO; none can
generate a trade on its own. That structure is the point: retail order flow
fails because it trades aggression alone, and a delta spike at a
meaningless price is noise.

    DIRECTION   Who controls the session? VWAP position and cumulative
                volume delta must agree. Disagreement means no bias, and
                no bias means no trade.

    LOCATION    Is price somewhere that matters? It must be within
                tolerance of a profile level — POC, value area edge, or a
                low-volume node. No level, no trade, regardless of how good
                the tape looks.

    AGGRESSION  Does the flow confirm entering here, right now? Absorption,
                delta shift, or book imbalance in the intended direction.

Setups are graded by how many filters fire cleanly, and the grade scales
position size through the risk layer: A full, B half, C quarter.

HONEST NOTE ON THE AGGRESSION FILTER
    With bar data only, "aggression" is approximated from volume and range
    (the absorption formula, plus bar-inferred delta). That is weaker than
    real footprint data. When live order flow from record_flow.py is
    available, `OrderFlowState` supplies the real version and the same
    interface accepts it. The strategy does not change; the quality of its
    third filter does.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import time

import numpy as np
import pandas as pd

from .profile import SessionContext, VolumeProfile, build_profile

RTH_OPEN = time(8, 30)
RTH_CLOSE = time(15, 0)


@dataclass
class Setup:
    """A proposed trade, with its grade and its reasoning."""

    is_long: bool
    entry_price: float
    stop_price: float
    target_price: float
    grade: str                 # "A", "B", or "C"
    kind: str                  # which named setup fired
    level_type: str            # which profile level it happened at
    level_price: float
    reasons: list

    @property
    def risk_points(self) -> float:
        return abs(self.entry_price - self.stop_price)

    @property
    def reward_risk(self) -> float:
        r = self.risk_points
        if r <= 0:
            return 0.0
        return abs(self.target_price - self.entry_price) / r


@dataclass
class StrategyConfig:
    # Profile
    profile_lookback: int = 120          # bars used to build the profile
    row_size_ticks: int = 4
    value_area_pct: float = 0.70

    # Location
    level_tolerance_atr: float = 0.5     # how close to a level counts

    # Aggression — Fabio's absorption formula
    absorption_volume_mult: float = 2.0
    absorption_range_atr: float = 0.3
    delta_smoothing: int = 5

    # Risk shape
    stop_atr_mult: float = 1.0
    min_reward_risk: float = 2.0
    target_r: float = 2.0

    # Session discipline — one market, one session
    session_start: time = time(8, 30)
    session_end: time = time(13, 0)
    max_trades_per_day: int = 5

    # Rebuild the volume profile every N bars rather than every bar. A
    # profile built from 120 bars barely moves in one minute, so this is
    # ~15x faster with no meaningful loss of information — and it matches
    # how a human reads a profile anyway.
    profile_refresh_bars: int = 15

    # Filters
    min_atr: float = 0.5                 # skip dead markets
    require_bias: bool = True            # direction filter mandatory


class TestBotStrategy:
    """
    The strategy. Stateless between sessions except for the trade counter.

    `on_bar()` returns a Setup or None. It never sizes the position and
    never decides whether trading is allowed — the risk layer owns both.
    """

    name = "test_bot_dla"

    def __init__(self, config: StrategyConfig | None = None):
        self.cfg = config or StrategyConfig()
        self.trades_today = 0
        self.profile: VolumeProfile | None = None
        self.session_bars: list = []
        self.cvd = 0.0
        self.last_reasons: list = []
        self._bars_since_profile = 0
        self._vwap_pv = 0.0        # running sum of typical price * volume
        self._vwap_v = 0.0         # running sum of volume

    def start_session(self, session_date) -> None:
        self.trades_today = 0
        self.profile = None
        self.session_bars = []
        self.cvd = 0.0
        self._bars_since_profile = 0
        self._vwap_pv = 0.0
        self._vwap_v = 0.0

    # ------------------------------------------------------------------

    def on_bar(self, ts, bar, history: pd.DataFrame) -> Setup | None:
        self.last_reasons = []
        t = ts.time() if hasattr(ts, "time") else ts

        if t < self.cfg.session_start or t > self.cfg.session_end:
            return None
        if self.trades_today >= self.cfg.max_trades_per_day:
            return None
        if len(history) < self.cfg.profile_lookback:
            return None

        atr = self._atr(history)
        if not np.isfinite(atr) or atr < self.cfg.min_atr:
            self.last_reasons.append("ATR too low — market is dead")
            return None

        # Track cumulative delta from bar-inferred aggression.
        self.cvd += self._bar_delta(bar)

        window = history.iloc[-self.cfg.profile_lookback:]

        self._bars_since_profile += 1
        if self.profile is None or self._bars_since_profile >= self.cfg.profile_refresh_bars:
            self.profile = build_profile(
                window,
                row_size_ticks=self.cfg.row_size_ticks,
                value_area_pct=self.cfg.value_area_pct,
            )
            self._bars_since_profile = 0
        if self.profile is None:
            return None

        vwap = self._update_vwap(bar)
        ctx = SessionContext(
            profile=self.profile,
            vwap=vwap,
            cvd=self.cvd,
            opening_price=float(window["open"].iloc[0]),
            current_price=float(bar.close),
        )

        # ---- FILTER 1: DIRECTION ----------------------------------------
        bias = ctx.bias
        if self.cfg.require_bias and bias == 0:
            self.last_reasons.append("no direction — VWAP and CVD disagree")
            return None

        # ---- FILTER 2: LOCATION -----------------------------------------
        tolerance = atr * self.cfg.level_tolerance_atr
        level = self.profile.nearest_level(float(bar.close), tolerance)
        if level is None:
            self.last_reasons.append("no profile level within tolerance")
            return None
        level_type, level_price = level

        # ---- FILTER 3: AGGRESSION ---------------------------------------
        absorbing = self._absorption(bar, history, atr)
        delta_shift = self._delta_shift(history)

        # ---- Assemble a setup ------------------------------------------
        setup = self._select_setup(
            ctx, bar, atr, bias, level_type, level_price,
            absorbing, delta_shift,
        )
        if setup is None:
            return None
        if setup.reward_risk < self.cfg.min_reward_risk:
            self.last_reasons.append(
                f"reward:risk {setup.reward_risk:.1f} below "
                f"{self.cfg.min_reward_risk}"
            )
            return None

        self.trades_today += 1
        return setup

    # ------------------------------------------------------------------
    # Setup selection
    # ------------------------------------------------------------------

    def _select_setup(self, ctx, bar, atr, bias, level_type, level_price,
                      absorbing, delta_shift) -> Setup | None:
        px = float(bar.close)
        reasons = [f"bias {'long' if bias > 0 else 'short'}",
                   f"at {level_type} {level_price:.2f}"]

        is_long = bias > 0
        stop_dist = atr * self.cfg.stop_atr_mult
        if stop_dist <= 0:
            return None

        confirmations = 0
        kind = "trend_pullback"

        if ctx.is_balanced:
            # Balanced day: fade the value area edges, but only into
            # absorption. Fading without absorption is how ranges kill you
            # on the day they finally break.
            at_edge = level_type in ("vah", "val")
            if not at_edge:
                self.last_reasons.append(
                    "balanced day but not at a value edge — no trade"
                )
                return None
            if not absorbing:
                self.last_reasons.append(
                    "balanced-day fade requires absorption; none detected"
                )
                return None

            kind = "value_area_fade"
            is_long = level_type == "val"
            reasons.append("absorption at value edge")
            confirmations += 1
            if delta_shift * (1 if is_long else -1) > 0:
                confirmations += 1
                reasons.append("delta shift supports the fade")
            target = ctx.profile.poc

        else:
            # Imbalanced day: go with the flow, entering at levels.
            if level_type == "lvn":
                kind = "lvn_breakout"
                reasons.append("low-volume node — price travels fast here")
                confirmations += 1
            elif level_type in ("poc", "hvn"):
                kind = "value_pullback"
                reasons.append("pullback into accepted value")

            if delta_shift * (1 if is_long else -1) > 0:
                confirmations += 1
                reasons.append("delta confirms direction")
            if absorbing:
                confirmations += 1
                reasons.append("absorption supports the level holding")

            target = px + (stop_dist * self.cfg.target_r if is_long
                           else -stop_dist * self.cfg.target_r)

        if confirmations == 0:
            self.last_reasons.append("no aggression confirmation")
            return None

        grade = "A" if confirmations >= 2 else "B" if confirmations == 1 else "C"

        stop = px - stop_dist if is_long else px + stop_dist

        # A fade's target is the POC, which may sit the wrong side of entry
        # if price has already crossed it. Reject rather than invert.
        if is_long and target <= px:
            return None
        if not is_long and target >= px:
            return None

        return Setup(
            is_long=is_long, entry_price=px, stop_price=stop,
            target_price=float(target), grade=grade, kind=kind,
            level_type=level_type, level_price=level_price, reasons=reasons,
        )

    # ------------------------------------------------------------------
    # Signal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _atr(history: pd.DataFrame, n: int = 14) -> float:
        if len(history) < n + 1:
            return float("nan")
        h = history["high"].to_numpy(dtype=float)[-n:]
        l = history["low"].to_numpy(dtype=float)[-n:]
        c = history["close"].to_numpy(dtype=float)[-n - 1:-1]
        tr = np.maximum(h - l, np.maximum(np.abs(h - c), np.abs(l - c)))
        return float(tr.mean())

    @staticmethod
    def _bar_delta(bar) -> float:
        """
        Approximate signed volume from where the bar closed in its range.

        This is a proxy, not real aggressor data. A bar closing at its high
        is treated as buying pressure. It is the same approximation
        TradingView's volume delta makes, and it carries the same error.
        """
        rng = float(bar.high) - float(bar.low)
        if rng <= 0:
            return 0.0
        pos = (float(bar.close) - float(bar.low)) / rng      # 0..1
        return float(bar.volume) * (2.0 * pos - 1.0)         # -vol..+vol

    def _delta_shift(self, history: pd.DataFrame) -> float:
        """Recent delta momentum, smoothed."""
        n = self.cfg.delta_smoothing
        if len(history) < n * 2:
            return 0.0
        deltas = [self._bar_delta(r) for r in history.iloc[-n * 2:].itertuples()]
        recent = float(np.mean(deltas[-n:]))
        prior = float(np.mean(deltas[:n]))
        return recent - prior

    def _absorption(self, bar, history: pd.DataFrame, atr: float) -> bool:
        """
        Fabio's formula: heavy volume, tight range.

            volume > avg_volume * 2.0  AND  range < ATR * 0.3

        Somebody large is filling passively and the price is not moving.
        """
        if len(history) < 20:
            return False
        avg_vol = float(history["volume"].iloc[-20:].mean())
        if avg_vol <= 0:
            return False
        rng = float(bar.high) - float(bar.low)
        return (
            float(bar.volume) > avg_vol * self.cfg.absorption_volume_mult
            and rng < atr * self.cfg.absorption_range_atr
        )

    def _update_vwap(self, bar) -> float:
        """
        Session-anchored VWAP, maintained incrementally.

        Two fixes over the obvious implementation. It is O(1) per bar
        instead of O(n) — recomputing over the whole history every bar was
        56% of total backtest runtime. And it anchors to the SESSION open,
        resetting in start_session(), rather than drifting over a rolling
        window that straddles session boundaries. A VWAP that includes
        yesterday is not the level anyone trades against.
        """
        typical = (float(bar.high) + float(bar.low) + float(bar.close)) / 3.0
        vol = float(bar.volume) or 1.0
        self._vwap_pv += typical * vol
        self._vwap_v += vol
        if self._vwap_v <= 0:
            return typical
        return self._vwap_pv / self._vwap_v
