"""
Risk layer — works for a prop evaluation OR a personal account.

The rule you asked for, stated precisely:

    Never lose more than 2% of the account in a single day.
    $1,000 on a $50K account. $2,000 on a $100K account.

That is implemented as an absolute hard ceiling. But a hard ceiling alone
is not risk management, for a reason worth being explicit about.

    On a Topstep $50K Combine, your entire trailing drawdown buffer is
    $2,000. A 2% day is $1,000 — HALF your total buffer, gone in one
    session. Two of those and the account is finished.

So the design here is two-tier. The 2% hard cap is the wall you asked for
and it never moves. Inside it sits a soft stop that halts the session much
earlier, plus Fabio's governors: a consecutive-loss timeout, a losing-day
size reduction, and a profit-protection cut. The soft stop is what actually
fires on a normal bad day; the 2% wall exists so that no combination of
bugs, gaps or bad luck can exceed it.

On a personal account the buffer argument disappears, so `PERSONAL_PRESET`
relaxes the soft stop toward the 2% ceiling. Same code, different tuning.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum


class Halt(Enum):
    NONE = "none"
    SOFT_DAILY_LOSS = "soft_daily_loss"
    HARD_DAILY_LOSS = "hard_daily_loss_2pct"
    LOSS_STREAK = "consecutive_losses"
    PROFIT_TARGET = "daily_profit_target"
    DRAWDOWN_FLOOR = "drawdown_floor"
    WEEKLY_STANDDOWN = "weekly_standdown"


@dataclass
class RiskConfig:
    """
    Every knob, in one place.

    Fractions are of ACCOUNT SIZE unless the name says otherwise.
    """

    account_size: float = 50_000.0

    # --- the hard rule -------------------------------------------------
    hard_daily_loss_pct: float = 0.02        # 2% — never exceeded
    # --- the stop that actually fires ----------------------------------
    soft_daily_loss_pct: float = 0.005       # 0.5% = $250 on $50K

    # --- per trade -----------------------------------------------------
    risk_per_trade_pct: float = 0.0025       # 0.25%, Fabio's number = $125
    min_reward_risk: float = 2.0

    # --- prop-specific: the trailing buffer ----------------------------
    # None for a personal account. When set, position size is additionally
    # clamped so no single trade can risk more than a fraction of what is
    # left above the drawdown floor.
    drawdown_buffer: float | None = 2_000.0
    max_buffer_fraction_per_trade: float = 0.075   # 7.5% of remaining buffer

    # --- governors (Fabio) ---------------------------------------------
    max_consecutive_losses: int = 3
    loss_timeout_minutes: int = 30
    daily_profit_target_r: float = 2.0       # at +2R, cut size
    profit_size_multiplier: float = 0.5
    losing_days_before_standdown: int = 2
    standdown_size_multiplier: float = 0.5

    # --- setup grading --------------------------------------------------
    grade_multipliers: dict = field(
        default_factory=lambda: {"A": 1.0, "B": 0.5, "C": 0.25}
    )

    # --- derived --------------------------------------------------------
    @property
    def hard_daily_loss(self) -> float:
        return self.account_size * self.hard_daily_loss_pct

    @property
    def soft_daily_loss(self) -> float:
        return self.account_size * self.soft_daily_loss_pct

    @property
    def base_risk(self) -> float:
        return self.account_size * self.risk_per_trade_pct

    def validate(self) -> list[str]:
        """
        Sanity checks. Returns warnings rather than raising, because a
        risky configuration is the user's choice to make — but it should
        never be made silently.
        """
        warnings = []

        if self.soft_daily_loss > self.hard_daily_loss:
            warnings.append(
                f"soft stop ${self.soft_daily_loss:,.0f} exceeds the hard "
                f"cap ${self.hard_daily_loss:,.0f} — the soft stop can never fire"
            )

        if self.drawdown_buffer is not None:
            # >= not >. A 2% cap on a $50K Combine is EXACTLY half the
            # $2,000 buffer, and that is precisely the case this warning
            # exists for — a strict > silently skipped it.
            if self.hard_daily_loss >= self.drawdown_buffer * 0.5:
                warnings.append(
                    f"a full {self.hard_daily_loss_pct:.0%} day "
                    f"(${self.hard_daily_loss:,.0f}) is "
                    f"{self.hard_daily_loss / self.drawdown_buffer:.0%} of your "
                    f"${self.drawdown_buffer:,.0f} drawdown buffer — "
                    f"{self.drawdown_buffer / self.hard_daily_loss:.1f} such days "
                    f"ends the account"
                )
            trades_to_floor = self.drawdown_buffer / self.base_risk
            if trades_to_floor < 10:
                warnings.append(
                    f"only {trades_to_floor:.0f} losing trades of "
                    f"${self.base_risk:,.0f} would exhaust the buffer; "
                    f"13+ is a healthier margin"
                )

        if self.min_reward_risk < 1.5:
            warnings.append(
                f"reward:risk of {self.min_reward_risk} needs a high win rate; "
                f"payoff ratio buys pass probability more cheaply than hit rate"
            )

        return warnings


# Preset for a Topstep $50K Combine.
PROP_50K = RiskConfig(
    account_size=50_000.0,
    hard_daily_loss_pct=0.02,       # $1,000 — matches Topstep's own limit
    soft_daily_loss_pct=0.005,      # $250 — where the bot actually stops
    risk_per_trade_pct=0.0025,      # $125
    drawdown_buffer=2_000.0,
)

PROP_100K = RiskConfig(
    account_size=100_000.0,
    hard_daily_loss_pct=0.02,       # $2,000 — matches Topstep's limit
    soft_daily_loss_pct=0.005,      # $500
    risk_per_trade_pct=0.0025,      # $250
    drawdown_buffer=3_000.0,
)

# Personal account: no trailing buffer, so the soft stop can sit closer to
# the 2% wall. Still not AT it — a 2% loss day should be rare, not routine.
PERSONAL = RiskConfig(
    account_size=50_000.0,
    hard_daily_loss_pct=0.02,
    soft_daily_loss_pct=0.012,
    risk_per_trade_pct=0.0025,
    drawdown_buffer=None,
)

PRESETS = {"prop_50k": PROP_50K, "prop_100k": PROP_100K, "personal": PERSONAL}


@dataclass
class RiskState:
    """
    Live risk state for one account. Ask it before every trade.

    `check()` returns a Halt. Anything other than Halt.NONE means do not
    trade, and the reason is in the enum.
    """

    config: RiskConfig
    day_pnl: float = 0.0
    equity_high: float = 0.0
    consecutive_losses: int = 0
    losing_days: int = 0
    timeout_until: datetime | None = None
    current_day: object = None
    halted_reason: Halt = Halt.NONE
    trades_today: int = 0
    day_history: list = field(default_factory=list)

    def __post_init__(self):
        self.equity_high = self.config.account_size

    # -- lifecycle -----------------------------------------------------

    def start_day(self, day) -> None:
        if self.current_day is not None:
            self.day_history.append(self.day_pnl)
            if self.day_pnl < 0:
                self.losing_days += 1
            else:
                self.losing_days = 0
        self.current_day = day
        self.day_pnl = 0.0
        self.consecutive_losses = 0
        self.timeout_until = None
        self.halted_reason = Halt.NONE
        self.trades_today = 0

    def on_trade_closed(self, pnl: float, when: datetime) -> None:
        self.day_pnl += pnl
        self.trades_today += 1

        if pnl > 0:
            self.consecutive_losses = 0
        else:
            self.consecutive_losses += 1
            if self.consecutive_losses >= self.config.max_consecutive_losses:
                self.timeout_until = when + timedelta(
                    minutes=self.config.loss_timeout_minutes
                )

    # -- the gate ------------------------------------------------------

    def check(self, now: datetime, equity: float | None = None) -> Halt:
        """The single question: may I open a position right now?"""
        cfg = self.config

        if equity is not None:
            self.equity_high = max(self.equity_high, equity)

        # Hard 2% ceiling. This is the wall.
        if self.day_pnl <= -cfg.hard_daily_loss:
            self.halted_reason = Halt.HARD_DAILY_LOSS
            return self.halted_reason

        # Soft stop — where a normal bad day actually ends.
        if self.day_pnl <= -cfg.soft_daily_loss:
            self.halted_reason = Halt.SOFT_DAILY_LOSS
            return self.halted_reason

        # Prop only: never trade with the drawdown floor in reach.
        if cfg.drawdown_buffer is not None and equity is not None:
            floor = self.equity_high - cfg.drawdown_buffer
            if equity - floor <= cfg.base_risk:
                self.halted_reason = Halt.DRAWDOWN_FLOOR
                return self.halted_reason

        # Consecutive-loss cooling-off.
        if self.timeout_until is not None and now < self.timeout_until:
            self.halted_reason = Halt.LOSS_STREAK
            return self.halted_reason

        self.halted_reason = Halt.NONE
        return Halt.NONE

    # -- sizing --------------------------------------------------------

    def risk_for_trade(self, grade: str = "A", equity: float | None = None) -> float:
        """
        Dollars to risk on the next trade, after every reduction.

        Reductions compound: a B-grade setup, after two losing days, with
        the daily profit target already banked, gets 0.5 * 0.5 * 0.5 of
        base risk. That is intentional — the conditions stack because the
        reasons to be careful stack.
        """
        cfg = self.config
        risk = cfg.base_risk

        risk *= cfg.grade_multipliers.get(grade.upper(), 0.25)

        # Profit protection: once the day is good, stop pressing.
        if self.day_pnl >= cfg.base_risk * cfg.daily_profit_target_r:
            risk *= cfg.profit_size_multiplier

        # Weekly stand-down after consecutive losing days.
        if self.losing_days >= cfg.losing_days_before_standdown:
            risk *= cfg.standdown_size_multiplier

        # Never let one trade exceed what is left of today's soft budget.
        room_today = cfg.soft_daily_loss + self.day_pnl
        risk = min(risk, max(room_today, 0.0))

        # Prop only: clamp against the remaining trailing buffer.
        if cfg.drawdown_buffer is not None and equity is not None:
            floor = self.equity_high - cfg.drawdown_buffer
            remaining = max(equity - floor, 0.0)
            risk = min(risk, remaining * cfg.max_buffer_fraction_per_trade)

        return max(risk, 0.0)

    def snapshot(self) -> dict:
        return {
            "day_pnl": round(self.day_pnl, 2),
            "trades_today": self.trades_today,
            "consecutive_losses": self.consecutive_losses,
            "losing_days": self.losing_days,
            "halted": self.halted_reason.value,
            "soft_stop": round(self.config.soft_daily_loss, 2),
            "hard_stop_2pct": round(self.config.hard_daily_loss, 2),
        }
