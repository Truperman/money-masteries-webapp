"""
Volume profile — the LOCATION filter.

This is the piece bot #1 was missing entirely, and the reason its order flow
signals had no context. Fabio Valentini's framework runs
Direction -> Location -> Aggression, and without a location filter you are
trading aggression alone, which is how retail order flow fails: a delta
spike at a meaningless price is noise.

What this computes, from bars or from trades:

    POC   Point of Control — the price with the most traded volume. The
          session's centre of gravity.
    VAH   Value Area High
    VAL   Value Area Low — together, the range containing 70% of volume.
          Price inside value = balanced, outside = imbalanced.
    LVN   Low Volume Nodes — price shelves that were rejected quickly.
          Price tends to move FAST through these, so they make poor targets
          and good breakout triggers.
    HVN   High Volume Nodes — accepted prices that tend to attract and
          hold price. Good targets, bad places to expect a breakout.

The 70% value area is convention, inherited from Market Profile's use of
one standard deviation. It is a choice, not a law; it is configurable.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd


@dataclass
class VolumeProfile:
    """A computed profile over some window of price action."""

    prices: np.ndarray          # bin centres, ascending
    volumes: np.ndarray         # volume at each bin
    poc: float
    vah: float
    val: float
    total_volume: float
    bin_size: float
    lvns: list = field(default_factory=list)
    hvns: list = field(default_factory=list)

    @property
    def value_area_width(self) -> float:
        return self.vah - self.val

    def is_inside_value(self, price: float) -> bool:
        return self.val <= price <= self.vah

    def position(self, price: float) -> str:
        """Where price sits relative to the profile, as a label."""
        if price > self.vah:
            return "above_value"
        if price < self.val:
            return "below_value"
        if abs(price - self.poc) <= self.bin_size:
            return "at_poc"
        return "inside_value"

    def nearest_level(self, price: float, tolerance: float) -> tuple[str, float] | None:
        """
        The closest meaningful level within `tolerance`, or None.

        This is the actual location gate: if it returns None, there is no
        level here and the trade should not happen regardless of how good
        the order flow looks.
        """
        candidates = [("poc", self.poc), ("vah", self.vah), ("val", self.val)]
        candidates += [("lvn", p) for p in self.lvns]
        candidates += [("hvn", p) for p in self.hvns]

        best, best_dist = None, float("inf")
        for name, level in candidates:
            d = abs(price - level)
            if d < best_dist:
                best, best_dist = (name, level), d

        return best if best_dist <= tolerance else None

    def summary(self) -> dict:
        return {
            "poc": round(self.poc, 2),
            "vah": round(self.vah, 2),
            "val": round(self.val, 2),
            "value_width": round(self.value_area_width, 2),
            "total_volume": round(self.total_volume, 1),
            "n_lvn": len(self.lvns),
            "n_hvn": len(self.hvns),
        }


def build_profile(
    bars: pd.DataFrame,
    tick_size: float = 0.25,
    row_size_ticks: int = 4,
    value_area_pct: float = 0.70,
    lvn_threshold: float = 0.30,
    hvn_threshold: float = 0.80,
) -> VolumeProfile | None:
    """
    Build a volume profile from OHLCV bars.

    Volume is spread evenly across each bar's high-low range. This is the
    standard approximation when you do not have tick data, and it is
    genuinely approximate — real profiles from trades put volume where it
    actually traded, not uniformly. Use `build_profile_from_trades` when you
    have the tape; the shape differs enough to matter at the edges.

    row_size_ticks controls resolution. Too fine and every bin is noise;
    too coarse and the value area loses meaning. Four ticks on MES (one
    point) is a reasonable default.
    """
    if bars is None or len(bars) == 0:
        return None

    lo = float(bars["low"].min())
    hi = float(bars["high"].max())
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        return None

    bin_size = tick_size * row_size_ticks
    n_bins = max(int(np.ceil((hi - lo) / bin_size)) + 1, 2)
    edges = lo + np.arange(n_bins + 1) * bin_size
    centres = edges[:-1] + bin_size / 2.0
    vols = np.zeros(n_bins, dtype=float)

    highs = bars["high"].to_numpy(dtype=float)
    lows = bars["low"].to_numpy(dtype=float)
    volumes = bars["volume"].to_numpy(dtype=float)

    keep = volumes > 0
    if not keep.any():
        return None
    highs, lows, volumes = highs[keep], lows[keep], volumes[keep]

    # Spread each bar's volume evenly across the bins its range covers.
    # Vectorised: the naive per-bar Python loop dominated runtime, making
    # a walk-forward sweep take about an hour instead of a minute.
    first = np.clip(((lows - lo) // bin_size).astype(np.int64), 0, n_bins - 1)
    last = np.clip(((highs - lo) // bin_size).astype(np.int64), 0, n_bins - 1)
    spans = (last - first + 1).astype(np.int64)

    starts = np.repeat(first, spans)
    ends = np.cumsum(spans)
    offsets = np.arange(int(ends[-1])) - np.repeat(ends - spans, spans)
    idx = starts + offsets
    weights = np.repeat(volumes / spans, spans)

    vols = np.bincount(idx, weights=weights, minlength=n_bins).astype(float)[:n_bins]

    total = float(vols.sum())
    if total <= 0:
        return None

    poc_idx = int(np.argmax(vols))
    poc = float(centres[poc_idx])

    val_idx, vah_idx = _value_area(vols, poc_idx, value_area_pct)
    val = float(centres[val_idx] - bin_size / 2.0)
    vah = float(centres[vah_idx] + bin_size / 2.0)

    peak = float(vols.max())
    lvns = _find_lvns(centres, vols, peak, lvn_threshold)
    hvns = _find_hvns(centres, vols, peak, hvn_threshold, poc)

    return VolumeProfile(
        prices=centres, volumes=vols, poc=poc, vah=vah, val=val,
        total_volume=total, bin_size=bin_size, lvns=lvns, hvns=hvns,
    )


def build_profile_from_trades(
    trades: pd.DataFrame,
    tick_size: float = 0.25,
    row_size_ticks: int = 4,
    value_area_pct: float = 0.70,
    lvn_threshold: float = 0.30,
    hvn_threshold: float = 0.80,
) -> VolumeProfile | None:
    """
    Build a profile from actual trades — price and size per execution.

    Strictly better than the bar approximation, because volume lands where
    it truly traded. Requires columns `price` and `size`. Feed it the tape
    captured by record_flow.py.
    """
    if trades is None or len(trades) == 0:
        return None

    px = trades["price"].to_numpy(dtype=float)
    sz = trades["size"].to_numpy(dtype=float)
    mask = np.isfinite(px) & np.isfinite(sz) & (sz > 0)
    px, sz = px[mask], sz[mask]
    if px.size == 0:
        return None

    lo, hi = float(px.min()), float(px.max())
    bin_size = tick_size * row_size_ticks
    n_bins = max(int(np.ceil((hi - lo) / bin_size)) + 1, 2)
    edges = lo + np.arange(n_bins + 1) * bin_size
    centres = edges[:-1] + bin_size / 2.0

    idx = np.clip(((px - lo) // bin_size).astype(int), 0, n_bins - 1)
    vols = np.bincount(idx, weights=sz, minlength=n_bins).astype(float)

    total = float(vols.sum())
    if total <= 0:
        return None

    poc_idx = int(np.argmax(vols))
    poc = float(centres[poc_idx])
    val_idx, vah_idx = _value_area(vols, poc_idx, value_area_pct)

    peak = float(vols.max())
    return VolumeProfile(
        prices=centres, volumes=vols, poc=poc,
        vah=float(centres[vah_idx] + bin_size / 2.0),
        val=float(centres[val_idx] - bin_size / 2.0),
        total_volume=total, bin_size=bin_size,
        lvns=_find_lvns(centres, vols, peak, lvn_threshold),
        hvns=_find_hvns(centres, vols, peak, hvn_threshold, poc),
    )


# ----------------------------------------------------------------------
# Internals
# ----------------------------------------------------------------------

def _value_area(vols: np.ndarray, poc_idx: int, target_pct: float) -> tuple[int, int]:
    """
    Grow outward from the POC until the target share of volume is enclosed.

    The standard Market Profile method: at each step compare the two bins
    immediately above and below the current area, and take the larger. That
    is why the value area is usually asymmetric around the POC.
    """
    total = vols.sum()
    target = total * target_pct

    lower = upper = poc_idx
    captured = vols[poc_idx]
    n = len(vols)

    while captured < target and (lower > 0 or upper < n - 1):
        below = vols[lower - 1] if lower > 0 else -1.0
        above = vols[upper + 1] if upper < n - 1 else -1.0

        if above >= below:
            upper += 1
            captured += vols[upper]
        else:
            lower -= 1
            captured += vols[lower]

    return lower, upper


def _find_lvns(centres, vols, peak, threshold) -> list:
    """
    Low volume nodes: local minima below `threshold` of peak volume.

    These are prices the market rejected. Price travels through them
    quickly, which makes them poor profit targets and useful breakout
    triggers.
    """
    out = []
    for i in range(1, len(vols) - 1):
        if vols[i] >= peak * threshold:
            continue
        if vols[i] <= vols[i - 1] and vols[i] <= vols[i + 1]:
            out.append(float(centres[i]))
    return out


def _find_hvns(centres, vols, peak, threshold, poc) -> list:
    """High volume nodes: local maxima above `threshold`, excluding the POC."""
    out = []
    for i in range(1, len(vols) - 1):
        if vols[i] < peak * threshold:
            continue
        if vols[i] >= vols[i - 1] and vols[i] >= vols[i + 1]:
            price = float(centres[i])
            if abs(price - poc) > 1e-9:
                out.append(price)
    return out


# ----------------------------------------------------------------------
# Session context
# ----------------------------------------------------------------------

@dataclass
class SessionContext:
    """
    Direction filter: is the day balanced or imbalanced, and which way?

    Balanced days rotate around value and reward fading the edges.
    Imbalanced days trend and punish fading. Trading the wrong mode is a
    more expensive mistake than a bad entry.
    """

    profile: VolumeProfile
    vwap: float
    cvd: float
    opening_price: float
    current_price: float

    @property
    def is_balanced(self) -> bool:
        """Price inside value and the profile not badly skewed."""
        if not self.profile.is_inside_value(self.current_price):
            return False
        width = self.profile.value_area_width
        if width <= 0:
            return False
        # The value area grows asymmetrically by construction (it takes the
        # heavier side at each step), so a modest skew is normal. <= keeps
        # the exact-threshold case on the balanced side.
        skew = abs(self.profile.poc - (self.profile.vah + self.profile.val) / 2)
        return skew <= width * 0.25

    @property
    def bias(self) -> int:
        """+1 bullish, -1 bearish, 0 none. Requires VWAP and CVD to agree."""
        above_vwap = self.current_price > self.vwap
        if above_vwap and self.cvd > 0:
            return 1
        if not above_vwap and self.cvd < 0:
            return -1
        return 0

    def summary(self) -> dict:
        return {
            "mode": "balanced" if self.is_balanced else "imbalanced",
            "bias": self.bias,
            "position": self.profile.position(self.current_price),
            "vwap": round(self.vwap, 2),
            "cvd": round(self.cvd, 1),
            **self.profile.summary(),
        }
