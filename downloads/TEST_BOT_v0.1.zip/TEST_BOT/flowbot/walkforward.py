"""
Walk-forward testing — the machinery that tells you whether an edge is real.

THE PROBLEM THIS SOLVES

Give any strategy enough parameters and enough history, and you can always
find settings that made money on that history. Those settings are usually
fitted to noise. The backtest looks superb and the live account bleeds.

Walk-forward analysis breaks that. Split the history into consecutive
blocks. Optimise on block N (in-sample), then test the winning parameters
on block N+1 (out-of-sample) WITHOUT re-optimising. Roll forward. Repeat.

The out-of-sample results are the only ones that mean anything, because
the optimiser never saw that data. If in-sample looks brilliant and
out-of-sample is flat, the edge was fitted. That is not a disappointing
result — it is the harness doing its job, and it costs you nothing but
compute instead of evaluation fees.

WHAT A GOOD RESULT LOOKS LIKE

    walk-forward efficiency  = OOS return / IS return

Above ~0.5 suggests the edge survives out of sample. Below ~0.3 means you
fitted noise. And consistency across windows matters more than the average:
one spectacular window among five poor ones is not an edge, it is a lucky
month.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass, field

import numpy as np
import pandas as pd


@dataclass
class Window:
    """One in-sample / out-of-sample pair."""

    index: int
    is_start: object
    is_end: object
    oos_start: object
    oos_end: object
    best_params: dict = field(default_factory=dict)
    is_metrics: dict = field(default_factory=dict)
    oos_metrics: dict = field(default_factory=dict)


@dataclass
class WalkForwardResult:
    windows: list
    metric: str

    @property
    def oos_values(self) -> list:
        return [w.oos_metrics.get(self.metric, 0.0) for w in self.windows]

    @property
    def is_values(self) -> list:
        return [w.is_metrics.get(self.metric, 0.0) for w in self.windows]

    @property
    def efficiency(self) -> float:
        """Out-of-sample performance as a fraction of in-sample."""
        is_total = sum(self.is_values)
        if is_total <= 0:
            return 0.0
        return sum(self.oos_values) / is_total

    @property
    def consistency(self) -> float:
        """Share of out-of-sample windows that were profitable."""
        vals = self.oos_values
        if not vals:
            return 0.0
        return sum(1 for v in vals if v > 0) / len(vals)

    @property
    def verdict(self) -> str:
        eff, cons = self.efficiency, self.consistency
        if not self.windows:
            return "NO DATA"
        if eff >= 0.5 and cons >= 0.6:
            return "PLAUSIBLE EDGE — worth forward testing"
        if eff >= 0.3 and cons >= 0.5:
            return "WEAK — not enough to fund an evaluation"
        return "OVERFIT — in-sample results did not survive"

    def report(self) -> str:
        lines = [
            "=" * 70,
            f"WALK-FORWARD ANALYSIS — metric: {self.metric}",
            "=" * 70,
            "",
            f"{'win':>4} {'in-sample':>12} {'out-sample':>12}  parameters",
            "-" * 70,
        ]
        for w in self.windows:
            lines.append(
                f"{w.index:>4} "
                f"{w.is_metrics.get(self.metric, 0):>12.2f} "
                f"{w.oos_metrics.get(self.metric, 0):>12.2f}  "
                f"{_fmt_params(w.best_params)}"
            )
        lines += [
            "-" * 70,
            f"{'':>4} {sum(self.is_values):>12.2f} {sum(self.oos_values):>12.2f}",
            "",
            f"  walk-forward efficiency : {self.efficiency:.2f}",
            f"  windows profitable OOS  : {self.consistency:.0%}",
            "",
            f"  VERDICT: {self.verdict}",
            "=" * 70,
        ]
        return "\n".join(lines)


def _fmt_params(p: dict) -> str:
    return ", ".join(f"{k}={v}" for k, v in sorted(p.items()))


def make_windows(
    df: pd.DataFrame,
    n_windows: int = 5,
    is_fraction: float = 0.7,
) -> list[tuple]:
    """
    Split a DataFrame into rolling in-sample / out-of-sample blocks.

    Splits on SESSION boundaries, never mid-day, so a window never begins
    halfway through a trading session.
    """
    if "session" not in df.columns:
        raise ValueError("df needs a 'session' column")

    sessions = sorted(df["session"].unique())
    if len(sessions) < n_windows * 3:
        raise ValueError(
            f"need at least {n_windows * 3} sessions for {n_windows} windows, "
            f"got {len(sessions)}"
        )

    block = len(sessions) // n_windows
    is_len = max(int(block * is_fraction), 1)

    out = []
    for i in range(n_windows):
        start = i * block
        is_sessions = sessions[start : start + is_len]
        oos_sessions = sessions[start + is_len : start + block]
        if not is_sessions or not oos_sessions:
            continue
        out.append((i, is_sessions, oos_sessions))
    return out


def grid(**kwargs) -> list[dict]:
    """Cartesian product of parameter options. grid(a=[1,2], b=[3,4])."""
    keys = list(kwargs.keys())
    return [dict(zip(keys, combo)) for combo in itertools.product(*kwargs.values())]


def walk_forward(
    df: pd.DataFrame,
    param_grid: list[dict],
    run_fn,
    metric: str = "net_profit",
    n_windows: int = 5,
    is_fraction: float = 0.7,
    min_trades: int = 10,
    verbose: bool = True,
) -> WalkForwardResult:
    """
    Run the full analysis.

    run_fn(df_slice, params) -> dict of metrics, which must include `metric`
    and "n_trades".

    A parameter set that produced fewer than `min_trades` in-sample is
    ignored, because a strategy that took four trades and won three is not
    a strategy, it is a coin landing well.
    """
    windows_spec = make_windows(df, n_windows, is_fraction)
    results = []

    for idx, is_sessions, oos_sessions in windows_spec:
        is_df = df[df["session"].isin(is_sessions)]
        oos_df = df[df["session"].isin(oos_sessions)]

        best_params, best_score, best_is = None, -np.inf, {}

        for params in param_grid:
            try:
                m = run_fn(is_df, params)
            except Exception:
                continue
            if m.get("n_trades", 0) < min_trades:
                continue
            score = m.get(metric, -np.inf)
            if score > best_score:
                best_params, best_score, best_is = params, score, m

        if best_params is None:
            if verbose:
                print(f"  window {idx}: no parameter set produced "
                      f"{min_trades}+ trades in sample")
            continue

        # The critical line: run OOS with the winning params, no re-fit.
        try:
            oos_metrics = run_fn(oos_df, best_params)
        except Exception:
            oos_metrics = {metric: 0.0, "n_trades": 0}

        w = Window(
            index=idx,
            is_start=is_sessions[0], is_end=is_sessions[-1],
            oos_start=oos_sessions[0], oos_end=oos_sessions[-1],
            best_params=best_params, is_metrics=best_is, oos_metrics=oos_metrics,
        )
        results.append(w)

        if verbose:
            print(f"  window {idx}: IS {best_is.get(metric, 0):>9.2f} "
                  f"-> OOS {oos_metrics.get(metric, 0):>9.2f}  "
                  f"({_fmt_params(best_params)})")

    return WalkForwardResult(windows=results, metric=metric)


def permutation_test(
    observed: float,
    trade_pnls: list,
    n_permutations: int = 2_000,
    seed: int = 42,
) -> dict:
    """
    Could this result have happened by chance?

    Shuffles the signs of the trade P&Ls to build a null distribution of
    "same trades, no directional skill", then asks where the observed
    result sits in it. A p-value above 0.05 means the result is
    indistinguishable from luck.

    This is the same discipline as the survivorship demo from bot #1:
    an impressive number is not evidence until you know what an unskilled
    version of it looks like.
    """
    if not trade_pnls:
        return {"p_value": 1.0, "observed": observed, "n": 0}

    rng = np.random.default_rng(seed)
    mags = np.abs(np.array(trade_pnls, dtype=float))

    null = np.empty(n_permutations)
    for i in range(n_permutations):
        signs = rng.choice([-1.0, 1.0], size=mags.size)
        null[i] = float((mags * signs).sum())

    p = float((null >= observed).mean())
    return {
        "p_value": round(p, 4),
        "observed": round(observed, 2),
        "null_mean": round(float(null.mean()), 2),
        "null_p95": round(float(np.percentile(null, 95)), 2),
        "n_trades": len(trade_pnls),
        "significant": p < 0.05,
    }
