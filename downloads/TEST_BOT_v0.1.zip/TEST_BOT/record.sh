#!/bin/bash
cd "$(dirname "$0")"
if [ ! -d .venv ]; then echo "Run setup first."; exit 1; fi
.venv/bin/python record_flow.py --symbol MES --out data/flow
