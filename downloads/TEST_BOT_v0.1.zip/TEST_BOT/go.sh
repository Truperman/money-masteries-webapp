#!/bin/bash
cd "$(dirname "$0")"
if [ ! -d .venv ]; then echo "Run setup first."; exit 1; fi
if [ ! -f .env ]; then echo "No credentials. Run setup first."; exit 1; fi
.venv/bin/python run_live.py "$@"
