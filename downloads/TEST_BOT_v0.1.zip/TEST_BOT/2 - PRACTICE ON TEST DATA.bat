@echo off
cd /d "%~dp0"
echo TEST BOT - STEP 2 - PRACTICE
echo.
if not exist .venv ( echo Run file number 1 first. & pause & exit /b 1 )
.venv\Scripts\python practice.py --days 120 --windows 3
echo.
pause
