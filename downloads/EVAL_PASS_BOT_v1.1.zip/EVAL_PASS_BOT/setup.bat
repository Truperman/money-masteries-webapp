@echo off
cd /d "%~dp0"
setlocal
echo.
echo ================================================================
echo    EVAL PASS BOT - Automatic Setup
echo ================================================================
echo.
set PY=
for %%P in (python python3 py) do (
  %%P -c "import sys; sys.exit(0 if sys.version_info>=(3,9) else 1)" >nul 2>&1
  if not errorlevel 1 ( set PY=%%P & goto found )
)
echo   Python is not installed, or was not added to PATH.
echo.
echo   Opening the download page...
echo.
echo   IMPORTANT: during the install, TICK the box that says
echo   "Add Python to PATH". Nearly every problem comes from that.
echo.
start "" "https://www.python.org/downloads/"
echo   Install it, then double-click this file again.
pause
exit /b 1
:found
%PY% setup_wizard.py
pause
