# EVAL PASS BOT  v1.0

A futures trading bot built to pass the Topstep $50K Trading Combine.

A futures trading bot framework built specifically against Topstep's
$50K Trading Combine rules, for MES (Micro E-mini S&P 500).

## What this is and is not

**It is** a correct, tested implementation of Topstep's rule set, a
pessimistic backtest engine, three strategy implementations, and a Monte
Carlo tool that tells you exactly what edge the rules demand.

**It is not** a profitable strategy. Nobody can hand you one. What this
does is make sure that *if* you find an edge, the risk layer will not throw
it away — and it tells you how big that edge has to be.

Read `REPORT.md` before you do anything else.

## Install

```bash
pip install pandas numpy requests
python3 tests/test_rules.py      # 16/16 must pass
python3 run_evaluation.py        # full evaluation
```

## Layout

```
topstep/
  rules.py        Combine rule engine — MLL, DLL, consistency, sizing
  data.py         CSV loader + calibrated synthetic generator
  strategies.py   Opening range breakout, trend pullback, VWAP fade
  backtest.py     Event-driven engine, pessimistic fills
  montecarlo.py   Required-edge analysis (the useful part)
  live.py         TopstepX / ProjectX execution adapter
tests/
  test_rules.py   Proves the rule engine matches Topstep's documented spec
run_evaluation.py Runs everything
```

## The rules, as implemented

$50K Combine, verified against Topstep's help center August 2026:

| Parameter | Value |
|---|---|
| Profit target | $3,000 |
| Maximum Loss Limit | $2,000 (starts at $48,000) |
| Daily Loss Limit | $1,000 |
| Max position | 5 contracts / 50 micros |
| Consistency | best day ≤ 50% of total profit |
| Minimum trading days | 2 |
| Session | 5:00 PM – 3:10 PM CT |

Three mechanics matter more than the rest:

1. **The MLL trails on end-of-day balance and never moves down.** It locks
   permanently once it reaches $50,000. Intraday gains do not raise it, but
   intraday losses can breach it. That asymmetry is the whole game.

2. **The MLL is monitored against unrealized P&L.** An open position that
   never gets closed can still fail the account. Stops must be attached at
   entry, not managed afterward.

3. **A losing day does not reset your best day** for consistency purposes.
   One oversized winner early can force you to grind out far more total
   profit than the nominal $3,000 target.

## Getting real data

The synthetic generator exists to exercise the engine. Any result it
produces about profitability is meaningless — the data is a random walk
with regimes I invented.

Easiest path, once you have API access:

```bash
pip install requests
# create .env with TOPSTEP_USERNAME and TOPSTEP_API_KEY
python3 fetch_data.py --days 365 --out mes_1min.csv
python3 run_evaluation.py --csv mes_1min.csv
```

`fetch_data.py` runs on your machine, pages through the history endpoint in
windows (20,000 bars max per request), converts timestamps to US/Central,
and writes the exact CSV format the loader expects.

Other sources, if you'd rather not subscribe yet: a chart export from
NinjaTrader, Tradovate or TradingView; Firstrate Data (cheap); Databento
GLBX.MDP3 (best quality, paid).

Any CSV works as long as it has `timestamp,open,high,low,close,volume` with
timestamps in **US Central** — the rule engine defines sessions in Central,
so UTC input silently misplaces every session boundary.

## Credentials

Keep `TOPSTEP_USERNAME` and `TOPSTEP_API_KEY` in a `.env` file that is in
your `.gitignore`. That key can place and cancel real orders. Do not paste
it into a chat, a commit, a screenshot, or an issue.

Nothing in this project needs your key to leave your machine — and since
Topstep prohibits remote servers, the bot has to run locally anyway.

## Evaluation mode

`topstep/evaluation.py` optimizes for **passing**, not profit. The Combine
has no time limit, so the objective is "reach $3,000 without ever touching
the floor, however long it takes" — not "make $3,000 fast."

Practical consequences, all measured:

- **Risk $75–100 per trade, not $150.** With no deadline, smaller size
  converts an 87% pass rate into 99%+. It costs a few extra months of
  subscription at $49/month.
- **Stop the instant you pass.** Every trade after that is pure downside.
- **Cap daily profit at ~$1,350.** Keeps the best-day consistency ratio
  under 50% without ever having to think about it.
- **Stop for the day after 3 consecutive losses**, and at −$500 rather than
  riding Topstep's −$1,000 daily limit.

```python
from topstep.evaluation import PassPolicy, compare_policies
compare_policies(win_rate=0.42, reward_risk=2.0)
```

## The API

Access costs **$29/month, or $14.50 with code `topstep`**. Enable it in
TopstepX under Settings → API, which links to ProjectX.

| Purpose | Endpoint |
|---|---|
| Base | `https://api.topstepx.com` |
| Authenticate | `POST /api/Auth/loginKey` |
| Accounts | `POST /api/Account/search` |
| Contracts | `POST /api/Contract/search` |
| Place order | `POST /api/Order/place` |
| Open positions | `POST /api/Position/searchOpen` |
| Realtime user hub | `wss://rtc.topstepx.com/hubs/user` |
| Realtime market hub | `wss://rtc.topstepx.com/hubs/market` |

Docs: <https://gateway.docs.projectx.com/>

**Bracket orders take ticks from entry, not prices** — `{"ticks": 40,
"type": 4}`. Passing a price creates a stop thousands of ticks away, i.e. an
unprotected position. `live.py` converts and validates this for you.

**VPS, VPN and remote servers are prohibited.** Topstep's API page: "All
trading activity must originate from your personal device." Build a
supervised session you start and stop, not an unattended cloud service.

## Going live

`topstep/live.py` wraps the ProjectX Gateway API. There is no sandbox, and
orders are final.

```python
from topstep.live import LiveConfig, ProjectXClient, LiveTrader
from topstep.rules import MES

cfg = LiveConfig(account_id="...", dry_run=True)   # keep dry_run True
trader = LiveTrader(ProjectXClient(cfg), MES)
trader.sync_from_broker()
```

Every order goes through `LiveTrader.submit()`, which routes to the same
rule engine the backtest uses. There is no path around it.

### Before you enable live orders

- [ ] Confirm **in writing** with Topstep support that unattended
      automation and your hosting setup are allowed. Third-party sources
      report that bots must be actively monitored and that VPS/VPN use is
      prohibited. Getting this wrong forfeits the account, and no amount of
      good code fixes a rules violation.
- [ ] Run `dry_run=True` against live data for at least two weeks.
- [ ] Test `client.flatten_all()` manually and confirm it works.
- [ ] Verify the front-month `contract_id` — it rolls quarterly.
- [ ] Confirm your strategy has a real edge on real data. This framework
      will faithfully execute a losing strategy.

## License

Yours. No warranty. Trading futures involves substantial risk of loss.
