"""
Topstep Trading Combine rule engine.

Encodes the $50K/$100K/$150K Combine and Express Funded Account constraints
as HARD limits. Every order the strategy wants to place is checked against
this engine first. If the engine says no, the trade does not happen.

Rule sources (Topstep help center, verified 2026-08):
  - Maximum Loss Limit: trails on END-OF-DAY balance, never moves down,
    locks permanently once it reaches the starting account size. Monitored
    in real time intraday against BOTH realized and unrealized P&L.
  - Daily Loss Limit: fixed per account size. On breach, positions are
    flattened and no new trades until the next session (5 PM CT).
  - Consistency (Combine): best day profit / total profit must be <= 50%.
  - Session: 5:00 PM CT -> 3:10 PM CT next day. Daily reset at 5 PM CT.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, time
from enum import Enum


class AccountState(Enum):
    ACTIVE = "active"
    PASSED = "passed"
    FAILED_MLL = "failed_max_loss_limit"
    LOCKED_OUT_DAILY = "locked_out_daily_loss"


@dataclass(frozen=True)
class CombineSpec:
    """Immutable parameters for one Combine size."""

    name: str
    starting_balance: float
    profit_target: float
    max_loss_limit: float       # dollars below starting balance
    daily_loss_limit: float
    max_contracts_standard: int
    max_contracts_micro: int
    consistency_pct: float = 0.50   # best day must be <= this share of total
    min_trading_days: int = 2

    @property
    def target_balance(self) -> float:
        return self.starting_balance + self.profit_target

    @property
    def initial_mll(self) -> float:
        return self.starting_balance - self.max_loss_limit

    @property
    def max_best_day(self) -> float:
        """Largest single-day profit that still satisfies consistency."""
        return self.profit_target * self.consistency_pct


COMBINE_50K = CombineSpec(
    name="$50K Combine",
    starting_balance=50_000.0,
    profit_target=3_000.0,
    max_loss_limit=2_000.0,
    daily_loss_limit=1_000.0,
    max_contracts_standard=5,
    max_contracts_micro=50,
)

COMBINE_100K = CombineSpec(
    name="$100K Combine",
    starting_balance=100_000.0,
    profit_target=6_000.0,
    max_loss_limit=3_000.0,
    daily_loss_limit=2_000.0,
    max_contracts_standard=10,
    max_contracts_micro=100,
)

COMBINE_150K = CombineSpec(
    name="$150K Combine",
    starting_balance=150_000.0,
    profit_target=9_000.0,
    max_loss_limit=4_500.0,
    daily_loss_limit=3_000.0,
    max_contracts_standard=15,
    max_contracts_micro=150,
)

SPECS = {"50k": COMBINE_50K, "100k": COMBINE_100K, "150k": COMBINE_150K}

# Session boundaries, US Central Time.
SESSION_OPEN = time(17, 0)    # 5:00 PM CT — new trading day begins
SESSION_CLOSE = time(15, 10)  # 3:10 PM CT — hard flat
RTH_OPEN = time(8, 30)        # 8:30 AM CT — regular cash open
RTH_CLOSE = time(15, 0)       # 3:00 PM CT


def trading_day(ts: datetime) -> datetime.date:
    """
    Map a timestamp to its Topstep trading day.

    The trading day rolls at 5 PM CT, so anything at or after 17:00 belongs
    to the NEXT calendar day's session.
    """
    from datetime import timedelta

    if ts.time() >= SESSION_OPEN:
        return (ts + timedelta(days=1)).date()
    return ts.date()


@dataclass
class RuleViolation:
    """Raised as data, not an exception — the engine reports, caller reacts."""

    rule: str
    detail: str
    timestamp: datetime | None = None


@dataclass
class TopstepAccount:
    """
    Live state machine for one Combine account.

    Usage per bar:
        acct.mark(timestamp, unrealized_pnl)   # checks MLL in real time
        if acct.can_trade(timestamp): ...      # gate new entries
        acct.on_fill(pnl)                      # record a closed trade
        acct.end_of_day(timestamp)             # trail the MLL
    """

    spec: CombineSpec
    balance: float = field(init=False)
    mll: float = field(init=False)
    state: AccountState = field(init=False, default=AccountState.ACTIVE)

    day_pnl: float = field(init=False, default=0.0)
    current_day: object = field(init=False, default=None)
    daily_pnls: dict = field(init=False, default_factory=dict)
    violations: list = field(init=False, default_factory=list)
    peak_equity: float = field(init=False)

    def __post_init__(self) -> None:
        self.balance = self.spec.starting_balance
        self.mll = self.spec.initial_mll
        self.peak_equity = self.spec.starting_balance

    # ------------------------------------------------------------------
    # Real-time monitoring
    # ------------------------------------------------------------------

    def equity(self, unrealized: float = 0.0) -> float:
        return self.balance + unrealized

    def mark(self, ts: datetime, unrealized: float = 0.0) -> RuleViolation | None:
        """
        Mark to market. This is the intraday MLL check.

        Topstep monitors the MLL in real time against realized AND unrealized
        P&L, so an open position moving against you can fail the account even
        if you never close it at that price. This is the #1 cause of failure
        and the reason stops must be hard-coded, not mental.
        """
        eq = self.equity(unrealized)
        self.peak_equity = max(self.peak_equity, eq)

        if eq <= self.mll:
            self.state = AccountState.FAILED_MLL
            v = RuleViolation(
                rule="max_loss_limit",
                detail=f"equity {eq:,.2f} touched MLL {self.mll:,.2f}",
                timestamp=ts,
            )
            self.violations.append(v)
            return v
        return None

    def can_trade(self, ts: datetime) -> bool:
        """Gate for opening a NEW position."""
        if self.state in (AccountState.FAILED_MLL, AccountState.PASSED):
            return False

        self._roll_day_if_needed(ts)

        if self.state is AccountState.LOCKED_OUT_DAILY:
            return False

        # No new entries inside the last few minutes before the hard flat.
        t = ts.time()
        if SESSION_CLOSE <= t < SESSION_OPEN:
            return False

        return True

    def must_flatten(self, ts: datetime) -> bool:
        """True when any open position has to be closed right now."""
        if self.state in (AccountState.FAILED_MLL, AccountState.LOCKED_OUT_DAILY):
            return True
        t = ts.time()
        return SESSION_CLOSE <= t < SESSION_OPEN

    # ------------------------------------------------------------------
    # Fills and day accounting
    # ------------------------------------------------------------------

    def on_fill(self, ts: datetime, pnl: float) -> RuleViolation | None:
        """Record a CLOSED trade's realized P&L."""
        self._roll_day_if_needed(ts)

        self.balance += pnl
        self.day_pnl += pnl
        self.daily_pnls[self.current_day] = self.day_pnl

        # Daily loss limit — flatten and stand down for the session.
        if self.day_pnl <= -self.spec.daily_loss_limit:
            self.state = AccountState.LOCKED_OUT_DAILY
            v = RuleViolation(
                rule="daily_loss_limit",
                detail=f"day P&L {self.day_pnl:,.2f} hit DLL "
                       f"-{self.spec.daily_loss_limit:,.2f}",
                timestamp=ts,
            )
            self.violations.append(v)
            return v
        return None

    def _roll_day_if_needed(self, ts: datetime) -> None:
        day = trading_day(ts)
        if self.current_day is None:
            self.current_day = day
            return
        if day != self.current_day:
            self.end_of_day(ts)
            self.current_day = day
            self.day_pnl = 0.0
            if self.state is AccountState.LOCKED_OUT_DAILY:
                self.state = AccountState.ACTIVE

    def end_of_day(self, ts: datetime) -> None:
        """
        Trail the MLL.

        The MLL rises with the END-OF-DAY balance and never falls. It stops
        trailing once it reaches the starting account size, then locks there
        permanently. Note the asymmetry: intraday gains do NOT raise the MLL,
        but intraday losses can breach it.
        """
        if self.current_day is not None:
            self.daily_pnls[self.current_day] = self.day_pnl

        candidate = self.balance - self.spec.max_loss_limit
        self.mll = min(max(self.mll, candidate), self.spec.starting_balance)

    # ------------------------------------------------------------------
    # Pass evaluation
    # ------------------------------------------------------------------

    @property
    def total_profit(self) -> float:
        return self.balance - self.spec.starting_balance

    @property
    def winning_days(self) -> dict:
        return {d: p for d, p in self.daily_pnls.items() if p > 0}

    @property
    def best_day(self) -> float:
        wins = self.winning_days
        return max(wins.values()) if wins else 0.0

    @property
    def consistency(self) -> float:
        """Best day as a share of total profit. Lower is better."""
        if self.total_profit <= 0:
            return float("inf")
        return self.best_day / self.total_profit

    def evaluate(self) -> dict:
        """Full pass/fail report against every Combine objective."""
        days_traded = len([d for d, p in self.daily_pnls.items() if p != 0])

        checks = {
            "profit_target": self.total_profit >= self.spec.profit_target,
            "no_mll_breach": self.state is not AccountState.FAILED_MLL,
            "consistency": self.consistency <= self.spec.consistency_pct,
            "min_trading_days": days_traded >= self.spec.min_trading_days,
        }

        return {
            "passed": all(checks.values()),
            "checks": checks,
            "balance": self.balance,
            "total_profit": self.total_profit,
            "best_day": self.best_day,
            "consistency": self.consistency,
            "days_traded": days_traded,
            "final_mll": self.mll,
            "state": self.state.value,
            "violations": [
                {"rule": v.rule, "detail": v.detail, "ts": str(v.timestamp)}
                for v in self.violations
            ],
        }


# ----------------------------------------------------------------------
# Position sizing
# ----------------------------------------------------------------------

@dataclass(frozen=True)
class Instrument:
    symbol: str
    tick_size: float
    tick_value: float
    commission_per_side: float

    def pnl(self, entry: float, exit_: float, contracts: int, is_long: bool) -> float:
        direction = 1 if is_long else -1
        ticks = (exit_ - entry) / self.tick_size * direction
        gross = ticks * self.tick_value * contracts
        return gross - 2 * self.commission_per_side * contracts


# Commissions are round-turn-ish retail estimates via Topstep's platforms.
MES = Instrument("MES", tick_size=0.25, tick_value=1.25, commission_per_side=0.37)
MNQ = Instrument("MNQ", tick_size=0.25, tick_value=0.50, commission_per_side=0.37)
ES = Instrument("ES", tick_size=0.25, tick_value=12.50, commission_per_side=1.40)
NQ = Instrument("NQ", tick_size=0.25, tick_value=5.00, commission_per_side=1.40)

INSTRUMENTS = {"MES": MES, "MNQ": MNQ, "ES": ES, "NQ": NQ}


def size_position(
    account: TopstepAccount,
    instrument: Instrument,
    stop_ticks: float,
    risk_per_trade: float,
    use_micros: bool = True,
) -> int:
    """
    Contracts to trade, sized so a full stop-out costs ~risk_per_trade.

    Then clamped three ways:
      1. Topstep's max position size for the account.
      2. The remaining distance to the MLL — never risk more than is left.
      3. The remaining room before the daily loss limit.

    Clamp #2 is what keeps a losing streak from ending the account: as the
    buffer shrinks, so does size, automatically.
    """
    if stop_ticks <= 0:
        return 0

    risk_per_contract = stop_ticks * instrument.tick_value
    if risk_per_contract <= 0:
        return 0

    contracts = int(risk_per_trade // risk_per_contract)

    cap = (
        account.spec.max_contracts_micro
        if use_micros
        else account.spec.max_contracts_standard
    )
    contracts = min(contracts, cap)

    # Never let one trade put the MLL in reach. Keep a 2x cushion.
    room_to_mll = account.balance - account.mll
    max_by_mll = int((room_to_mll / 2) // risk_per_contract)
    contracts = min(contracts, max_by_mll)

    # Respect what is left of today's loss limit.
    room_today = account.spec.daily_loss_limit + account.day_pnl
    max_by_day = int((room_today / 1.5) // risk_per_contract)
    contracts = min(contracts, max_by_day)

    return max(contracts, 0)
