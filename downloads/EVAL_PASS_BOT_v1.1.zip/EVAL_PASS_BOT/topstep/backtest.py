"""
Event-driven backtest engine.

Walks bars in order, hands each to the strategy, and routes every resulting
order through the Topstep rule engine. The engine is deliberately pessimistic:

  - Entries fill at the NEXT bar's open, not the signal bar's close.
  - Stops fill at the stop price or worse (gap-through fills at the open).
  - When a bar's range covers both the stop and the target, the STOP is
    assumed to hit first. Without tick data you cannot know the order, and
    assuming the good outcome is how backtests lie.
  - Slippage is charged on entry and exit.
  - Commissions are charged per side.
  - The MLL is marked against unrealized P&L on every single bar.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from .rules import (
    AccountState,
    CombineSpec,
    Instrument,
    TopstepAccount,
    size_position,
)
from .strategies import Signal, Strategy


@dataclass
class Position:
    is_long: bool
    entry_price: float
    contracts: int
    stop_price: float
    target_price: float
    entry_time: object
    reason: str = ""


@dataclass
class Trade:
    entry_time: object
    exit_time: object
    is_long: bool
    entry_price: float
    exit_price: float
    contracts: int
    pnl: float
    exit_reason: str


@dataclass
class BacktestResult:
    account: TopstepAccount
    trades: list = field(default_factory=list)
    equity_curve: list = field(default_factory=list)
    # Why signals never became trades. A backtest that silently drops 80%
    # of its signals looks like a low-frequency strategy instead of a bug.
    skips: dict = field(
        default_factory=lambda: {
            "zero_size": 0,      # position sizing rounded to zero
            "not_allowed": 0,    # rule engine blocked the entry
            "signals": 0,        # total signals the strategy produced
        }
    )

    @property
    def report(self) -> dict:
        r = self.account.evaluate()
        wins = [t for t in self.trades if t.pnl > 0]
        losses = [t for t in self.trades if t.pnl <= 0]
        gross_win = sum(t.pnl for t in wins)
        gross_loss = abs(sum(t.pnl for t in losses))

        r.update(
            {
                "n_trades": len(self.trades),
                "win_rate": len(wins) / len(self.trades) if self.trades else 0.0,
                "avg_win": gross_win / len(wins) if wins else 0.0,
                "avg_loss": -gross_loss / len(losses) if losses else 0.0,
                "profit_factor": (gross_win / gross_loss) if gross_loss > 0 else float("inf"),
                "expectancy": (
                    sum(t.pnl for t in self.trades) / len(self.trades)
                    if self.trades
                    else 0.0
                ),
            }
        )
        return r


def run_backtest(
    df: pd.DataFrame,
    strategy: Strategy,
    spec: CombineSpec,
    instrument: Instrument,
    risk_per_trade: float = 150.0,
    slippage_ticks: float = 1.0,
    use_micros: bool = True,
    stop_when_resolved: bool = True,
) -> BacktestResult:
    """
    Run one Combine attempt.

    stop_when_resolved: halt as soon as the account passes or fails, which
    is what actually happens in a real Combine.
    """
    account = TopstepAccount(spec)
    result = BacktestResult(account=account)

    position: Position | None = None
    pending: Signal | None = None
    current_session = None
    slip = slippage_ticks * instrument.tick_size

    bars = list(df.itertuples())

    for i, bar in enumerate(bars):
        ts = bar.Index.to_pydatetime()
        session = bar.session

        if session != current_session:
            current_session = session
            strategy.start_session(session)
            pending = None

        # --- 1. Mark open position to market. MLL is checked here. ---
        if position is not None:
            unreal = instrument.pnl(
                position.entry_price, bar.close, position.contracts, position.is_long
            )
            violation = account.mark(ts, unreal)
            if violation is not None:
                # Account is dead. Close at the current price for the record.
                position = _close(
                    result, account, instrument, position, ts, bar.close, "mll_breach"
                )
                break
        else:
            account.mark(ts, 0.0)

        if account.state is AccountState.FAILED_MLL:
            break

        # --- 2. Manage the open position: stop, target, forced flat. ---
        if position is not None:
            exit_price, reason = _check_exit(position, bar, slip)

            if exit_price is None and account.must_flatten(ts):
                exit_price, reason = bar.close, "session_flat"

            if exit_price is not None:
                position = _close(
                    result, account, instrument, position, ts, exit_price, reason
                )

        # --- 3. Fill a pending entry at this bar's open. ---
        if position is None and pending is not None:
            if account.can_trade(ts):
                entry = bar.open + (slip if pending.is_long else -slip)
                stop_ticks = abs(entry - pending.stop_price) / instrument.tick_size

                contracts = size_position(
                    account, instrument, stop_ticks, risk_per_trade, use_micros
                )
                if contracts > 0:
                    position = Position(
                        is_long=pending.is_long,
                        entry_price=entry,
                        contracts=contracts,
                        stop_price=pending.stop_price,
                        target_price=pending.target_price,
                        entry_time=ts,
                        reason=pending.reason,
                    )
                else:
                    result.skips["zero_size"] += 1
            else:
                result.skips["not_allowed"] += 1
            pending = None

        # --- 4. Ask the strategy for a new signal. ---
        if position is None and pending is None and account.can_trade(ts):
            history = df.iloc[max(0, i - 200) : i + 1]
            sig = strategy.on_bar(bar.Index, bar, history)
            if sig is not None:
                result.skips["signals"] += 1
                if i + 1 < len(bars):
                    pending = sig

        result.equity_curve.append(
            {
                "timestamp": ts,
                "balance": account.balance,
                "mll": account.mll,
                "session": session,
            }
        )

        if stop_when_resolved:
            if account.total_profit >= spec.profit_target and position is None:
                report = account.evaluate()
                if report["passed"]:
                    account.state = AccountState.PASSED
                    break

    # Final end-of-day so the last session's P&L is recorded.
    if bars:
        account.end_of_day(bars[-1].Index.to_pydatetime())

    return result


def _check_exit(pos: Position, bar, slip: float):
    """
    Decide whether this bar closes the position.

    Pessimistic ordering: if both the stop and target are inside the bar's
    range, the stop is assumed to have hit first.
    """
    if pos.is_long:
        if bar.low <= pos.stop_price:
            # Gap through the stop fills at the open, not the stop price.
            fill = min(pos.stop_price, bar.open) - slip
            return fill, "stop"
        if bar.high >= pos.target_price:
            fill = max(pos.target_price, bar.open) - slip
            return fill, "target"
    else:
        if bar.high >= pos.stop_price:
            fill = max(pos.stop_price, bar.open) + slip
            return fill, "stop"
        if bar.low <= pos.target_price:
            fill = min(pos.target_price, bar.open) + slip
            return fill, "target"
    return None, ""


def _close(result, account, instrument, pos, ts, price, reason):
    pnl = instrument.pnl(pos.entry_price, price, pos.contracts, pos.is_long)
    account.on_fill(ts, pnl)
    result.trades.append(
        Trade(
            entry_time=pos.entry_time,
            exit_time=ts,
            is_long=pos.is_long,
            entry_price=pos.entry_price,
            exit_price=price,
            contracts=pos.contracts,
            pnl=pnl,
            exit_reason=reason,
        )
    )
    return None
