"""
Order flow metrics.

Implements the microstructure signals that have actual evidence behind them,
and is explicit about which ones do not.

WHAT HAS EVIDENCE
    Order Flow Imbalance (OFI) — Cont, Kukanov & Stoikov, "The Price Impact
    of Order Book Events" (2010/2014). OFI is a linear predictor of
    short-horizon price change with a well-documented, replicated
    relationship. This is the strongest signal in this module.

    Book imbalance at the top of book — predictive of the next tick's
    direction at horizons measured in seconds.

WHAT IS WEAKER
    Cumulative Volume Delta — widely used, decays fast, and is trivially
    confounded by trade classification error. Useful as context, poor as a
    trigger.

    Absorption and exhaustion — popular in retail order flow education,
    thinly evidenced. Implemented here because they are cheap to compute and
    reasonable as filters, not because the literature supports them.

THE HORIZON PROBLEM — read this before using any of it
    Order flow edges decay in SECONDS. A pure order flow strategy is a
    scalping strategy, and Topstep explicitly prohibits "making hundreds of
    rapid trades to take advantage of preferential queue position in SIM"
    and "running scalping algorithms designed to exploit unrealistic SIM
    fills." The Combine runs in a simulated environment, so a strategy whose
    edge comes from queue position is both unbannable-to-verify and
    non-transferable to a live funded account.

    The usable approach is therefore order flow as CONFIRMATION on an entry
    whose thesis is bar-scale. You are not trading the imbalance. You are
    declining a breakout that the flow does not support. That keeps hold
    times in minutes, stays inside the rules, and survives the SIM-to-live
    transition.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field

import numpy as np


# ----------------------------------------------------------------------
# Event containers
# ----------------------------------------------------------------------

@dataclass(frozen=True)
class BookSnapshot:
    """Top-of-book state at a point in time."""

    timestamp: float
    bid_price: float
    bid_size: float
    ask_price: float
    ask_size: float

    @property
    def mid(self) -> float:
        return (self.bid_price + self.ask_price) / 2.0

    @property
    def spread(self) -> float:
        return self.ask_price - self.bid_price

    @property
    def imbalance(self) -> float:
        """
        Queue imbalance in [-1, 1]. Positive means bid-heavy.

        The most-cited short-horizon predictor in the microstructure
        literature: the side with the smaller queue is more likely to be
        consumed, so the price tends to move toward it.
        """
        total = self.bid_size + self.ask_size
        if total <= 0:
            return 0.0
        return (self.bid_size - self.ask_size) / total


@dataclass(frozen=True)
class TradeEvent:
    """A single execution with its inferred aggressor."""

    timestamp: float
    price: float
    size: float
    is_buy_aggressor: bool | None = None   # None = unknown, must classify

    def signed_size(self) -> float:
        if self.is_buy_aggressor is None:
            return 0.0
        return self.size if self.is_buy_aggressor else -self.size


# ----------------------------------------------------------------------
# Trade classification
# ----------------------------------------------------------------------

def classify_lee_ready(trade_price: float, book: BookSnapshot) -> bool | None:
    """
    Classify a trade's aggressor side using the quote rule.

    Trades at or above the ask are buyer-initiated; at or below the bid,
    seller-initiated. Inside the spread is genuinely ambiguous and returns
    None rather than a coin flip, because guessing here is the main source
    of noise in every delta-based metric.

    Prefer the venue's own aggressor flag when the feed provides one. CME
    does; use it and skip this entirely.
    """
    if trade_price >= book.ask_price:
        return True
    if trade_price <= book.bid_price:
        return False
    mid = book.mid
    if trade_price > mid:
        return True
    if trade_price < mid:
        return False
    return None


# ----------------------------------------------------------------------
# Order Flow Imbalance
# ----------------------------------------------------------------------

def ofi_increment(prev: BookSnapshot, curr: BookSnapshot) -> float:
    """
    One OFI term, per Cont, Kukanov & Stoikov.

        e_n =  I(P_bid_n >= P_bid_n-1) * q_bid_n
             - I(P_bid_n <= P_bid_n-1) * q_bid_n-1
             - I(P_ask_n <= P_ask_n-1) * q_ask_n
             + I(P_ask_n >= P_ask_n-1) * q_ask_n-1

    This counts liquidity ADDED on the bid and REMOVED from the ask as
    positive pressure, and captures price-level changes as well as size
    changes — which is why it beats a naive bid-minus-ask size difference.
    """
    e = 0.0

    if curr.bid_price >= prev.bid_price:
        e += curr.bid_size
    if curr.bid_price <= prev.bid_price:
        e -= prev.bid_size

    if curr.ask_price <= prev.ask_price:
        e -= curr.ask_size
    if curr.ask_price >= prev.ask_price:
        e += prev.ask_size

    return e


class OrderFlowState:
    """
    Rolling order flow metrics over a time window.

    Feed it book snapshots and trades as they arrive; read metrics whenever
    the strategy needs them. All windows are in seconds of wall clock, not
    event counts, so the metrics mean the same thing in fast and slow
    markets.
    """

    def __init__(self, window_seconds: float = 60.0):
        self.window = window_seconds
        self._books: deque[BookSnapshot] = deque()
        self._trades: deque[TradeEvent] = deque()
        self._ofi: deque[tuple[float, float]] = deque()   # (ts, increment)
        self._prev_book: BookSnapshot | None = None
        self.cumulative_delta: float = 0.0                # session-long

    # -- ingestion ----------------------------------------------------

    def on_book(self, book: BookSnapshot) -> None:
        if self._prev_book is not None:
            inc = ofi_increment(self._prev_book, book)
            self._ofi.append((book.timestamp, inc))
        self._prev_book = book
        self._books.append(book)
        self._expire(book.timestamp)

    def on_trade(self, trade: TradeEvent) -> None:
        if trade.is_buy_aggressor is None and self._prev_book is not None:
            side = classify_lee_ready(trade.price, self._prev_book)
            trade = TradeEvent(trade.timestamp, trade.price, trade.size, side)
        self._trades.append(trade)
        self.cumulative_delta += trade.signed_size()
        self._expire(trade.timestamp)

    def _expire(self, now: float) -> None:
        cutoff = now - self.window
        while self._books and self._books[0].timestamp < cutoff:
            self._books.popleft()
        while self._trades and self._trades[0].timestamp < cutoff:
            self._trades.popleft()
        while self._ofi and self._ofi[0][0] < cutoff:
            self._ofi.popleft()

    # -- metrics ------------------------------------------------------

    @property
    def ready(self) -> bool:
        """Enough data in the window for the metrics to mean anything."""
        return len(self._books) >= 10 and len(self._trades) >= 5

    @property
    def ofi(self) -> float:
        """Summed order flow imbalance over the window."""
        return float(sum(inc for _, inc in self._ofi))

    @property
    def normalized_ofi(self) -> float:
        """
        OFI scaled by its own recent volatility, so the number is
        comparable across sessions and instruments. Roughly a z-score.
        """
        if len(self._ofi) < 10:
            return 0.0
        vals = np.array([inc for _, inc in self._ofi], dtype=float)
        sd = vals.std()
        if sd <= 0:
            return 0.0
        return float(vals.sum() / (sd * np.sqrt(len(vals))))

    @property
    def delta(self) -> float:
        """Signed volume over the window. Positive = buyers lifting offers."""
        return float(sum(t.signed_size() for t in self._trades))

    @property
    def volume(self) -> float:
        return float(sum(t.size for t in self._trades))

    @property
    def delta_ratio(self) -> float:
        """Delta as a share of volume, in [-1, 1]."""
        v = self.volume
        return self.delta / v if v > 0 else 0.0

    @property
    def book_imbalance(self) -> float:
        """Average top-of-book imbalance over the window."""
        if not self._books:
            return 0.0
        return float(np.mean([b.imbalance for b in self._books]))

    @property
    def trade_intensity(self) -> float:
        """Trades per second over the window."""
        if not self._trades:
            return 0.0
        span = self._trades[-1].timestamp - self._trades[0].timestamp
        return len(self._trades) / span if span > 0 else 0.0

    @property
    def price_change(self) -> float:
        if len(self._books) < 2:
            return 0.0
        return self._books[-1].mid - self._books[0].mid

    def absorption(self, tick_size: float = 0.25) -> float:
        """
        Volume traded per tick of price movement.

        High absorption means heavy volume is being consumed without the
        price going anywhere — someone large is filling passively. Treat as
        a filter that argues AGAINST a breakout continuing, never as a
        standalone signal; the evidence here is anecdotal.
        """
        moved = abs(self.price_change) / tick_size
        if moved < 1.0:
            moved = 1.0
        return self.volume / moved

    def snapshot(self) -> dict:
        return {
            "ofi": round(self.ofi, 2),
            "normalized_ofi": round(self.normalized_ofi, 3),
            "delta": round(self.delta, 1),
            "delta_ratio": round(self.delta_ratio, 3),
            "book_imbalance": round(self.book_imbalance, 3),
            "trade_intensity": round(self.trade_intensity, 2),
            "volume": round(self.volume, 1),
            "cumulative_delta": round(self.cumulative_delta, 1),
            "ready": self.ready,
        }


# ----------------------------------------------------------------------
# Confirmation gate
# ----------------------------------------------------------------------

@dataclass
class FlowGate:
    """
    Turns order flow into a yes/no on a trade the STRATEGY already wants.

    This is the safe way to use microstructure inside a prop evaluation:
    the entry thesis comes from bar-scale structure, and flow only vetoes.
    Because it can only decline trades, it cannot invent a scalping
    strategy, and it cannot push hold times into the range Topstep flags.
    """

    min_normalized_ofi: float = 0.5
    min_delta_ratio: float = 0.15
    min_book_imbalance: float = 0.05
    require_all: bool = False        # False = majority vote
    max_absorption: float | None = None
    reasons: list = field(default_factory=list)

    def check(self, flow: OrderFlowState, is_long: bool,
              tick_size: float = 0.25) -> bool:
        """True if flow supports the intended direction."""
        self.reasons = []

        if not flow.ready:
            self.reasons.append("insufficient flow data")
            return False

        sign = 1.0 if is_long else -1.0
        votes = []

        ofi_ok = sign * flow.normalized_ofi >= self.min_normalized_ofi
        votes.append(ofi_ok)
        if not ofi_ok:
            self.reasons.append(
                f"OFI {flow.normalized_ofi:+.2f} does not support "
                f"{'long' if is_long else 'short'}"
            )

        delta_ok = sign * flow.delta_ratio >= self.min_delta_ratio
        votes.append(delta_ok)
        if not delta_ok:
            self.reasons.append(f"delta ratio {flow.delta_ratio:+.2f} too weak")

        book_ok = sign * flow.book_imbalance >= self.min_book_imbalance
        votes.append(book_ok)
        if not book_ok:
            self.reasons.append(
                f"book imbalance {flow.book_imbalance:+.2f} against"
            )

        if self.max_absorption is not None:
            absorbed = flow.absorption(tick_size)
            if absorbed > self.max_absorption:
                self.reasons.append(
                    f"absorption {absorbed:.0f} above {self.max_absorption:.0f}"
                    " — size is defending this level"
                )
                return False

        return all(votes) if self.require_all else sum(votes) >= 2
