"""
Live execution adapter for TopstepX (ProjectX Gateway API).

STATUS: scaffold. The endpoint paths and payload shapes below follow the
ProjectX Gateway conventions, but you MUST verify them against the current
docs before sending a live order. Topstep provides no sandbox — the API
trades your real evaluation account, and orders are final.

The important design point: this module cannot place an order that the rule
engine has not approved. `LiveTrader.submit()` routes everything through the
same TopstepAccount used in the backtest, so the risk logic you tested is
the risk logic that runs.

Before you run this:
  1. Confirm with Topstep support IN WRITING whether unattended automation
     and VPS hosting are permitted on your account. Third-party sources say
     bots must be actively monitored and that VPS/VPN is prohibited. Getting
     this wrong forfeits the account.
  2. Paper-trade the logic against live data with ORDERS DISABLED for at
     least two weeks (set dry_run=True).
  3. Verify the kill switch works before enabling real orders.
"""

from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone

from .rules import (
    COMBINE_50K,
    AccountState,
    CombineSpec,
    Instrument,
    TopstepAccount,
    size_position,
)

log = logging.getLogger("topstep.live")

# Verified against ProjectX Gateway docs, August 2026.
PROJECTX_BASE = os.environ.get("PROJECTX_BASE_URL", "https://api.topstepx.com")
USER_HUB = "https://rtc.topstepx.com/hubs/user"
MARKET_HUB = "https://rtc.topstepx.com/hubs/market"

# Order type enums (ProjectX).
ORDER_TYPE_LIMIT = 1
ORDER_TYPE_MARKET = 2
ORDER_TYPE_STOP = 4
ORDER_TYPE_TRAILING_STOP = 5

# Side enums. 0 = Bid (buy), 1 = Ask (sell).
SIDE_BUY = 0
SIDE_SELL = 1


class OrderRejected(Exception):
    """The rule engine refused the order. This is a success, not an error."""


@dataclass
class LiveConfig:
    username: str = field(default_factory=lambda: os.environ.get("TOPSTEP_USERNAME", ""))
    api_key: str = field(default_factory=lambda: os.environ.get("TOPSTEP_API_KEY", ""))
    account_id: str = field(default_factory=lambda: os.environ.get("TOPSTEP_ACCOUNT_ID", ""))
    contract_id: str = "CON.F.US.MES.Z26"   # verify the current front month
    risk_per_trade: float = 150.0
    dry_run: bool = True                     # NEVER default this to False
    max_daily_orders: int = 40               # runaway-loop backstop
    api_base: str = PROJECTX_BASE


class ProjectXClient:
    """
    Thin HTTP wrapper. Verify every path against current ProjectX docs.

    Deliberately minimal — this is the part most likely to change, and a
    thick abstraction over an API you have not tested is a liability.
    """

    def __init__(self, cfg: LiveConfig):
        self.cfg = cfg
        self._token: str | None = None
        self._token_ts: float = 0.0

    # -- auth ----------------------------------------------------------

    def authenticate(self) -> str:
        """POST /api/Auth/loginKey -> session token (cache it, it expires)."""
        import requests

        if self._token and (time.time() - self._token_ts) < 3_000:
            return self._token

        resp = requests.post(
            f"{PROJECTX_BASE}/api/Auth/loginKey",
            json={"userName": self.cfg.username, "apiKey": self.cfg.api_key},
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
        if not data.get("success"):
            raise RuntimeError(f"auth failed: {data}")

        self._token = data["token"]
        self._token_ts = time.time()
        return self._token

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.authenticate()}",
            "Content-Type": "application/json",
        }

    # -- account -------------------------------------------------------

    def get_account(self) -> dict:
        import requests

        resp = requests.post(
            f"{PROJECTX_BASE}/api/Account/search",
            json={"onlyActiveAccounts": True},
            headers=self._headers(),
            timeout=15,
        )
        resp.raise_for_status()
        return resp.json()

    def get_positions(self) -> list:
        import requests

        resp = requests.post(
            f"{PROJECTX_BASE}/api/Position/searchOpen",
            json={"accountId": self.cfg.account_id},
            headers=self._headers(),
            timeout=15,
        )
        resp.raise_for_status()
        return resp.json().get("positions", [])

    # -- orders --------------------------------------------------------

    def place_bracket(
        self,
        side: int,          # SIDE_BUY / SIDE_SELL
        size: int,
        stop_ticks: int,
        target_ticks: int,
    ) -> dict:
        """
        Market entry with attached stop and target.

        NOTE the units: ProjectX brackets are specified in TICKS FROM ENTRY,
        not absolute prices. Passing a price here silently creates a bracket
        thousands of ticks away, which means an effectively unprotected
        position. This is the single easiest way to blow the account through
        a coding error.

        The stop is attached at entry, never as a follow-up call. A bot that
        enters and then places its stop separately will eventually fill,
        disconnect before the second call lands, and run naked into the MLL.
        """
        import requests

        if stop_ticks <= 0 or target_ticks <= 0:
            raise ValueError(
                f"bracket ticks must be positive, got stop={stop_ticks} "
                f"target={target_ticks}"
            )

        payload = {
            "accountId": int(self.cfg.account_id),
            "contractId": self.cfg.contract_id,
            "type": ORDER_TYPE_MARKET,
            "side": side,
            "size": int(size),
            "stopLossBracket": {"ticks": int(stop_ticks), "type": ORDER_TYPE_STOP},
            "takeProfitBracket": {"ticks": int(target_ticks), "type": ORDER_TYPE_LIMIT},
        }

        if self.cfg.dry_run:
            log.info("DRY RUN — would submit %s", payload)
            return {"success": True, "orderId": "DRYRUN", "dryRun": True}

        resp = requests.post(
            f"{PROJECTX_BASE}/api/Order/place",
            json=payload,
            headers=self._headers(),
            timeout=15,
        )
        resp.raise_for_status()
        return resp.json()

    def flatten_all(self) -> dict:
        """Kill switch. Test this before you ever enable live orders."""
        import requests

        if self.cfg.dry_run:
            log.warning("DRY RUN — would flatten all positions")
            return {"success": True, "dryRun": True}

        resp = requests.post(
            f"{PROJECTX_BASE}/api/Position/closeContract",
            json={
                "accountId": self.cfg.account_id,
                "contractId": self.cfg.contract_id,
            },
            headers=self._headers(),
            timeout=15,
        )
        resp.raise_for_status()
        return resp.json()


class LiveTrader:
    """
    Binds a strategy to the rule engine and the broker.

    Every order passes through `submit()`, which cannot be bypassed. If the
    rule engine says no, the order is never constructed.
    """

    def __init__(
        self,
        client: ProjectXClient,
        instrument: Instrument,
        spec: CombineSpec = COMBINE_50K,
        cfg: LiveConfig | None = None,
    ):
        self.client = client
        self.instrument = instrument
        self.cfg = cfg or client.cfg
        self.account = TopstepAccount(spec)
        self.orders_today = 0
        self._last_day = None

    def sync_from_broker(self) -> None:
        """
        Reconcile local state with the broker's truth.

        Call this on startup and after any disconnect. The local account
        object is a model; the broker is reality. If they disagree, stop
        trading — do not guess.
        """
        data = self.client.get_account()
        accounts = data.get("accounts", [])
        match = next(
            (a for a in accounts if str(a.get("id")) == str(self.cfg.account_id)), None
        )
        if match is None:
            raise RuntimeError(
                f"account {self.cfg.account_id} not found in {[a.get('id') for a in accounts]}"
            )

        broker_balance = float(match.get("balance", 0.0))
        drift = abs(broker_balance - self.account.balance)
        if drift > 1.0:
            log.warning(
                "balance drift: local %.2f vs broker %.2f — trusting broker",
                self.account.balance,
                broker_balance,
            )
            self.account.balance = broker_balance

    def submit(self, signal, price: float) -> dict:
        """Route a strategy signal through the rule engine to the broker."""
        now = datetime.now(timezone.utc).astimezone()

        day = now.date()
        if day != self._last_day:
            self._last_day = day
            self.orders_today = 0

        if self.orders_today >= self.cfg.max_daily_orders:
            raise OrderRejected("daily order cap reached — possible runaway loop")

        if self.account.state is AccountState.FAILED_MLL:
            raise OrderRejected("account has breached the MLL")

        if not self.account.can_trade(now):
            raise OrderRejected(f"rule engine blocked entry: {self.account.state.value}")

        stop_ticks = abs(price - signal.stop_price) / self.instrument.tick_size
        contracts = size_position(
            self.account,
            self.instrument,
            stop_ticks,
            self.cfg.risk_per_trade,
            use_micros=True,
        )
        if contracts <= 0:
            raise OrderRejected(
                f"position size clamped to zero "
                f"(buffer ${self.account.balance - self.account.mll:,.0f}, "
                f"stop {stop_ticks:.0f} ticks)"
            )

        # Convert absolute prices to ticks from entry — the API's unit.
        target_ticks = round(
            abs(signal.target_price - price) / self.instrument.tick_size
        )
        stop_ticks_int = round(stop_ticks)

        self.orders_today += 1
        log.info(
            "submitting %s %d %s stop=%d ticks target=%d ticks",
            "LONG" if signal.is_long else "SHORT",
            contracts,
            self.instrument.symbol,
            stop_ticks_int,
            target_ticks,
        )

        return self.client.place_bracket(
            side=SIDE_BUY if signal.is_long else SIDE_SELL,
            size=contracts,
            stop_ticks=stop_ticks_int,
            target_ticks=target_ticks,
        )

    def heartbeat(self, unrealized: float) -> None:
        """
        Call on every tick or bar. This is the live MLL guard.

        If it trips, everything is flattened immediately. Do not make this
        conditional on anything.
        """
        now = datetime.now(timezone.utc).astimezone()
        violation = self.account.mark(now, unrealized)
        if violation is not None:
            log.critical("MLL BREACH: %s — flattening", violation.detail)
            self.client.flatten_all()
        elif self.account.must_flatten(now):
            log.info("flatten condition: session close or daily lockout")
            self.client.flatten_all()
