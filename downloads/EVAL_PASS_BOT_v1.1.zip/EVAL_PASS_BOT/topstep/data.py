"""
Market data for the backtest.

Two sources:

  load_csv()   — real intraday bars. USE THIS for anything you intend to
                 trade. Expects columns: timestamp, open, high, low, close,
                 volume. Timestamps must be US/Central (Topstep's session
                 clock) or tz-aware.

  synthetic()  — a calibrated random-price generator used only to exercise
                 the engine. It has NO real edge in it. Results from
                 synthetic data prove the machinery runs; they prove nothing
                 whatsoever about whether a strategy makes money.

Where to get real MES data:
  - Databento (GLBX.MDP3, MES futures) — paid, best quality
  - Your NinjaTrader / Tradovate / TradingView chart export — free
  - Firstrate Data, Kibot — paid, cheap
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

from .rules import RTH_CLOSE, RTH_OPEN, SESSION_CLOSE, SESSION_OPEN, trading_day

REQUIRED_COLUMNS = ["open", "high", "low", "close", "volume"]


def load_csv(path: str, tz: str = "US/Central") -> pd.DataFrame:
    """
    Load real intraday bars from CSV.

    Returns a DataFrame indexed by timestamp with OHLCV columns plus a
    `session` column mapping each bar to its Topstep trading day.
    """
    df = pd.read_csv(path)
    df.columns = [c.strip().lower() for c in df.columns]

    ts_col = next(
        (c for c in ("timestamp", "datetime", "date", "time") if c in df.columns),
        None,
    )
    if ts_col is None:
        raise ValueError(f"no timestamp column found in {path}; got {list(df.columns)}")

    df[ts_col] = pd.to_datetime(df[ts_col])
    df = df.set_index(ts_col).sort_index()

    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"missing required columns {missing} in {path}")

    df = df[REQUIRED_COLUMNS]
    df["session"] = [trading_day(ts.to_pydatetime()) for ts in df.index]
    return df


@dataclass
class SyntheticConfig:
    """
    Parameters calibrated to roughly resemble MES 1-minute behaviour.

    These are deliberately conservative. The generator produces a
    regime-switching random walk: some days trend, most chop. There is no
    hidden signal a strategy can learn — that is the point.
    """

    start_price: float = 6_000.0
    n_days: int = 250
    bars_per_day: int = 390          # RTH minutes, 08:30-15:00 CT
    # Calibrated so the daily range lands near 50-70 points and the 15-minute
    # opening range near 15-25 points, which is what ES/MES actually does.
    # Setting this too high silently makes every stop unaffordable.
    rth_sigma_points: float = 1.05   # per-minute stdev during RTH
    overnight_sigma_points: float = 0.40
    trend_day_prob: float = 0.35     # share of days with directional drift
    trend_strength: float = 0.25     # drift as a fraction of per-bar sigma
    tick_size: float = 0.25
    seed: int | None = None


def _intraday_vol_curve(n: int) -> np.ndarray:
    """
    U-shaped volatility: hot open, midday lull, active close.

    Real index futures show roughly 2x open-vs-midday volatility. Ignoring
    this makes opening-range strategies look far better than they are.
    """
    x = np.linspace(0.0, 1.0, n)
    curve = 1.9 * np.exp(-((x - 0.02) ** 2) / 0.012)   # opening spike
    curve += 0.9 * np.exp(-((x - 1.0) ** 2) / 0.02)    # closing pickup
    curve += 0.62                                       # baseline
    return curve / curve.mean()


def synthetic(cfg: SyntheticConfig | None = None) -> pd.DataFrame:
    """Generate calibrated fake 1-minute bars. Engine testing only."""
    cfg = cfg or SyntheticConfig()
    rng = np.random.default_rng(cfg.seed)

    vol_curve = _intraday_vol_curve(cfg.bars_per_day)
    rows = []
    price = cfg.start_price
    day = datetime(2025, 1, 2, 0, 0)

    for _ in range(cfg.n_days):
        while day.weekday() >= 5:  # skip weekends
            day += timedelta(days=1)

        # Overnight gap: 5 PM CT prior day -> 8:30 AM CT open.
        gap = rng.normal(0, cfg.overnight_sigma_points * np.sqrt(60))
        price = max(price + gap, 1.0)

        is_trend_day = rng.random() < cfg.trend_day_prob
        drift_sign = rng.choice([-1.0, 1.0]) if is_trend_day else 0.0
        drift = drift_sign * cfg.trend_strength * cfg.rth_sigma_points

        bar_time = day.replace(hour=RTH_OPEN.hour, minute=RTH_OPEN.minute)

        for i in range(cfg.bars_per_day):
            sigma = cfg.rth_sigma_points * vol_curve[i]
            ret = rng.normal(drift, sigma)
            open_ = price
            close = max(price + ret, 1.0)

            # Wicks scale with the bar's own realised range.
            body = abs(close - open_)
            wick = abs(rng.normal(0, sigma * 0.6))
            high = max(open_, close) + wick
            low = min(open_, close) - abs(rng.normal(0, sigma * 0.6))
            low = min(low, min(open_, close))
            high = max(high, max(open_, close))

            volume = int(max(rng.normal(1_400 * vol_curve[i], 400), 50))

            rows.append(
                {
                    "timestamp": bar_time,
                    "open": _round_tick(open_, cfg.tick_size),
                    "high": _round_tick(high, cfg.tick_size),
                    "low": _round_tick(low, cfg.tick_size),
                    "close": _round_tick(close, cfg.tick_size),
                    "volume": volume,
                }
            )

            price = close
            bar_time += timedelta(minutes=1)
            _ = body  # kept for readability of the wick logic

        day += timedelta(days=1)

    df = pd.DataFrame(rows).set_index("timestamp")
    df["session"] = [trading_day(ts.to_pydatetime()) for ts in df.index]
    return df


def _round_tick(p: float, tick: float) -> float:
    return round(round(p / tick) * tick, 2)


def rth_only(df: pd.DataFrame) -> pd.DataFrame:
    """Filter to the regular cash session, 08:30-15:00 CT."""
    t = df.index.time
    return df[(t >= RTH_OPEN) & (t <= RTH_CLOSE)]


def sessions(df: pd.DataFrame):
    """Yield (session_date, bars) for each trading day."""
    for day, bars in df.groupby("session", sort=True):
        yield day, bars


__all__ = [
    "load_csv",
    "synthetic",
    "SyntheticConfig",
    "rth_only",
    "sessions",
    "SESSION_OPEN",
    "SESSION_CLOSE",
]
