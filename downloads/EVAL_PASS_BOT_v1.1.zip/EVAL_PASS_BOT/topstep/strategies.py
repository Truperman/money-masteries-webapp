"""
Strategy implementations.

Every strategy returns a Signal or None for each bar. The strategy NEVER
sizes the position and NEVER decides whether it is allowed to trade — the
rule engine owns both. A strategy only expresses "I want to be long/short
here, with this stop and this target."

That separation is deliberate. It means a strategy cannot fail the account
no matter how badly it behaves; the worst it can do is lose money slowly
inside the risk envelope.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import time

import numpy as np
import pandas as pd

from .rules import RTH_OPEN


@dataclass
class Signal:
    is_long: bool
    stop_price: float
    target_price: float
    reason: str = ""


class Strategy:
    """Base class. Subclasses implement on_bar()."""

    name = "base"

    def start_session(self, session_date) -> None:
        """Called once at the start of each trading day."""

    def on_bar(self, ts, bar, history: pd.DataFrame) -> Signal | None:
        raise NotImplementedError

    @staticmethod
    def _atr(history: pd.DataFrame, n: int = 14) -> float:
        """Average true range in points, over the last n bars."""
        if len(history) < n + 1:
            return float("nan")
        h = history["high"].to_numpy()[-n:]
        l = history["low"].to_numpy()[-n:]
        c = history["close"].to_numpy()[-n - 1 : -1]
        tr = np.maximum(h - l, np.maximum(np.abs(h - c), np.abs(l - c)))
        return float(tr.mean())


# ----------------------------------------------------------------------


class OpeningRangeBreakout(Strategy):
    """
    Trade the first clean break of the opening range.

    Rationale for a Combine: it produces few trades with defined risk and a
    natural daily cap, which fits the consistency objective. One entry per
    day means no revenge-trading spiral.

    Parameters:
      range_minutes  — how long to build the opening range
      stop_buffer_r  — stop placed this fraction of the range beyond the
                       opposite side
      target_r       — profit target as a multiple of risk
      max_entries    — hard cap on entries per session
    """

    name = "opening_range_breakout"

    def __init__(
        self,
        range_minutes: int = 15,
        target_r: float = 2.0,
        max_entries: int = 1,
        cutoff: time = time(13, 0),
        stop_frac: float = 0.5,
        max_stop_atr: float = 2.5,
    ):
        self.range_minutes = range_minutes
        self.target_r = target_r
        self.max_entries = max_entries
        self.cutoff = cutoff
        # Stop placement. Parking the stop at the far side of the opening
        # range makes risk-per-contract so large that position sizing rounds
        # to zero on a $2,000 MLL. Stop inside the range instead, capped by
        # ATR so a wild open cannot produce an unaffordable trade.
        self.stop_frac = stop_frac
        self.max_stop_atr = max_stop_atr
        self.reset()

    def reset(self):
        self.or_high = None
        self.or_low = None
        self.entries_today = 0
        self.range_locked = False

    def start_session(self, session_date) -> None:
        self.reset()

    def on_bar(self, ts, bar, history) -> Signal | None:
        t = ts.time()
        if t < RTH_OPEN or t > self.cutoff:
            return None
        if self.entries_today >= self.max_entries:
            return None

        minutes_in = (t.hour - RTH_OPEN.hour) * 60 + (t.minute - RTH_OPEN.minute)

        # Build the range.
        if minutes_in < self.range_minutes:
            self.or_high = bar.high if self.or_high is None else max(self.or_high, bar.high)
            self.or_low = bar.low if self.or_low is None else min(self.or_low, bar.low)
            return None

        if self.or_high is None or self.or_low is None:
            return None

        rng = self.or_high - self.or_low
        if rng <= 0:
            return None

        # A range that is too tight or too wide relative to the day's ATR
        # produces false breaks and unmanageable stops respectively.
        atr = self._atr(history, 14)
        if np.isnan(atr) or rng < atr * 0.8 or rng > atr * 6:
            return None

        # Risk distance: a fraction of the range, capped by ATR.
        risk = min(rng * self.stop_frac, atr * self.max_stop_atr)
        if risk <= 0:
            return None

        if bar.close > self.or_high:
            self.entries_today += 1
            return Signal(
                is_long=True,
                stop_price=bar.close - risk,
                target_price=bar.close + risk * self.target_r,
                reason=f"break above OR high {self.or_high:.2f}",
            )

        if bar.close < self.or_low:
            self.entries_today += 1
            return Signal(
                is_long=False,
                stop_price=bar.close + risk,
                target_price=bar.close - risk * self.target_r,
                reason=f"break below OR low {self.or_low:.2f}",
            )

        return None


# ----------------------------------------------------------------------


class TrendPullback(Strategy):
    """
    Enter with the intraday trend on a pullback to a moving average.

    Trend is defined by a fast/slow EMA cross on the session's own bars.
    Entry triggers when price pulls back to the fast EMA and then resumes.
    Stop goes beyond the swing; target is a multiple of that risk.
    """

    name = "trend_pullback"

    def __init__(
        self,
        fast: int = 9,
        slow: int = 30,
        target_r: float = 2.0,
        max_entries: int = 3,
        cutoff: time = time(14, 0),
    ):
        self.fast = fast
        self.slow = slow
        self.target_r = target_r
        self.max_entries = max_entries
        self.cutoff = cutoff
        self.entries_today = 0

    def start_session(self, session_date) -> None:
        self.entries_today = 0

    def on_bar(self, ts, bar, history) -> Signal | None:
        if ts.time() < RTH_OPEN or ts.time() > self.cutoff:
            return None
        if self.entries_today >= self.max_entries:
            return None
        if len(history) < self.slow + 5:
            return None

        closes = history["close"]
        ema_f = closes.ewm(span=self.fast, adjust=False).mean()
        ema_s = closes.ewm(span=self.slow, adjust=False).mean()

        f_now, s_now = ema_f.iloc[-1], ema_s.iloc[-1]
        atr = self._atr(history, 14)
        if np.isnan(atr) or atr <= 0:
            return None

        recent = history.iloc[-6:]

        # Uptrend: fast above slow, price dipped to the fast EMA, now resuming.
        if f_now > s_now:
            touched = (recent["low"] <= ema_f.iloc[-6:]).any()
            if touched and bar.close > f_now and bar.close > bar.open:
                stop = float(recent["low"].min()) - atr * 0.25
                risk = bar.close - stop
                if risk <= 0 or risk > atr * 4:
                    return None
                self.entries_today += 1
                return Signal(
                    is_long=True,
                    stop_price=stop,
                    target_price=bar.close + risk * self.target_r,
                    reason="pullback to fast EMA in uptrend",
                )

        # Downtrend mirror.
        if f_now < s_now:
            touched = (recent["high"] >= ema_f.iloc[-6:]).any()
            if touched and bar.close < f_now and bar.close < bar.open:
                stop = float(recent["high"].max()) + atr * 0.25
                risk = stop - bar.close
                if risk <= 0 or risk > atr * 4:
                    return None
                self.entries_today += 1
                return Signal(
                    is_long=False,
                    stop_price=stop,
                    target_price=bar.close - risk * self.target_r,
                    reason="pullback to fast EMA in downtrend",
                )

        return None


# ----------------------------------------------------------------------


class VWAPReversion(Strategy):
    """
    Fade extensions away from session VWAP.

    High hit-rate, small winners, occasional large loser — the exact shape
    that trailing drawdown punishes. Included so the evaluation can show
    that a high win rate is not the same as a passable strategy.
    """

    name = "vwap_reversion"

    def __init__(
        self,
        entry_sigma: float = 2.0,
        target_r: float = 1.0,
        max_entries: int = 4,
        cutoff: time = time(14, 0),
        stop_atr: float = 3.0,
    ):
        self.entry_sigma = entry_sigma
        self.target_r = target_r
        self.stop_atr = stop_atr
        self.max_entries = max_entries
        self.cutoff = cutoff
        self.entries_today = 0

    def start_session(self, session_date) -> None:
        self.entries_today = 0

    def on_bar(self, ts, bar, history) -> Signal | None:
        if ts.time() < RTH_OPEN or ts.time() > self.cutoff:
            return None
        if self.entries_today >= self.max_entries:
            return None
        if len(history) < 30:
            return None

        typical = (history["high"] + history["low"] + history["close"]) / 3.0
        vol = history["volume"].replace(0, 1)
        vwap = float((typical * vol).cumsum().iloc[-1] / vol.cumsum().iloc[-1])

        dev = typical - vwap
        sigma = float(dev.std())
        if sigma <= 0:
            return None

        atr = self._atr(history, 14)
        if np.isnan(atr) or atr <= 0:
            return None

        z = (bar.close - vwap) / sigma

        # A fade needs room to be wrong before it is right, so the stop sits
        # well beyond the extension while the target is only the trip back to
        # the mean. That asymmetry is the whole point: frequent small wins,
        # rare large losses. It is also precisely the profile that trailing
        # drawdown punishes, which is what this strategy exists to show.
        if z >= self.entry_sigma:
            self.entries_today += 1
            return Signal(
                is_long=False,
                stop_price=bar.close + atr * self.stop_atr,
                target_price=vwap,
                reason=f"fade +{z:.1f} sigma from VWAP",
            )

        if z <= -self.entry_sigma:
            self.entries_today += 1
            return Signal(
                is_long=True,
                stop_price=bar.close - atr * self.stop_atr,
                target_price=vwap,
                reason=f"fade {z:.1f} sigma from VWAP",
            )

        return None


STRATEGIES = {
    s.name: s
    for s in (OpeningRangeBreakout, TrendPullback, VWAPReversion)
}
