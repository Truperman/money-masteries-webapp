"""
Evaluation mode: optimize for PASSING, not for profit.

The honest premise first, because it shapes everything below.

You cannot pass a Combine without positive expectancy. Passing means netting
+$3,000 before losing $2,000, and no amount of clever account management
turns a losing strategy into a winning one. The approaches that claim to —
exploiting simulated fills, high-frequency order spam — are explicitly
prohibited by Topstep and get the account removed rather than funded.

What CAN be optimized, and what this module does, is the wrapper around a
given edge. A strategy tuned for long-run profit and the same strategy tuned
for pass probability behave differently in specific, measurable ways:

  - Profit-maximizing keeps trading after the target is hit. Pass-maximizing
    stops dead, because every trade after that point is pure downside.
  - Profit-maximizing takes the big day when it comes. Pass-maximizing caps
    it, because a $2,000 day on a $3,000 target fails the consistency
    objective and forces you to grind out thousands more.
  - Profit-maximizing sizes by edge. Pass-maximizing shrinks near the
    finish, where the value of accumulated progress is highest and the cost
    of losing it is total.

Every one of those trades away expected profit for a higher probability of
reaching one specific finish line. That is exactly the trade you want while
the goal is getting funded.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from .rules import COMBINE_50K, AccountState, CombineSpec, TopstepAccount


@dataclass
class PassPolicy:
    """
    Governors layered on top of the hard rule engine.

    The rule engine says what Topstep forbids. This says what a trader
    chasing a pass should additionally refuse to do.
    """

    # Stop the moment the evaluation is actually passed.
    target_lock: bool = True

    # Cap daily profit so the consistency objective can never fail.
    # 0.90 means: use 90% of the allowed best-day size as the daily cap.
    consistency_governor: bool = True
    consistency_headroom: float = 0.90

    # Stop for the session after this many losses in a row.
    max_consecutive_losses: int = 3

    # Once this fraction of the target is banked, cut size. Late-stage
    # progress is the most expensive thing in the account to lose.
    endgame_trigger: float = 0.70
    endgame_risk_multiplier: float = 0.60

    # Voluntary daily loss stop, tighter than Topstep's. Hitting Topstep's
    # $1,000 limit costs a fifth of the entire buffer in one session.
    soft_daily_loss: float | None = 500.0

    def daily_profit_cap(self, spec: CombineSpec) -> float:
        return spec.max_best_day * self.consistency_headroom


class PassOptimizer:
    """
    Wraps a TopstepAccount and answers two questions per trade:

        should_trade()     -> bool
        risk_multiplier()  -> float in [0, 1]

    It never places orders and never overrides the rule engine. It only
    declines opportunities the rule engine would have allowed.
    """

    def __init__(
        self,
        account: TopstepAccount,
        policy: PassPolicy | None = None,
    ):
        self.account = account
        self.policy = policy or PassPolicy()
        self.consecutive_losses = 0
        self.locked = False
        self.stop_reason: str | None = None

    # ------------------------------------------------------------------

    def on_trade_closed(self, pnl: float) -> None:
        if pnl > 0:
            self.consecutive_losses = 0
        else:
            self.consecutive_losses += 1

    def new_session(self) -> None:
        self.consecutive_losses = 0

    # ------------------------------------------------------------------

    def is_passed(self) -> bool:
        return bool(self.account.evaluate()["passed"])

    def should_trade(self, ts: datetime) -> bool:
        """Every reason to decline a trade the rule engine would permit."""
        acct = self.account
        pol = self.policy

        if self.locked:
            return False

        # Hard rules first — these are Topstep's, not ours.
        if not acct.can_trade(ts):
            return False

        # Done. Stop.
        if pol.target_lock and self.is_passed():
            self.locked = True
            self.stop_reason = "evaluation passed"
            return False

        # Consistency governor: never let one day get big enough to fail
        # the best-day ratio.
        if pol.consistency_governor:
            cap = pol.daily_profit_cap(acct.spec)
            if acct.day_pnl >= cap:
                self.stop_reason = f"daily profit cap ${cap:,.0f} reached"
                return False

        # Voluntary daily loss stop, well inside Topstep's.
        if pol.soft_daily_loss is not None and acct.day_pnl <= -pol.soft_daily_loss:
            self.stop_reason = f"soft daily loss ${pol.soft_daily_loss:,.0f} hit"
            return False

        # Losing streak circuit breaker.
        if self.consecutive_losses >= pol.max_consecutive_losses:
            self.stop_reason = f"{self.consecutive_losses} consecutive losses"
            return False

        return True

    def risk_multiplier(self) -> float:
        """Scale the base risk per trade. Never scales up."""
        acct = self.account
        pol = self.policy
        mult = 1.0

        progress = acct.total_profit / acct.spec.profit_target
        if progress >= pol.endgame_trigger:
            mult *= pol.endgame_risk_multiplier

        # Do not let a single trade breach the consistency cap on the way up.
        if pol.consistency_governor:
            cap = pol.daily_profit_cap(acct.spec)
            room = cap - acct.day_pnl
            if room <= 0:
                return 0.0

        return max(mult, 0.0)


# ----------------------------------------------------------------------
# Measurement
# ----------------------------------------------------------------------

def simulate_with_policy(
    win_rate: float,
    reward_risk: float,
    trades_per_day: float,
    risk_per_trade: float,
    policy: PassPolicy | None,
    spec: CombineSpec = COMBINE_50K,
    max_days: int = 60,
    rng=None,
    intrabar_adverse_r: float = 0.6,
) -> tuple[str, int, float]:
    """
    One Combine attempt, with or without the pass-optimizing policy.

    Pass policy=None to measure the unmanaged baseline.
    """
    import numpy as np
    from datetime import timedelta

    rng = rng or np.random.default_rng()
    account = TopstepAccount(spec)
    opt = PassOptimizer(account, policy) if policy is not None else None

    day = datetime(2026, 1, 5, 9, 0)

    for d in range(max_days):
        while day.weekday() >= 5:
            day += timedelta(days=1)

        if opt is not None:
            opt.new_session()

        n_trades = int(rng.poisson(trades_per_day))
        ts = day.replace(hour=9, minute=0)

        for _ in range(n_trades):
            if not account.can_trade(ts):
                break

            if opt is not None:
                if not opt.should_trade(ts):
                    break
                mult = opt.risk_multiplier()
                if mult <= 0:
                    break
            else:
                mult = 1.0

            risk = risk_per_trade * mult
            room = account.balance - account.mll
            if room <= 0:
                return ("failed_mll", d + 1, account.total_profit)

            risk = min(risk, room / 2.0)
            if risk < risk_per_trade * 0.25 * mult:
                return ("stalled", d + 1, account.total_profit)

            # Adverse excursion before resolution — the MLL watches this.
            if account.mark(ts, -risk * intrabar_adverse_r) is not None:
                return ("failed_mll", d + 1, account.total_profit)

            won = rng.random() < win_rate
            pnl = risk * reward_risk if won else -risk

            if account.mark(ts, pnl) is not None:
                return ("failed_mll", d + 1, account.total_profit)

            account.on_fill(ts, pnl)
            if opt is not None:
                opt.on_trade_closed(pnl)

            if account.state is AccountState.FAILED_MLL:
                return ("failed_mll", d + 1, account.total_profit)

            ts += timedelta(minutes=20)

        account.end_of_day(day.replace(hour=15, minute=10))
        day += timedelta(days=1)
        account.current_day = None
        account.day_pnl = 0.0
        if account.state is AccountState.LOCKED_OUT_DAILY:
            account.state = AccountState.ACTIVE

        if account.evaluate()["passed"]:
            return ("passed", d + 1, account.total_profit)

    return ("exhausted", max_days, account.total_profit)


def compare_policies(
    win_rate: float,
    reward_risk: float,
    trades_per_day: float = 3.0,
    risk_per_trade: float = 150.0,
    n_runs: int = 2_000,
    spec: CombineSpec = COMBINE_50K,
    seed: int = 99,
    policy: PassPolicy | None = None,
) -> dict:
    """Baseline vs pass-optimized, same edge, same seed."""
    import numpy as np

    policy = policy or PassPolicy()
    out = {}

    for label, pol in (("baseline", None), ("pass_optimized", policy)):
        rng = np.random.default_rng(seed)
        counts = {"passed": 0, "failed_mll": 0, "stalled": 0, "exhausted": 0}
        days = []
        for _ in range(n_runs):
            outcome, d, _profit = simulate_with_policy(
                win_rate, reward_risk, trades_per_day, risk_per_trade,
                pol, spec, rng=rng,
            )
            counts[outcome] += 1
            if outcome == "passed":
                days.append(d)

        out[label] = {
            "pass_rate": round(counts["passed"] / n_runs, 4),
            "failed_mll": round(counts["failed_mll"] / n_runs, 4),
            "stalled": round(counts["stalled"] / n_runs, 4),
            "exhausted": round(counts["exhausted"] / n_runs, 4),
            "median_days": float(np.median(days)) if days else float("nan"),
        }

    out["win_rate"] = win_rate
    out["reward_risk"] = reward_risk
    out["delta_pass_rate"] = round(
        out["pass_optimized"]["pass_rate"] - out["baseline"]["pass_rate"], 4
    )
    return out
