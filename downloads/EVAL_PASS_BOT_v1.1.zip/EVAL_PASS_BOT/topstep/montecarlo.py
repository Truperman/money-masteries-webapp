"""
Monte Carlo evaluation of the Combine.

This is the part of the toolkit that does not depend on price data at all,
and is therefore the part you can actually trust.

Instead of asking "did my strategy make money on this price history", it asks
the question that decides whether you get funded:

    Given a strategy with win rate W, reward:risk R, N trades per day, and
    F dollars risked per trade, what is the probability of passing the
    $50K Combine before failing it?

It answers by simulating thousands of Combine attempts through the SAME rule
engine the backtester uses, so the trailing drawdown, the daily loss limit,
and the consistency objective all apply exactly as Topstep applies them.

The output is a required-edge surface: the minimum win rate at each R that
gives you a workable chance. That number is the honest bar to clear.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta

import numpy as np

from .rules import COMBINE_50K, AccountState, CombineSpec, TopstepAccount


@dataclass
class EdgeProfile:
    """A strategy expressed purely as a statistical edge."""

    win_rate: float
    reward_risk: float          # winner size as a multiple of the risked amount
    trades_per_day: float
    risk_per_trade: float
    name: str = ""

    @property
    def expectancy_r(self) -> float:
        """Expected value per trade in R units. Must be > 0 to be viable."""
        return self.win_rate * self.reward_risk - (1 - self.win_rate)

    @property
    def expectancy_dollars(self) -> float:
        return self.expectancy_r * self.risk_per_trade


@dataclass
class MonteCarloResult:
    profile: EdgeProfile
    n_runs: int
    passed: int
    failed_mll: int
    stalled: int          # buffer too thin to keep trading — practically dead
    exhausted: int        # still alive, just too slow to hit the target
    days_to_pass: list
    final_profits: list

    @property
    def pass_rate(self) -> float:
        return self.passed / self.n_runs

    @property
    def mll_failure_rate(self) -> float:
        return self.failed_mll / self.n_runs

    @property
    def dead_rate(self) -> float:
        """Everything that ends the attempt for risk reasons."""
        return (self.failed_mll + self.stalled) / self.n_runs

    @property
    def median_days_to_pass(self) -> float:
        return float(np.median(self.days_to_pass)) if self.days_to_pass else float("nan")

    def summary(self) -> dict:
        return {
            "name": self.profile.name,
            "win_rate": self.profile.win_rate,
            "reward_risk": self.profile.reward_risk,
            "risk_per_trade": self.profile.risk_per_trade,
            "trades_per_day": self.profile.trades_per_day,
            "expectancy_R": round(self.profile.expectancy_r, 4),
            "pass_rate": round(self.pass_rate, 4),
            "mll_failure_rate": round(self.mll_failure_rate, 4),
            "stalled_rate": round(self.stalled / self.n_runs, 4),
            "dead_rate": round(self.dead_rate, 4),
            "ran_out_of_time": round(self.exhausted / self.n_runs, 4),
            "median_days_to_pass": self.median_days_to_pass,
        }


def simulate_one(
    profile: EdgeProfile,
    spec: CombineSpec = COMBINE_50K,
    max_days: int = 60,
    rng: np.random.Generator | None = None,
    intrabar_adverse_r: float = 0.6,
    adaptive_sizing: bool = True,
) -> tuple[str, int, float]:
    """
    Simulate a single Combine attempt.

    intrabar_adverse_r models the excursion against you WITHIN a trade before
    it resolves. This matters enormously: the MLL is monitored on unrealized
    P&L, so a trade that ends at +2R having first gone -0.6R can still fail
    the account if the buffer was thin. Ignoring this is the single most
    common way a Combine simulation overstates the pass rate.

    Returns (outcome, days_used, final_profit).
    """
    rng = rng or np.random.default_rng()
    account = TopstepAccount(spec)
    day = datetime(2026, 1, 5, 9, 0)

    for d in range(max_days):
        # Weekends off.
        while day.weekday() >= 5:
            day += timedelta(days=1)

        n_trades = rng.poisson(profile.trades_per_day)
        ts = day.replace(hour=9, minute=0)

        for _ in range(int(n_trades)):
            if not account.can_trade(ts):
                break

            risk = profile.risk_per_trade
            room = account.balance - account.mll
            if room <= 0:
                return ("failed_mll", d + 1, account.total_profit)

            if adaptive_sizing:
                # Never stake more than half the remaining buffer. This is
                # what converts a blowup into a slow stall.
                risk = min(risk, room / 2.0)
                if risk < profile.risk_per_trade * 0.25:
                    # Buffer too thin to express the edge. The account is
                    # technically alive but can no longer reach the target,
                    # which is a failure in every way that matters.
                    return ("stalled", d + 1, account.total_profit)

            # Adverse excursion first — this is where accounts die.
            adverse = -risk * intrabar_adverse_r
            if account.mark(ts, adverse) is not None:
                return ("failed_mll", d + 1, account.total_profit)

            won = rng.random() < profile.win_rate
            pnl = risk * profile.reward_risk if won else -risk

            if account.mark(ts, pnl) is not None:
                return ("failed_mll", d + 1, account.total_profit)

            account.on_fill(ts, pnl)
            if account.state is AccountState.FAILED_MLL:
                return ("failed_mll", d + 1, account.total_profit)

            ts += timedelta(minutes=20)

        account.end_of_day(day.replace(hour=15, minute=10))
        day += timedelta(days=1)

        # Roll the day forward inside the account too.
        account.current_day = None
        account.day_pnl = 0.0
        if account.state is AccountState.LOCKED_OUT_DAILY:
            account.state = AccountState.ACTIVE

        report = account.evaluate()
        if report["passed"]:
            return ("passed", d + 1, account.total_profit)

    return ("exhausted", max_days, account.total_profit)


def run_monte_carlo(
    profile: EdgeProfile,
    n_runs: int = 2_000,
    spec: CombineSpec = COMBINE_50K,
    max_days: int = 60,
    seed: int = 42,
    adaptive_sizing: bool = True,
) -> MonteCarloResult:
    rng = np.random.default_rng(seed)
    passed = failed = stalled = exhausted = 0
    days_to_pass, profits = [], []

    for _ in range(n_runs):
        outcome, days, profit = simulate_one(
            profile, spec, max_days, rng, adaptive_sizing=adaptive_sizing
        )
        profits.append(profit)
        if outcome == "passed":
            passed += 1
            days_to_pass.append(days)
        elif outcome == "failed_mll":
            failed += 1
        elif outcome == "stalled":
            stalled += 1
        else:
            exhausted += 1

    return MonteCarloResult(
        profile=profile,
        n_runs=n_runs,
        passed=passed,
        failed_mll=failed,
        stalled=stalled,
        exhausted=exhausted,
        days_to_pass=days_to_pass,
        final_profits=profits,
    )


def required_edge_grid(
    reward_risks=(1.0, 1.5, 2.0, 3.0),
    win_rates=(0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65),
    risk_per_trade: float = 150.0,
    trades_per_day: float = 3.0,
    n_runs: int = 800,
    spec: CombineSpec = COMBINE_50K,
    seed: int = 7,
) -> list[dict]:
    """Sweep the win-rate / reward-risk plane and report pass probability."""
    rows = []
    for rr in reward_risks:
        for wr in win_rates:
            p = EdgeProfile(
                win_rate=wr,
                reward_risk=rr,
                trades_per_day=trades_per_day,
                risk_per_trade=risk_per_trade,
                name=f"WR={wr:.0%} R={rr}",
            )
            res = run_monte_carlo(p, n_runs=n_runs, spec=spec, seed=seed)
            rows.append(res.summary())
    return rows


def risk_sizing_sweep(
    profile_template: EdgeProfile,
    risks=(50, 75, 100, 150, 200, 300, 400),
    n_runs: int = 1_000,
    spec: CombineSpec = COMBINE_50K,
    seed: int = 11,
) -> list[dict]:
    """
    Hold the edge constant, vary only dollars risked per trade.

    This isolates the effect of position size on pass probability. There is
    always an interior optimum: too small and you cannot reach the target
    inside the time limit, too large and the trailing drawdown gets you.
    """
    rows = []
    for r in risks:
        p = EdgeProfile(
            win_rate=profile_template.win_rate,
            reward_risk=profile_template.reward_risk,
            trades_per_day=profile_template.trades_per_day,
            risk_per_trade=float(r),
            name=f"risk=${r}",
        )
        res = run_monte_carlo(p, n_runs=n_runs, spec=spec, seed=seed)
        rows.append(res.summary())
    return rows
