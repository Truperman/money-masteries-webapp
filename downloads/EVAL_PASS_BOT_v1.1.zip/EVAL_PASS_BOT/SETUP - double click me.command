#!/bin/bash
cd "$(dirname "$0")"
clear
cat <<'BANNER'
================================================================
   EVAL PASS BOT  -  AUTOMATIC SETUP
================================================================
  This finds or installs Python, sets everything up, opens the
  Topstep page for your API key, grabs it from your clipboard,
  and checks it actually works.

  Your key is saved only on this computer.
================================================================

BANNER
bash setup.sh
echo
printf "Press RETURN to close this window: "
read -r _
