#!/bin/bash
# Download a year of MES price history for testing.
cd "$(dirname "$0")"
if [ ! -d .venv ]; then echo "Run 'bash setup.sh' first."; exit 1; fi
.venv/bin/python fetch_data.py --days 365 --out mes_1min.csv
