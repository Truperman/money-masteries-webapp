#!/bin/bash
# Start the bot. Safe mode by default.
#   bash go.sh                     -> safe mode, no real orders
#   bash go.sh --live --risk 75    -> real orders (asks you to confirm)
cd "$(dirname "$0")"

if [ ! -d .venv ]; then
  echo "Not set up yet. Run this first:"
  echo "    bash setup.sh"
  exit 1
fi

if [ ! -f .env ] || grep -q "PUT_YOUR" .env 2>/dev/null; then
  echo "No credentials saved yet. Run this first:"
  echo "    bash setup.sh"
  exit 1
fi

.venv/bin/python run_live.py "$@"
