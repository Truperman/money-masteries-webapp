#!/usr/bin/env python3
"""
Pull MES historical bars from the TopstepX / ProjectX API into a CSV.

RUN THIS ON YOUR OWN MACHINE. Your API key never leaves it.

Setup
-----
1. Enable API access: TopstepX -> Settings -> API ($29/mo, or $14.50 with
   code `topstep`). Generate a key there.

2. Put the credentials in a file called `.env` next to this script:

       TOPSTEP_USERNAME=your_topstepx_username
       TOPSTEP_API_KEY=your_generated_key

   Add `.env` to .gitignore. Never paste these into a chat, a commit, or
   an issue — the key can place and cancel real orders on your account.

3. Install and run:

       pip install requests
       python3 fetch_data.py --days 365 --out mes_1min.csv

The output CSV is exactly the format `topstep/data.load_csv()` expects, so:

       python3 run_evaluation.py --csv mes_1min.csv

Notes
-----
The API returns at most 20,000 bars per request, so this pages backwards in
windows and stitches the results. One-minute bars over a full 24-hour
session run about 1,400 per day, so a year needs roughly 25 requests. Be
polite about rate limits — there is a delay between calls.

Timestamps come back in UTC and are converted to US/Central, which is the
session clock Topstep's rules are defined in. The rule engine assumes
Central; feeding it UTC will silently misplace every session boundary.
"""

from __future__ import annotations

import argparse
import csv
import os
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

API_BASE = os.environ.get("PROJECTX_BASE_URL", "https://api.topstepx.com")
MAX_BARS = 20_000
UNIT_MINUTE = 2


def load_env(path: Path = Path(".env")) -> None:
    """Minimal .env reader so there is no extra dependency."""
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        os.environ.setdefault(key.strip(), val.strip().strip("'\""))


def authenticate(username: str, api_key: str) -> str:
    import requests

    resp = requests.post(
        f"{API_BASE}/api/Auth/loginKey",
        json={"userName": username, "apiKey": api_key},
        timeout=20,
    )
    resp.raise_for_status()
    data = resp.json()
    if not data.get("success"):
        raise SystemExit(
            f"Authentication failed (code {data.get('errorCode')}): "
            f"{data.get('errorMessage')}\n"
            "Check TOPSTEP_USERNAME matches your TopstepX username exactly, "
            "and that your API subscription is active."
        )
    return data["token"]


def find_contract(token: str, symbol: str = "MES") -> dict:
    """Look up the active front-month contract."""
    import requests

    resp = requests.post(
        f"{API_BASE}/api/Contract/search",
        json={"searchText": symbol, "live": False},
        headers={"Authorization": f"Bearer {token}"},
        timeout=20,
    )
    resp.raise_for_status()
    payload = resp.json()
    contracts = payload.get("contracts", [])
    if not contracts:
        raise SystemExit(f"No contracts found for '{symbol}': {payload}")

    active = [c for c in contracts if c.get("activeContract")]
    chosen = (active or contracts)[0]

    print(f"  contract : {chosen.get('id')}  ({chosen.get('description')})")
    print(f"  tick     : {chosen.get('tickSize')} = ${chosen.get('tickValue')}")
    return chosen


def fetch_window(token: str, contract_id: str, start: datetime, end: datetime) -> list:
    import requests

    resp = requests.post(
        f"{API_BASE}/api/History/retrieveBars",
        json={
            "contractId": contract_id,
            "live": False,
            "startTime": start.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "endTime": end.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "unit": UNIT_MINUTE,
            "unitNumber": 1,
            "limit": MAX_BARS,
            "includePartialBar": False,
        },
        headers={"Authorization": f"Bearer {token}"},
        timeout=60,
    )
    resp.raise_for_status()
    data = resp.json()
    if not data.get("success"):
        raise SystemExit(f"retrieveBars failed: {data}")
    return data.get("bars", [])


def to_central(ts_str: str) -> datetime:
    """Parse the API timestamp and convert to US/Central."""
    try:
        from zoneinfo import ZoneInfo
    except ImportError:
        raise SystemExit("Python 3.9+ required for timezone conversion")

    ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    return ts.astimezone(ZoneInfo("America/Chicago"))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=365, help="days of history")
    ap.add_argument("--symbol", default="MES")
    ap.add_argument("--out", default="mes_1min.csv")
    ap.add_argument("--window-days", type=int, default=10,
                    help="days per request; lower if you hit the 20k bar cap")
    ap.add_argument("--sleep", type=float, default=0.5, help="seconds between calls")
    args = ap.parse_args()

    load_env()
    username = os.environ.get("TOPSTEP_USERNAME", "")
    api_key = os.environ.get("TOPSTEP_API_KEY", "")

    if not username or not api_key:
        raise SystemExit(
            "Missing credentials.\n"
            "Create a .env file next to this script containing:\n"
            "  TOPSTEP_USERNAME=your_username\n"
            "  TOPSTEP_API_KEY=your_key\n"
        )

    print("authenticating...")
    token = authenticate(username, api_key)
    print("  ok")

    print(f"finding {args.symbol} contract...")
    contract = find_contract(token, args.symbol)
    contract_id = contract["id"]

    end = datetime.now(timezone.utc)
    start = end - timedelta(days=args.days)

    all_bars: dict[str, dict] = {}
    cursor = start
    request_n = 0

    print(f"fetching {args.days} days in {args.window_days}-day windows...")
    while cursor < end:
        window_end = min(cursor + timedelta(days=args.window_days), end)
        request_n += 1

        bars = fetch_window(token, contract_id, cursor, window_end)
        for b in bars:
            all_bars[b["t"]] = b   # dedupe on timestamp

        print(f"  [{request_n:3d}] {cursor:%Y-%m-%d} -> {window_end:%Y-%m-%d}  "
              f"{len(bars):>6,} bars  (total {len(all_bars):,})")

        if len(bars) >= MAX_BARS:
            print("       hit the 20,000 bar cap — rerun with a smaller "
                  "--window-days to avoid gaps")

        cursor = window_end
        time.sleep(args.sleep)

    if not all_bars:
        raise SystemExit("No bars returned. Check the contract and date range.")

    rows = []
    for b in sorted(all_bars.values(), key=lambda x: x["t"]):
        ts = to_central(b["t"])
        rows.append({
            "timestamp": ts.strftime("%Y-%m-%d %H:%M:%S"),
            "open": b["o"],
            "high": b["h"],
            "low": b["l"],
            "close": b["c"],
            "volume": b["v"],
        })

    out = Path(args.out)
    with out.open("w", newline="") as f:
        w = csv.DictWriter(
            f, fieldnames=["timestamp", "open", "high", "low", "close", "volume"]
        )
        w.writeheader()
        w.writerows(rows)

    print(f"\nwrote {len(rows):,} bars to {out}")
    print(f"range: {rows[0]['timestamp']} -> {rows[-1]['timestamp']} (US/Central)")
    print(f"\nnext:  python3 run_evaluation.py --csv {out}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
