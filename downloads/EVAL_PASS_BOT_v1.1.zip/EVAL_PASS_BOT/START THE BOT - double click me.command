#!/bin/bash
# Starts the bot in SAFE MODE. No real orders are sent.
cd "$(dirname "$0")"
clear

cat <<'BANNER'
================================================================
   EVAL PASS BOT  -  SAFE MODE
================================================================

  The bot will connect to your account and watch the market,
  but it will NOT place any real orders.

  To stop it:  hold CONTROL and press C
  Do NOT just close this window.

================================================================

BANNER

if [ ! -d .venv ]; then
  echo "  Not set up yet."
  echo "  Double-click 'SETUP - double click me.command' first."
  echo
  printf "Press RETURN to close: "
  read -r _
  exit 1
fi

bash go.sh

echo
printf "Press RETURN to close this window: "
read -r _
