#!/usr/bin/env python3
"""
Setup wizard — automates everything that can be automated.

WHAT THIS DOES FOR THE USER

  Python            checks the version; if it is missing or too old, offers
                    to install it via Homebrew, or opens the correct
                    download page for their exact operating system.

  Dependencies      builds the private environment and installs everything.

  API key           opens the TopstepX settings page directly in their
                    browser — no hunting through menus. Then reads the key
                    from their clipboard if it looks like one, so they never
                    have to paste it manually.

  Validation        calls Topstep immediately to confirm the credentials
                    work, instead of failing later with a cryptic error.

  Account check     lists their actual accounts, confirms a Combine is
                    active, and reports the balance and drawdown room.

WHAT CANNOT BE AUTOMATED, AND WHY

  Creating a Topstep account and generating the API key both happen behind
  their login. No script can do that, and any tool that offers to would be
  asking for their password. This wizard takes them to the exact page and
  catches the key on the way back — that is the whole of what is honestly
  possible.
"""

from __future__ import annotations

import os
import platform
import re
import shutil
import subprocess
import sys
import webbrowser
from pathlib import Path

HERE = Path(__file__).resolve().parent

TOPSTEPX_API_SETTINGS = "https://topstepx.com/settings/api"
TOPSTEP_SIGNUP = "https://www.topstep.com/"
PYTHON_DOWNLOAD = "https://www.python.org/downloads/"
API_BASE = os.environ.get("PROJECTX_BASE_URL", "https://api.topstepx.com")

IS_MAC = platform.system() == "Darwin"
IS_WIN = platform.system() == "Windows"


# ----------------------------------------------------------------------
# Presentation
# ----------------------------------------------------------------------

def hr(char="=", n=64):
    print(char * n)


def head(title):
    print()
    hr()
    print(f"  {title}")
    hr()
    print()


def ok(msg):
    print(f"  [OK]   {msg}")


def warn(msg):
    print(f"  [!]    {msg}")


def fail(msg):
    print(f"  [X]    {msg}")


def ask(prompt, default=None):
    suffix = f" [{default}]" if default else ""
    try:
        val = input(f"  {prompt}{suffix}: ").strip()
    except EOFError:
        return default or ""
    return val or (default or "")


def yes(prompt, default=True):
    d = "S/n" if default else "s/N"
    try:
        val = input(f"  {prompt} ({d}): ").strip().lower()
    except EOFError:
        return default
    if not val:
        return default
    return val in ("y", "yes", "s", "si", "sí")


def pause():
    try:
        input("\n  Press RETURN when you are ready to continue... ")
    except EOFError:
        pass


# ----------------------------------------------------------------------
# 1. Python
# ----------------------------------------------------------------------

def check_python() -> bool:
    head("STEP 1 of 4 — Checking Python")

    v = sys.version_info
    print(f"  Found Python {v.major}.{v.minor}.{v.micro}")
    print(f"  Running on {platform.system()} {platform.machine()}")
    print()

    if v >= (3, 9):
        ok(f"Python {v.major}.{v.minor} works. Nothing to install.")
        return True

    fail(f"Python {v.major}.{v.minor} is too old — 3.9 or newer is needed.")
    print()

    if IS_MAC and shutil.which("brew"):
        print("  Homebrew is installed on this Mac, so I can do this for you.")
        if yes("  Install a newer Python now?"):
            print("\n  Running: brew install python@3.12")
            print("  (this takes a few minutes)\n")
            try:
                subprocess.run(["brew", "install", "python@3.12"], check=True)
                ok("Installed. Close this window and run setup again.")
            except subprocess.CalledProcessError:
                fail("Homebrew install failed. Opening the download page instead.")
                webbrowser.open(PYTHON_DOWNLOAD)
            return False

    print("  Opening the Python download page in your browser...")
    webbrowser.open(PYTHON_DOWNLOAD)
    print()
    if IS_WIN:
        warn("IMPORTANT for Windows: during the install, TICK the box that")
        warn('says "Add Python to PATH". Almost every problem on Windows')
        warn("comes from that box being left unchecked.")
    print()
    print("  Install it, then close this window and run setup again.")
    return False


# ----------------------------------------------------------------------
# 2. Dependencies
# ----------------------------------------------------------------------

def venv_python() -> Path:
    return HERE / ".venv" / ("Scripts" if IS_WIN else "bin") / (
        "python.exe" if IS_WIN else "python")


def install_deps() -> bool:
    head("STEP 2 of 4 — Installing what the bot needs")

    vp = venv_python()
    if vp.exists():
        ok("Environment already exists.")
    else:
        print("  Building a private environment for this bot...")
        print("  (this keeps it separate from the rest of your computer)\n")
        try:
            subprocess.run([sys.executable, "-m", "venv", str(HERE / ".venv")],
                           check=True)
        except subprocess.CalledProcessError:
            fail("Could not create the environment.")
            return False
        ok("Environment created.")

    print("\n  Installing packages (about a minute)...\n")
    try:
        subprocess.run([str(vp), "-m", "pip", "install", "--quiet",
                        "--upgrade", "pip"], check=True)
        subprocess.run([str(vp), "-m", "pip", "install", "--quiet", "-r",
                        str(HERE / "requirements.txt")], check=True)
    except subprocess.CalledProcessError:
        fail("Install failed. Check your internet connection and try again.")
        return False

    ok("All packages installed.")

    print("\n  Running self-tests...\n")
    all_ok = True
    for name in ("test_rules.py", "test_orderflow.py"):
        path = HERE / "tests" / name
        if not path.exists():
            continue
        try:
            r = subprocess.run([str(vp), str(path)], capture_output=True,
                               text=True, timeout=180)
            last = [l for l in r.stdout.strip().splitlines() if "passed" in l]
            if last:
                print(f"  {name:<22} {last[-1].strip()}")
            if r.returncode != 0:
                all_ok = False
        except Exception:
            all_ok = False
    if all_ok:
        ok("Everything checks out.")
    else:
        warn("Some tests failed — the bot may still run, but tell support.")

    return True


# ----------------------------------------------------------------------
# 3. Credentials
# ----------------------------------------------------------------------

def read_clipboard() -> str:
    """Read the clipboard, so the user never has to paste by hand."""
    try:
        if IS_MAC:
            r = subprocess.run(["pbpaste"], capture_output=True, text=True,
                               timeout=5)
            return r.stdout.strip()
        if IS_WIN:
            r = subprocess.run(
                ["powershell", "-NoProfile", "-Command", "Get-Clipboard"],
                capture_output=True, text=True, timeout=5)
            return r.stdout.strip()
        for tool in (["xclip", "-o", "-selection", "clipboard"], ["xsel", "-b"]):
            if shutil.which(tool[0]):
                r = subprocess.run(tool, capture_output=True, text=True,
                                   timeout=5)
                return r.stdout.strip()
    except Exception:
        pass
    return ""


def looks_like_key(s: str) -> bool:
    """A ProjectX key is a long token with no spaces."""
    s = s.strip()
    if len(s) < 20 or len(s) > 400:
        return False
    if " " in s or "\n" in s:
        return False
    return bool(re.fullmatch(r"[A-Za-z0-9\-_=+/.]+", s))


def get_credentials() -> tuple[str, str] | None:
    head("STEP 3 of 4 — Connecting your Topstep account")

    env = HERE / ".env"
    if env.exists():
        text = env.read_text()
        if "PUT_YOUR" not in text and "TOPSTEP_API_KEY=" in text:
            ok("Credentials already saved.")
            if not yes("  Replace them with different ones?", default=False):
                u = k = ""
                for line in text.splitlines():
                    if line.startswith("TOPSTEP_USERNAME="):
                        u = line.split("=", 1)[1].strip()
                    if line.startswith("TOPSTEP_API_KEY="):
                        k = line.split("=", 1)[1].strip()
                return (u, k) if u and k else None

    print("  You need an API key from TopstepX. If you do not have one yet,")
    print("  I will take you straight to the page.")
    print()
    print("  It costs $29/month, or $14.50 with the code:  topstep")
    print()

    if yes("  Open the TopstepX API settings page in your browser now?"):
        print(f"\n  Opening {TOPSTEPX_API_SETTINGS}")
        webbrowser.open(TOPSTEPX_API_SETTINGS)
        print()
        print("  On that page:")
        print("    1. Subscribe if you have not already")
        print("    2. Click 'Add API Key'")
        print("    3. COPY the key — it is usually shown only once")
        print()
        print("  Once you have copied it, come back here.")
        pause()

    # Try the clipboard first — this is the convenience that matters.
    clip = read_clipboard()
    key = ""
    if looks_like_key(clip):
        preview = f"{clip[:6]}...{clip[-4:]}"
        print(f"\n  I found something in your clipboard that looks like a key:")
        print(f"     {preview}  ({len(clip)} characters)")
        if yes("  Use this?"):
            key = clip
            ok("Got it from the clipboard.")

    if not key:
        print("\n  Paste your API key below.")
        print("  (On Mac use Command+V, on Windows right-click to paste.)")
        key = ask("API key").strip()

    if not key:
        warn("No key entered.")
        warn("The bot needs one to connect to your account.")
        warn("Run this setup again once you have it.")
        return None

    print()
    print("  Now your TopstepX USERNAME — this is the username you log in")
    print("  with, NOT your email address.")
    user = ask("TopstepX username").strip()

    if not user:
        warn("No username entered.")
        return None

    return user, key


# ----------------------------------------------------------------------
# 4. Validate against the real API
# ----------------------------------------------------------------------

def validate(user: str, key: str) -> bool:
    head("STEP 4 of 4 — Checking it works")

    vp = venv_python()
    script = f'''
import json, sys
try:
    import requests
except ImportError:
    print(json.dumps({{"error": "no_requests"}})); sys.exit()
try:
    r = requests.post("{API_BASE}/api/Auth/loginKey",
                      json={{"userName": {user!r}, "apiKey": {key!r}}},
                      timeout=25)
    d = r.json()
    if not d.get("success"):
        print(json.dumps({{"error": "auth", "detail": d.get("errorMessage")}}))
        sys.exit()
    tok = d["token"]
    a = requests.post("{API_BASE}/api/Account/search",
                      json={{"onlyActiveAccounts": True}},
                      headers={{"Authorization": "Bearer " + tok}}, timeout=25)
    print(json.dumps({{"ok": True, "accounts": a.json().get("accounts", [])}}))
except Exception as e:
    print(json.dumps({{"error": "network", "detail": str(e)}}))
'''
    print("  Contacting Topstep...\n")
    try:
        r = subprocess.run([str(vp), "-c", script], capture_output=True,
                           text=True, timeout=90)
        import json
        data = json.loads(r.stdout.strip() or "{}")
    except Exception as e:
        fail(f"Could not run the check: {e}")
        return False

    if data.get("error") == "auth":
        fail("Topstep rejected these credentials.")
        print()
        print("  The three usual causes, in order:")
        print("    1. You used your EMAIL instead of your TopstepX USERNAME")
        print("    2. The key got cut off when copying, or has a space")
        print("    3. Your API subscription is not active yet")
        if data.get("detail"):
            print(f"\n  Topstep said: {data['detail']}")
        return False

    if data.get("error") == "network":
        fail("Could not reach Topstep.")
        print()
        print("    - Are you on a VPN? Turn it off. Topstep blocks VPNs, and")
        print("      their rules prohibit trading through one.")
        print("    - Check your internet connection.")
        return False

    if not data.get("ok"):
        fail("Something unexpected happened. Tell support.")
        return False

    ok("Credentials work.")

    accounts = data.get("accounts", [])
    if not accounts:
        print()
        warn("No active trading accounts found on this login.")
        warn("You need an active Trading Combine to trade.")
        print()
        if yes("  Open Topstep to start one?"):
            webbrowser.open(TOPSTEP_SIGNUP)
        return True

    print()
    print(f"  Found {len(accounts)} active account(s):\n")
    for a in accounts:
        bal = a.get("balance")
        name = a.get("name") or a.get("id")
        line = f"    - {name}"
        if bal is not None:
            line += f"   balance ${float(bal):,.2f}"
        print(line)

    print()
    ok("You are ready to trade.")
    return True


# ----------------------------------------------------------------------

def save_env(user: str, key: str) -> None:
    env = HERE / ".env"
    env.write_text(f"TOPSTEP_USERNAME={user}\nTOPSTEP_API_KEY={key}\n")
    try:
        os.chmod(env, 0o600)
    except Exception:
        pass


def main() -> int:
    print()
    hr()
    print("   EVAL PASS BOT — Automatic Setup")
    hr()
    print()
    print("  This will get everything ready for you. It takes a few minutes.")
    print("  Your API key is saved ONLY on this computer and never sent")
    print("  anywhere except to Topstep itself.")

    if not check_python():
        return 1

    if not install_deps():
        return 1

    creds = get_credentials()

    if creds is None:
        head("Setup finished — partly")
        ok("The bot is installed and its tests pass.")
        warn("No credentials yet, so it cannot connect to your account.")
        print()
        print("  Run this setup again once you have your API key from")
        print("  TopstepX -> Settings -> API tab.")
        return 0

    user, key = creds
    save_env(user, key)

    if validate(user, key):
        head("Setup complete")
        print("  Next: double-click")
        print()
        print("      START THE BOT - double click me")
        print()
        print("  That runs in SAFE MODE. It connects to your real account,")
        print("  watches the market and writes down every trade it WOULD")
        print("  make — without sending a single order.")
        print()
        print("  Stay in safe mode for at least two weeks. The bot has NOT")
        print("  been proven profitable on real market data, and the logs")
        print("  are how you find out before risking an evaluation.")
        return 0

    head("Setup finished — credentials need fixing")
    print("  Everything is installed, but the login did not work.")
    print("  Run this setup again to re-enter them.")
    return 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n  Cancelled.")
        sys.exit(130)
