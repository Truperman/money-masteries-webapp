@echo off
REM Start the bot in SAFE MODE. No real orders are sent.
cd /d "%~dp0"
if not exist .venv ( echo Not set up yet. Double-click setup.bat first. & pause & exit /b 1 )
if not exist .env ( echo No credentials. Double-click setup.bat first. & pause & exit /b 1 )
.venv\Scripts\python run_live.py %*
pause
