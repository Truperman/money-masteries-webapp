#!/usr/bin/env python3
"""
Full evaluation run.

  python3 run_evaluation.py              # synthetic data + Monte Carlo
  python3 run_evaluation.py --csv mes.csv  # your real MES bars

Outputs a JSON blob and prints readable tables.
"""

from __future__ import annotations

import argparse
import json

import pandas as pd

from topstep.backtest import run_backtest
from topstep.data import SyntheticConfig, load_csv, synthetic
from topstep.montecarlo import (
    EdgeProfile,
    required_edge_grid,
    risk_sizing_sweep,
    run_monte_carlo,
)
from topstep.rules import COMBINE_50K, MES
from topstep.strategies import OpeningRangeBreakout, TrendPullback, VWAPReversion

pd.set_option("display.width", 200)


def backtest_section(df, label: str) -> list[dict]:
    print(f"\n{'=' * 78}\nSTRATEGY BACKTEST — {label}\n{'=' * 78}")
    rows = []
    for cls in (OpeningRangeBreakout, TrendPullback, VWAPReversion):
        strat = cls()
        res = run_backtest(
            df, strat, COMBINE_50K, MES, risk_per_trade=150.0, slippage_ticks=1.0
        )
        r = res.report
        rows.append(
            {
                "strategy": cls.name,
                "trades": r["n_trades"],
                "win_rate": round(r["win_rate"], 3),
                "avg_win": round(r["avg_win"], 2),
                "avg_loss": round(r["avg_loss"], 2),
                "expectancy": round(r["expectancy"], 2),
                "profit_factor": round(r["profit_factor"], 2),
                "net_profit": round(r["total_profit"], 2),
                "best_day": round(r["best_day"], 2),
                "consistency": round(r["consistency"], 3)
                if r["consistency"] != float("inf")
                else None,
                "state": r["state"],
                "passed": r["passed"],
                "zero_size_skips": res.skips["zero_size"],
            }
        )
    print(pd.DataFrame(rows).to_string(index=False))
    return rows


def montecarlo_section() -> dict:
    print(f"\n{'=' * 78}\nREQUIRED EDGE — probability of passing the $50K Combine")
    print("$150 risk/trade, 3 trades/day, 60-day limit, adaptive sizing")
    print("=" * 78)

    grid = required_edge_grid(n_runs=800)
    g = pd.DataFrame(grid)

    print("\nPASS RATE (%)   rows = win rate, cols = reward:risk")
    print((g.pivot(index="win_rate", columns="reward_risk", values="pass_rate") * 100).round(1).to_string())

    print("\nACCOUNT DEAD (%)  — breached the MLL or stalled out")
    print((g.pivot(index="win_rate", columns="reward_risk", values="dead_rate") * 100).round(1).to_string())

    print(f"\n{'=' * 78}\nPOSITION SIZE SWEEP — same edge, different dollars at risk")
    print("WR 42%, R 2.0, 3 trades/day")
    print("=" * 78)
    base = EdgeProfile(0.42, 2.0, 3.0, 150.0)
    sweep = risk_sizing_sweep(base, n_runs=1_000)
    s = pd.DataFrame(sweep)[
        ["risk_per_trade", "pass_rate", "mll_failure_rate", "stalled_rate",
         "ran_out_of_time", "median_days_to_pass"]
    ]
    print(s.to_string(index=False))

    print(f"\n{'=' * 78}\nSIZING METHOD — adaptive buffer clamp vs fixed size")
    print("=" * 78)
    cmp_rows = []
    for wr in (0.35, 0.40, 0.45):
        for adaptive in (True, False):
            p = EdgeProfile(wr, 2.0, 3.0, 150.0, name=f"WR{wr:.0%}")
            r = run_monte_carlo(p, n_runs=800, adaptive_sizing=adaptive, seed=5)
            d = r.summary()
            d["sizing"] = "adaptive" if adaptive else "fixed"
            cmp_rows.append(d)
    c = pd.DataFrame(cmp_rows)[
        ["name", "sizing", "pass_rate", "mll_failure_rate", "stalled_rate"]
    ]
    print(c.to_string(index=False))

    return {"grid": grid, "risk_sweep": sweep, "sizing_comparison": cmp_rows}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", help="path to real intraday MES bars")
    ap.add_argument("--days", type=int, default=250)
    ap.add_argument("--out", default="evaluation_results.json")
    args = ap.parse_args()

    if args.csv:
        df = load_csv(args.csv)
        label = f"REAL DATA — {args.csv}"
    else:
        df = synthetic(SyntheticConfig(n_days=args.days, seed=20260822))
        label = "SYNTHETIC DATA — engine test only, NOT evidence of edge"

    rng = df.groupby("session").agg(hi=("high", "max"), lo=("low", "min"))
    print(f"\nBars: {len(df):,}   Sessions: {df.session.nunique()}   "
          f"Median daily range: {(rng.hi - rng.lo).median():.1f} pts")

    bt = backtest_section(df, label)
    mc = montecarlo_section()

    with open(args.out, "w") as f:
        json.dump({"backtests": bt, "montecarlo": mc}, f, indent=2, default=str)
    print(f"\nWrote {args.out}")


if __name__ == "__main__":
    main()
