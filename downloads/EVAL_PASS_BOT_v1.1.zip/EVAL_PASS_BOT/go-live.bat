@echo off
REM Start the bot with REAL ORDERS. It will ask you to confirm.
cd /d "%~dp0"
if not exist .venv ( echo Not set up yet. Double-click setup.bat first. & pause & exit /b 1 )
.venv\Scripts\python run_live.py --live --risk 75
pause
