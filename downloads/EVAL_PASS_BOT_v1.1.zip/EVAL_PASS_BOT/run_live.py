#!/usr/bin/env python3
"""
Connect the bot to your Topstep account and run a trading session.

SAFETY MODEL
    Dry run is the default and cannot be turned off by accident. To send
    real orders you must pass --live AND type a confirmation phrase at the
    prompt. There is no config file setting that arms it silently.

    In dry run the bot does everything except send orders: authenticates,
    reads your real balance and positions, builds bars, evaluates the
    strategy, sizes positions against the real rule engine, and logs every
    order it WOULD have placed. Run it this way for at least two weeks.

WHAT IT DOES EACH MINUTE
    1. Pulls the latest 1-minute bars from the API.
    2. Marks any open position to market and checks the loss limit.
    3. Asks the strategy for a signal on the newly closed bar.
    4. Routes the signal through the rule engine, which sizes it and can
       refuse it outright.
    5. Sends the bracket order, or logs it in dry run.

USAGE
    python3 run_live.py                          # dry run, ORB strategy
    python3 run_live.py --strategy trend_pullback
    python3 run_live.py --risk 75                # dollars per trade
    python3 run_live.py --live                   # real orders, prompts first

STOPPING
    Ctrl-C flattens any open position and exits. Do not kill the terminal
    window without stopping cleanly — an orphaned position keeps running
    against your loss limit.

TOPSTEP RULES
    Trading must originate from your personal device. Do not run this on a
    VPS or through a VPN. Keep the machine awake for the session.
"""

from __future__ import annotations

import argparse
import logging
import os
import signal
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd

from topstep.evaluation import PassOptimizer, PassPolicy
from topstep.live import LiveConfig, LiveTrader, OrderRejected, ProjectXClient
from topstep.rules import COMBINE_50K, INSTRUMENTS, SPECS, trading_day
from topstep.strategies import STRATEGIES

log = logging.getLogger("run_live")
_running = True


def _stop(signum, frame):
    global _running
    _running = False
    print("\nshutting down — flattening any open position...")


def load_env(path: Path = Path(".env")) -> None:
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, _, v = line.partition("=")
            os.environ.setdefault(k.strip(), v.strip().strip("'\""))


def setup_logging(logfile: Path) -> None:
    logfile.parent.mkdir(parents=True, exist_ok=True)
    fmt = "%(asctime)s %(levelname)-8s %(name)s: %(message)s"
    logging.basicConfig(
        level=logging.INFO,
        format=fmt,
        handlers=[logging.StreamHandler(sys.stdout),
                  logging.FileHandler(logfile)],
    )


def fetch_recent_bars(client: ProjectXClient, contract_id: str,
                      minutes: int = 400) -> pd.DataFrame:
    """Pull the last N one-minute bars and shape them like the backtester's."""
    import requests
    from zoneinfo import ZoneInfo

    end = datetime.now(timezone.utc)
    start = end - timedelta(minutes=minutes + 60)

    resp = requests.post(
        f"{client.cfg.api_base}/api/History/retrieveBars",
        json={
            "contractId": contract_id,
            "live": False,
            "startTime": start.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "endTime": end.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "unit": 2, "unitNumber": 1,
            "limit": 20000, "includePartialBar": False,
        },
        headers=client._headers(),
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    if not data.get("success"):
        raise RuntimeError(f"retrieveBars failed: {data}")

    central = ZoneInfo("America/Chicago")
    rows = []
    for b in data.get("bars", []):
        ts = datetime.fromisoformat(b["t"].replace("Z", "+00:00"))
        rows.append({
            "timestamp": ts.astimezone(central).replace(tzinfo=None),
            "open": b["o"], "high": b["h"], "low": b["l"],
            "close": b["c"], "volume": b["v"],
        })

    if not rows:
        return pd.DataFrame()

    df = pd.DataFrame(rows).set_index("timestamp").sort_index()
    df["session"] = [trading_day(t.to_pydatetime()) for t in df.index]
    return df


def _friendly_startup_error(exc: Exception) -> None:
    """
    Translate the usual startup failures into something actionable.

    A stack trace is the correct output for a bug and the wrong output for
    a wrong password, and most people running this will hit the second.
    """
    text = str(exc).lower()
    print("\n" + "=" * 64)

    if "proxy" in text or "connection" in text or "timed out" in text \
            or "name resolution" in text or "max retries" in text:
        print("  Could not reach Topstep's servers.")
        print("=" * 64)
        print("\n  Things to check:")
        print("    - Are you connected to the internet?")
        print("    - Are you on a VPN? Turn it off. Topstep blocks VPNs,")
        print("      and their rules prohibit trading through one.")
        print("    - Is a firewall or corporate network blocking it?")

    elif "auth" in text or "401" in text or "403" in text \
            or "unauthorized" in text or "errorcode" in text:
        print("  Topstep rejected your login.")
        print("=" * 64)
        print("\n  Things to check:")
        print("    - Is TOPSTEP_USERNAME your TopstepX username exactly?")
        print("      It is the username, not your email address.")
        print("    - Was the API key copied completely, with no spaces?")
        print("    - Is your API subscription active?")
        print("      TopstepX -> Settings -> API tab")
        print("\n  To re-enter your credentials, delete the .env file and")
        print("  run setup again.")

    else:
        print("  Could not start.")
        print("=" * 64)
        print(f"\n  {exc}")

    print("\n" + "=" * 64 + "\n")


def confirm_live() -> bool:
    print("\n" + "=" * 68)
    print("  LIVE MODE — this will send REAL orders to your Topstep account.")
    print("  Orders executed via the API are final. No review, no reversal.")
    print("=" * 68)
    ans = input('\nType exactly: I understand this trades real money\n> ')
    return ans.strip() == "I understand this trades real money"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--strategy", default="opening_range_breakout",
                    choices=list(STRATEGIES.keys()))
    ap.add_argument("--account", default="50k", choices=list(SPECS.keys()))
    ap.add_argument("--symbol", default="MES", choices=list(INSTRUMENTS.keys()))
    ap.add_argument("--risk", type=float, default=75.0,
                    help="dollars risked per trade (75-100 recommended)")
    ap.add_argument("--live", action="store_true",
                    help="send real orders (prompts for confirmation)")
    ap.add_argument("--poll", type=float, default=20.0,
                    help="seconds between bar polls")
    ap.add_argument("--log", default="logs/session.log")
    args = ap.parse_args()

    signal.signal(signal.SIGINT, _stop)
    setup_logging(Path(args.log))
    load_env()

    username = os.environ.get("TOPSTEP_USERNAME", "")
    api_key = os.environ.get("TOPSTEP_API_KEY", "")
    account_id = os.environ.get("TOPSTEP_ACCOUNT_ID", "")

    if not username or not api_key:
        raise SystemExit(
            "Missing credentials. Create a .env file containing:\n"
            "  TOPSTEP_USERNAME=your_username\n"
            "  TOPSTEP_API_KEY=your_key\n"
        )

    dry_run = True
    if args.live:
        if not confirm_live():
            print("Not confirmed — staying in dry run.")
        else:
            dry_run = False

    spec = SPECS[args.account]
    instrument = INSTRUMENTS[args.symbol]

    cfg = LiveConfig(
        username=username,
        api_key=api_key,
        account_id=account_id,
        risk_per_trade=args.risk,
        dry_run=dry_run,
    )
    client = ProjectXClient(cfg)

    log.info("authenticating")
    try:
        client.authenticate()
    except Exception as exc:
        _friendly_startup_error(exc)
        raise SystemExit(1)

    # Resolve the account if it wasn't supplied.
    try:
        accounts = client.get_account().get("accounts", [])
    except Exception as exc:
        _friendly_startup_error(exc)
        raise SystemExit(1)
    if not accounts:
        raise SystemExit("No active accounts returned. Is your Combine active?")
    if not account_id:
        cfg.account_id = str(accounts[0]["id"])
        log.info("using account %s (%s)", cfg.account_id,
                 accounts[0].get("name", "unnamed"))
    for a in accounts:
        log.info("  account %s  balance %.2f", a.get("id"), a.get("balance", 0))

    # Resolve the front-month contract.
    import requests
    r = requests.post(
        f"{cfg.api_base}/api/Contract/search",
        json={"searchText": args.symbol, "live": False},
        headers=client._headers(), timeout=20,
    )
    r.raise_for_status()
    contracts = r.json().get("contracts", [])
    active = [c for c in contracts if c.get("activeContract")] or contracts
    if not active:
        raise SystemExit(f"no contract found for {args.symbol}")
    cfg.contract_id = active[0]["id"]
    log.info("contract %s (%s)", cfg.contract_id, active[0].get("description"))

    trader = LiveTrader(client, instrument, spec, cfg)
    trader.sync_from_broker()

    strategy = STRATEGIES[args.strategy]()
    optimizer = PassOptimizer(trader.account, PassPolicy())

    mode = "DRY RUN — no orders will be sent" if dry_run else "*** LIVE ***"
    log.info("=" * 60)
    log.info("%s", mode)
    log.info("strategy=%s  account=%s  symbol=%s  risk=$%.0f",
             args.strategy, spec.name, args.symbol, args.risk)
    log.info("balance=%.2f  MLL=%.2f  buffer=$%.0f",
             trader.account.balance, trader.account.mll,
             trader.account.balance - trader.account.mll)
    log.info("=" * 60)

    last_bar_ts = None
    current_session = None

    while _running:
        try:
            df = fetch_recent_bars(client, cfg.contract_id)
            if df.empty:
                time.sleep(args.poll)
                continue

            bar = df.iloc[-1]
            bar_ts = df.index[-1]
            session = df["session"].iloc[-1]

            if session != current_session:
                current_session = session
                strategy.start_session(session)
                optimizer.new_session()
                log.info("--- new session %s ---", session)

            # Heartbeat: mark to market, enforce the loss limit and flats.
            trader.heartbeat(unrealized=0.0)

            if bar_ts != last_bar_ts:
                last_bar_ts = bar_ts

                if not optimizer.should_trade(datetime.now()):
                    log.info("standing down: %s", optimizer.stop_reason)
                else:
                    sig = strategy.on_bar(bar_ts, bar, df)
                    if sig is not None:
                        log.info("SIGNAL %s @ %.2f stop=%.2f target=%.2f (%s)",
                                 "LONG" if sig.is_long else "SHORT",
                                 bar.close, sig.stop_price, sig.target_price,
                                 sig.reason)
                        try:
                            result = trader.submit(sig, float(bar.close))
                            log.info("order result: %s", result)
                        except OrderRejected as e:
                            log.info("rejected by rule engine: %s", e)

            time.sleep(args.poll)

        except KeyboardInterrupt:
            break
        except Exception as exc:            # never die on a transient error
            log.exception("loop error: %s", exc)
            time.sleep(min(args.poll * 3, 60))

    # Clean shutdown.
    try:
        log.info("flattening")
        client.flatten_all()
    except Exception as exc:
        log.error("flatten failed — CHECK YOUR PLATFORM MANUALLY: %s", exc)

    report = trader.account.evaluate()
    log.info("session over. balance=%.2f profit=%.2f state=%s",
             report["balance"], report["total_profit"], report["state"])


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
