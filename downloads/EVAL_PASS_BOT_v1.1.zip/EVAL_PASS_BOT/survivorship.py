#!/usr/bin/env python3
"""
Why you cannot learn edge from other bots' track records.

Run a large population of bots that provably have ZERO edge — coin flips at
1:1, expectancy exactly nil — through the real $50K Combine rule engine.
Some of them pass. Then look at what the survivors' track records look like.

If the survivors of a known-worthless strategy produce impressive-looking
statistics, then impressive-looking statistics are not evidence of edge, and
copying the parameters of whoever is at the top of a leaderboard copies
their luck rather than their method.

    python3 survivorship.py
"""

from __future__ import annotations

from datetime import datetime, timedelta

import numpy as np

from topstep.rules import COMBINE_50K, AccountState, TopstepAccount


def run_one(rng, win_rate=0.50, reward_risk=1.0, risk=150.0,
            trades_per_day=3.0, max_days=250):
    """One Combine attempt. Returns outcome plus the realized trade record."""
    account = TopstepAccount(COMBINE_50K)
    day = datetime(2026, 1, 5, 9, 0)
    wins = losses = 0

    for d in range(max_days):
        while day.weekday() >= 5:
            day += timedelta(days=1)
        ts = day.replace(hour=9, minute=0)

        for _ in range(int(rng.poisson(trades_per_day))):
            if not account.can_trade(ts):
                break
            room = account.balance - account.mll
            if room <= 0:
                return "dead", wins, losses, account.total_profit
            r = min(risk, room / 2.0)
            if r < risk * 0.25:
                return "dead", wins, losses, account.total_profit

            won = rng.random() < win_rate
            pnl = r * reward_risk if won else -r
            if account.mark(ts, pnl) is not None:
                return "dead", wins, losses, account.total_profit
            account.on_fill(ts, pnl)
            wins += won
            losses += not won
            if account.state is AccountState.FAILED_MLL:
                return "dead", wins, losses, account.total_profit
            ts += timedelta(minutes=20)

        account.end_of_day(day.replace(hour=15, minute=10))
        day += timedelta(days=1)
        account.current_day = None
        account.day_pnl = 0.0
        if account.state is AccountState.LOCKED_OUT_DAILY:
            account.state = AccountState.ACTIVE

        if account.evaluate()["passed"]:
            return "passed", wins, losses, account.total_profit

    return "unfinished", wins, losses, account.total_profit


def main(n_bots=3000, seed=1234):
    rng = np.random.default_rng(seed)
    print(f"Running {n_bots:,} bots with ZERO edge (50% win rate, 1:1 payoff).")
    print("True expectancy per trade: $0.00. None of these has any skill.\n")

    survivors, dead, unfinished = [], 0, 0
    for _ in range(n_bots):
        outcome, w, l, profit = run_one(rng)
        if outcome == "passed":
            n = w + l
            survivors.append({
                "win_rate": w / n if n else 0.0,
                "trades": n,
                "profit": profit,
            })
        elif outcome == "dead":
            dead += 1
        else:
            unfinished += 1

    n_s = len(survivors)
    print(f"  passed      {n_s:>6,}  ({n_s / n_bots:.1%})")
    print(f"  blew up     {dead:>6,}  ({dead / n_bots:.1%})")
    print(f"  unfinished  {unfinished:>6,}  ({unfinished / n_bots:.1%})")

    if not survivors:
        print("\nNo survivors.")
        return

    wr = np.array([s["win_rate"] for s in survivors])
    tr = np.array([s["trades"] for s in survivors])
    pf = np.array([s["profit"] for s in survivors])

    print(f"\nNow look only at the {n_s:,} that passed — the ones whose")
    print("track records you would find on a leaderboard:\n")
    print(f"  median win rate      {np.median(wr):.1%}")
    print(f"  mean win rate        {wr.mean():.1%}")
    print(f"  90th pct win rate    {np.percentile(wr, 90):.1%}")
    print(f"  best win rate        {wr.max():.1%}")
    print(f"  median trades taken  {int(np.median(tr))}")
    print(f"  median net profit    ${np.median(pf):,.0f}")

    strong = (wr >= 0.55).sum()
    print(f"\n  {strong:,} of them ({strong / n_s:.0%}) show a win rate at or above 55%.")
    print("  Every single one is a coin flip. The apparent edge is selection,")
    print("  not skill — and no amount of studying their parameters recovers")
    print("  an edge that was never there.")


if __name__ == "__main__":
    main()
