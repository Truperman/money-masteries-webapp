"""
Unit tests proving the rule engine matches Topstep's documented behaviour.

These are the tests that matter. If the engine is wrong, every backtest
result built on it is fiction.
"""

import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from topstep.rules import (  # noqa: E402
    COMBINE_50K,
    MES,
    AccountState,
    TopstepAccount,
    size_position,
    trading_day,
)


def test_initial_state():
    a = TopstepAccount(COMBINE_50K)
    assert a.balance == 50_000
    assert a.mll == 48_000, "MLL starts $2,000 below a $50K account"
    assert a.spec.target_balance == 53_000
    assert a.spec.max_best_day == 1_500


def test_mll_trails_on_eod_balance():
    """Topstep's own example: balance to $50,500 -> MLL to $48,500."""
    a = TopstepAccount(COMBINE_50K)
    a.on_fill(datetime(2026, 3, 2, 9, 0), 500)
    a.end_of_day(datetime(2026, 3, 2, 15, 10))
    assert a.balance == 50_500
    assert a.mll == 48_500


def test_mll_never_moves_down():
    """Give back the gains — the MLL stays where it climbed to."""
    a = TopstepAccount(COMBINE_50K)
    a.on_fill(datetime(2026, 3, 2, 9, 0), 500)
    a.end_of_day(datetime(2026, 3, 2, 15, 10))
    assert a.mll == 48_500

    a.on_fill(datetime(2026, 3, 3, 9, 0), -500)
    a.end_of_day(datetime(2026, 3, 3, 15, 10))
    assert a.balance == 50_000
    assert a.mll == 48_500, "MLL is a ratchet, it only goes up"


def test_mll_locks_at_starting_balance():
    """Once the MLL reaches $50,000 it locks and stops trailing forever."""
    a = TopstepAccount(COMBINE_50K)
    a.on_fill(datetime(2026, 3, 2, 9, 0), 2_500)
    a.end_of_day(datetime(2026, 3, 2, 15, 10))
    assert a.mll == 50_000, "capped at starting balance, not 50,500"

    a.on_fill(datetime(2026, 3, 3, 9, 0), 3_000)
    a.end_of_day(datetime(2026, 3, 3, 15, 10))
    assert a.balance == 55_500
    assert a.mll == 50_000, "locked permanently"


def test_unrealized_loss_can_breach_mll():
    """
    The critical rule. An open position that never gets closed can still
    fail the account, because the MLL is monitored against unrealized P&L.
    """
    a = TopstepAccount(COMBINE_50K)
    v = a.mark(datetime(2026, 3, 2, 10, 0), unrealized=-1_900)
    assert v is None
    assert a.state is AccountState.ACTIVE

    v = a.mark(datetime(2026, 3, 2, 10, 1), unrealized=-2_000)
    assert v is not None
    assert v.rule == "max_loss_limit"
    assert a.state is AccountState.FAILED_MLL
    assert not a.can_trade(datetime(2026, 3, 2, 10, 2))


def test_daily_loss_limit_locks_out_for_the_session():
    a = TopstepAccount(COMBINE_50K)
    ts = datetime(2026, 3, 2, 10, 0)
    a.on_fill(ts, -600)
    assert a.can_trade(ts)

    v = a.on_fill(datetime(2026, 3, 2, 11, 0), -400)
    assert v is not None and v.rule == "daily_loss_limit"
    assert a.state is AccountState.LOCKED_OUT_DAILY
    assert not a.can_trade(datetime(2026, 3, 2, 12, 0))
    assert a.must_flatten(datetime(2026, 3, 2, 12, 0))


def test_lockout_clears_next_session():
    a = TopstepAccount(COMBINE_50K)
    a.on_fill(datetime(2026, 3, 2, 10, 0), -1_000)
    assert a.state is AccountState.LOCKED_OUT_DAILY
    # Next trading day.
    assert a.can_trade(datetime(2026, 3, 3, 9, 0))
    assert a.state is AccountState.ACTIVE


def test_trading_day_rolls_at_5pm_ct():
    """Anything at or after 17:00 CT belongs to the next session."""
    assert trading_day(datetime(2026, 3, 2, 16, 59)) == datetime(2026, 3, 2).date()
    assert trading_day(datetime(2026, 3, 2, 17, 0)) == datetime(2026, 3, 3).date()
    assert trading_day(datetime(2026, 3, 2, 21, 30)) == datetime(2026, 3, 3).date()
    assert trading_day(datetime(2026, 3, 3, 8, 30)) == datetime(2026, 3, 3).date()


def test_consistency_math():
    """Best day / total profit, must be <= 50% in the Combine."""
    a = TopstepAccount(COMBINE_50K)
    a.on_fill(datetime(2026, 3, 2, 9, 0), 1_400)
    a.end_of_day(datetime(2026, 3, 2, 15, 10))
    a.on_fill(datetime(2026, 3, 3, 9, 0), 900)
    a.end_of_day(datetime(2026, 3, 3, 15, 10))
    a.on_fill(datetime(2026, 3, 4, 9, 0), 800)
    a.end_of_day(datetime(2026, 3, 4, 15, 10))

    assert a.total_profit == 3_100
    assert a.best_day == 1_400
    assert abs(a.consistency - 1_400 / 3_100) < 1e-9
    assert a.consistency <= 0.50

    report = a.evaluate()
    assert report["passed"] is True


def test_consistency_failure_blocks_pass():
    """Hit the target but with one huge day — objective not met."""
    a = TopstepAccount(COMBINE_50K)
    a.on_fill(datetime(2026, 3, 2, 9, 0), 2_500)
    a.end_of_day(datetime(2026, 3, 2, 15, 10))
    a.on_fill(datetime(2026, 3, 3, 9, 0), 600)
    a.end_of_day(datetime(2026, 3, 3, 15, 10))

    assert a.total_profit == 3_100
    assert a.consistency > 0.50
    report = a.evaluate()
    assert report["passed"] is False
    assert report["checks"]["profit_target"] is True
    assert report["checks"]["consistency"] is False


def test_losing_day_does_not_reset_best_day():
    """Topstep: 'Losses do not reset your best day.'"""
    a = TopstepAccount(COMBINE_50K)
    a.on_fill(datetime(2026, 3, 2, 9, 0), 1_600)
    a.end_of_day(datetime(2026, 3, 2, 15, 10))
    a.on_fill(datetime(2026, 3, 3, 9, 0), -400)
    a.end_of_day(datetime(2026, 3, 3, 15, 10))
    assert a.best_day == 1_600, "the losing day does not erase the best day"


def test_min_trading_days_enforced():
    a = TopstepAccount(COMBINE_50K)
    a.on_fill(datetime(2026, 3, 2, 9, 0), 3_000)
    a.end_of_day(datetime(2026, 3, 2, 15, 10))
    report = a.evaluate()
    assert report["checks"]["min_trading_days"] is False
    assert report["passed"] is False


def test_position_size_respects_contract_cap():
    a = TopstepAccount(COMBINE_50K)
    # Tiny stop + big risk budget would want a huge size; cap is 50 micros.
    n = size_position(a, MES, stop_ticks=1, risk_per_trade=10_000)
    assert n == 50


def test_position_size_shrinks_as_mll_approaches():
    """
    The self-protecting clamp: less buffer, smaller size.

    With a healthy balance the risk budget binds. As the balance decays
    toward the MLL, the buffer clamp takes over and size falls monotonically
    to zero — which is what stops a losing streak from ending the account.
    """
    a = TopstepAccount(COMBINE_50K)
    full = size_position(a, MES, stop_ticks=20, risk_per_trade=200)
    assert full == 8  # 200 / (20 ticks * $1.25)

    sizes = []
    for bal in (50_000, 48_600, 48_400, 48_200, 48_100, 48_000):
        a.balance = bal
        n = size_position(a, MES, stop_ticks=20, risk_per_trade=200)
        sizes.append(n)
        # Never risk more than half the remaining buffer.
        assert n * 20 * MES.tick_value <= (bal - 48_000) / 2 + 1e-9

    assert sizes == sorted(sizes, reverse=True), "size must decay monotonically"
    assert sizes[0] == full
    assert sizes[-1] == 0, "no buffer left, no trade"
    # At $48,200 only $200 of buffer remains: half of that is $100, which
    # buys 4 micros at $25 of risk each — half the unconstrained size.
    assert sizes[3] == 4 < full, "clamp binds before the buffer is gone"


def test_position_size_respects_remaining_daily_room():
    a = TopstepAccount(COMBINE_50K)
    a.on_fill(datetime(2026, 3, 2, 9, 0), -900)  # $100 of daily room left
    n = size_position(a, MES, stop_ticks=20, risk_per_trade=200)
    assert n * 20 * MES.tick_value <= 100 / 1.5 + 1e-9


def test_mes_pnl_and_commissions():
    """8 ticks up on 4 MES = 8 * 1.25 * 4 = $40 gross, minus commissions."""
    pnl = MES.pnl(entry=5000.00, exit_=5002.00, contracts=4, is_long=True)
    assert abs(pnl - (40 - 2 * 0.37 * 4)) < 1e-9

    # Same move against a short.
    pnl_short = MES.pnl(entry=5000.00, exit_=5002.00, contracts=4, is_long=False)
    assert abs(pnl_short - (-40 - 2 * 0.37 * 4)) < 1e-9


if __name__ == "__main__":
    import traceback

    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    for t in tests:
        try:
            t()
            print(f"  PASS  {t.__name__}")
        except Exception:
            failed += 1
            print(f"  FAIL  {t.__name__}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
