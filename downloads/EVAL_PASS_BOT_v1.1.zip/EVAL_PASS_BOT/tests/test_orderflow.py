"""
Tests for the order flow metrics.

OFI in particular is easy to implement subtly wrong — the indicator
conditions use >= and <= on BOTH branches, which means a price level that
is unchanged contributes both terms. Getting that backwards inverts the
signal, and an inverted signal backtests as a reliable loser.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from topstep.orderflow import (  # noqa: E402
    BookSnapshot,
    FlowGate,
    OrderFlowState,
    TradeEvent,
    classify_lee_ready,
    ofi_increment,
)


def book(ts, bp, bs, ap, asz):
    return BookSnapshot(ts, bp, bs, ap, asz)


def test_book_imbalance():
    b = book(0, 5000.00, 100, 5000.25, 100)
    assert b.imbalance == 0.0

    b = book(0, 5000.00, 150, 5000.25, 50)
    assert b.imbalance == 0.5, "bid-heavy is positive"

    b = book(0, 5000.00, 50, 5000.25, 150)
    assert b.imbalance == -0.5

    b = book(0, 5000.00, 0, 5000.25, 0)
    assert b.imbalance == 0.0, "empty book must not divide by zero"


def test_book_mid_and_spread():
    b = book(0, 5000.00, 10, 5000.25, 10)
    assert b.mid == 5000.125
    assert abs(b.spread - 0.25) < 1e-9


def test_ofi_bid_size_increase_is_positive():
    """More size resting on the bid at the same price = buying pressure."""
    prev = book(0, 5000.00, 100, 5000.25, 100)
    curr = book(1, 5000.00, 200, 5000.25, 100)
    # bid price unchanged: +q_bid_n - q_bid_n-1 = 200 - 100 = +100
    # ask price unchanged: -q_ask_n + q_ask_n-1 = -100 + 100 = 0
    assert ofi_increment(prev, curr) == 100.0


def test_ofi_ask_size_increase_is_negative():
    prev = book(0, 5000.00, 100, 5000.25, 100)
    curr = book(1, 5000.00, 100, 5000.25, 200)
    # bid contributes 0, ask: -200 + 100 = -100
    assert ofi_increment(prev, curr) == -100.0


def test_ofi_bid_price_up_is_positive():
    """The bid stepping up is aggressive buying regardless of size."""
    prev = book(0, 5000.00, 100, 5000.25, 100)
    curr = book(1, 5000.25, 80, 5000.50, 100)
    # bid up: +80 only (no -prev term since curr.bid > prev.bid)
    # ask up: +100 only
    assert ofi_increment(prev, curr) == 180.0


def test_ofi_bid_price_down_is_negative():
    prev = book(0, 5000.25, 100, 5000.50, 100)
    curr = book(1, 5000.00, 80, 5000.25, 100)
    # bid down: -100 ; ask down: -100
    assert ofi_increment(prev, curr) == -200.0


def test_ofi_sign_is_directionally_correct():
    """
    The property that matters: a book that is steadily strengthening on the
    bid must produce positive cumulative OFI, and vice versa.
    """
    flow = OrderFlowState(window_seconds=100)
    for i in range(20):
        flow.on_book(book(i, 5000.00, 100 + i * 10, 5000.25, 100))
    assert flow.ofi > 0, "growing bid queue must read as positive pressure"

    flow2 = OrderFlowState(window_seconds=100)
    for i in range(20):
        flow2.on_book(book(i, 5000.00, 100, 5000.25, 100 + i * 10))
    assert flow2.ofi < 0


def test_lee_ready_classification():
    b = book(0, 5000.00, 100, 5000.25, 100)
    assert classify_lee_ready(5000.25, b) is True, "at ask = buyer initiated"
    assert classify_lee_ready(5000.50, b) is True
    assert classify_lee_ready(5000.00, b) is False, "at bid = seller initiated"
    assert classify_lee_ready(4999.75, b) is False
    assert classify_lee_ready(5000.125, b) is None, "exact mid is ambiguous"


def test_delta_uses_aggressor_side():
    flow = OrderFlowState(window_seconds=100)
    flow.on_book(book(0, 5000.00, 100, 5000.25, 100))
    flow.on_trade(TradeEvent(1, 5000.25, 10, True))
    flow.on_trade(TradeEvent(2, 5000.00, 4, False))
    assert flow.delta == 6.0
    assert flow.volume == 14.0
    assert abs(flow.delta_ratio - 6 / 14) < 1e-9


def test_unknown_aggressor_gets_classified_from_book():
    flow = OrderFlowState(window_seconds=100)
    flow.on_book(book(0, 5000.00, 100, 5000.25, 100))
    flow.on_trade(TradeEvent(1, 5000.25, 10, None))   # at ask -> buy
    assert flow.delta == 10.0


def test_window_expires_old_events():
    flow = OrderFlowState(window_seconds=10)
    for i in range(30):
        flow.on_book(book(i, 5000.00, 100, 5000.25, 100))
        flow.on_trade(TradeEvent(i, 5000.25, 1, True))
    # Only the last ~10 seconds should remain in the window.
    assert flow.volume <= 11, f"window not expiring, volume={flow.volume}"
    # Cumulative delta is session-long and must NOT expire.
    assert flow.cumulative_delta == 30.0


def test_not_ready_without_enough_data():
    flow = OrderFlowState()
    assert not flow.ready
    gate = FlowGate()
    assert gate.check(flow, is_long=True) is False
    assert "insufficient" in gate.reasons[0]


def test_gate_confirms_aligned_flow():
    """Strong buying pressure should confirm a long and reject a short."""
    flow = OrderFlowState(window_seconds=100)
    for i in range(30):
        flow.on_book(book(i, 5000.00, 100 + i * 20, 5000.25, 100))
        flow.on_trade(TradeEvent(i, 5000.25, 5, True))

    assert flow.ready
    gate = FlowGate()
    assert gate.check(flow, is_long=True) is True, gate.reasons
    assert gate.check(flow, is_long=False) is False


def test_gate_rejects_opposing_flow():
    flow = OrderFlowState(window_seconds=100)
    for i in range(30):
        flow.on_book(book(i, 5000.00, 100, 5000.25, 100 + i * 20))
        flow.on_trade(TradeEvent(i, 5000.00, 5, False))

    gate = FlowGate()
    assert gate.check(flow, is_long=True) is False
    assert gate.check(flow, is_long=False) is True


def test_gate_can_only_decline_never_invent():
    """
    Structural guarantee: the gate returns a bool for a direction the
    strategy chose. It has no way to express 'go the other way'.
    """
    import inspect

    src = inspect.getsource(FlowGate.check)
    assert "return" in src
    sig = inspect.signature(FlowGate.check)
    assert "is_long" in sig.parameters, "direction is an input, not an output"


def test_absorption_no_division_by_zero():
    flow = OrderFlowState(window_seconds=100)
    for i in range(20):
        flow.on_book(book(i, 5000.00, 100, 5000.25, 100))
        flow.on_trade(TradeEvent(i, 5000.00, 50, False))
    a = flow.absorption(tick_size=0.25)
    assert a > 0 and a == flow.volume, "flat price floors the divisor at 1"


if __name__ == "__main__":
    import traceback

    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    for t in tests:
        try:
            t()
            print(f"  PASS  {t.__name__}")
        except Exception:
            failed += 1
            print(f"  FAIL  {t.__name__}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
