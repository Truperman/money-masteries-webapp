@echo off
REM Download a year of MES price history.
cd /d "%~dp0"
.venv\Scripts\python fetch_data.py --days 365 --out mes_1min.csv
pause
