#!/usr/bin/env python3
"""
Record live order flow from the TopstepX market hub to disk.

WHY THIS EXISTS
    The ProjectX history endpoint serves OHLCV bars only. There is no
    historical depth-of-market and no historical trade-aggressor data. That
    means you CANNOT backtest an order flow strategy from Topstep's API —
    the inputs simply are not served.

    Two ways to get the data:

      1. Buy it. Databento's GLBX.MDP3 dataset has MES with MBO, MBP-1,
         TBBO and Trades schemas going back to 2019-04-14. This is the
         correct answer if you want to test an idea this month.

      2. Record it yourself, starting now. Free, but you begin with zero
         history and accumulate roughly one session per day. This script
         does that. Every day you do not run it is a day of data you will
         never get back.

    Run both if you can: buy a year to develop against, record live to
    verify your capture pipeline agrees with the vendor's.

USAGE
    pip install signalrcore requests
    python3 record_flow.py --symbol MES --out data/flow

    Writes one gzipped JSONL file per session per stream:
        data/flow/MES_2026-08-22_trades.jsonl.gz
        data/flow/MES_2026-08-22_depth.jsonl.gz
        data/flow/MES_2026-08-22_quotes.jsonl.gz

    Stop with Ctrl-C. Files are flushed continuously, so a kill mid-session
    costs you at most the last few events.

NOTE ON CLOCKS
    Timestamps are recorded as received, plus the venue timestamp when the
    feed supplies one. Your local clock is not synchronised to the exchange;
    for anything latency-sensitive, trust the venue field. For minute-scale
    confirmation logic the difference is immaterial.
"""

from __future__ import annotations

import argparse
import gzip
import json
import os
import signal
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

API_BASE = os.environ.get("PROJECTX_BASE_URL", "https://api.topstepx.com")
USER_HUB = "https://rtc.topstepx.com/hubs/user"
MARKET_HUB = "https://rtc.topstepx.com/hubs/market"

_running = True


def _stop(signum, frame):
    global _running
    _running = False
    print("\nstopping — flushing files...")


def load_env(path: Path = Path(".env")) -> None:
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, _, v = line.partition("=")
            os.environ.setdefault(k.strip(), v.strip().strip("'\""))


def authenticate(username: str, api_key: str) -> str:
    import requests

    r = requests.post(
        f"{API_BASE}/api/Auth/loginKey",
        json={"userName": username, "apiKey": api_key},
        timeout=20,
    )
    r.raise_for_status()
    d = r.json()
    if not d.get("success"):
        raise SystemExit(f"auth failed: {d.get('errorMessage')}")
    return d["token"]


def find_contract(token: str, symbol: str) -> str:
    import requests

    r = requests.post(
        f"{API_BASE}/api/Contract/search",
        json={"searchText": symbol, "live": False},
        headers={"Authorization": f"Bearer {token}"},
        timeout=20,
    )
    r.raise_for_status()
    contracts = r.json().get("contracts", [])
    if not contracts:
        raise SystemExit(f"no contract found for {symbol}")
    active = [c for c in contracts if c.get("activeContract")] or contracts
    c = active[0]
    print(f"  contract: {c['id']}  ({c.get('description')})")
    return c["id"]


class StreamWriter:
    """One gzipped JSONL file per stream, flushed as it goes."""

    def __init__(self, out_dir: Path, symbol: str, stream: str):
        out_dir.mkdir(parents=True, exist_ok=True)
        day = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        self.path = out_dir / f"{symbol}_{day}_{stream}.jsonl.gz"
        self.fh = gzip.open(self.path, "at", encoding="utf-8")
        self.count = 0

    def write(self, payload) -> None:
        self.fh.write(
            json.dumps({"recv_ts": time.time(), "data": payload},
                       separators=(",", ":"), default=str) + "\n"
        )
        self.count += 1
        if self.count % 200 == 0:
            self.fh.flush()

    def close(self) -> None:
        self.fh.flush()
        self.fh.close()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbol", default="MES")
    ap.add_argument("--out", default="data/flow")
    ap.add_argument("--quiet", action="store_true",
                    help="suppress the live metrics line")
    args = ap.parse_args()

    signal.signal(signal.SIGINT, _stop)

    load_env()
    user = os.environ.get("TOPSTEP_USERNAME", "")
    key = os.environ.get("TOPSTEP_API_KEY", "")
    if not user or not key:
        raise SystemExit(
            "Missing credentials. Create .env with TOPSTEP_USERNAME and "
            "TOPSTEP_API_KEY (see .env.example)."
        )

    try:
        from signalrcore.hub_connection_builder import HubConnectionBuilder
    except ImportError:
        raise SystemExit("pip install signalrcore")

    print("authenticating...")
    token = authenticate(user, key)
    contract_id = find_contract(token, args.symbol)

    out_dir = Path(args.out)
    writers = {
        s: StreamWriter(out_dir, args.symbol, s)
        for s in ("trades", "depth", "quotes")
    }
    print(f"writing to {out_dir}/")

    # Live metrics, so you can see the flow is sane while recording.
    from topstep.orderflow import BookSnapshot, OrderFlowState, TradeEvent

    flow = OrderFlowState(window_seconds=60.0)
    last_print = 0.0

    def on_quote(msg):
        nonlocal last_print
        writers["quotes"].write(msg)
        try:
            d = msg[1] if isinstance(msg, list) and len(msg) > 1 else msg
            book = BookSnapshot(
                timestamp=time.time(),
                bid_price=float(d["bestBid"]),
                bid_size=float(d.get("bestBidSize", 0) or 0),
                ask_price=float(d["bestAsk"]),
                ask_size=float(d.get("bestAskSize", 0) or 0),
            )
            flow.on_book(book)
        except (KeyError, TypeError, ValueError):
            pass  # schema drift should never kill the recorder

        now = time.time()
        if not args.quiet and now - last_print > 5.0:
            last_print = now
            s = flow.snapshot()
            print(
                f"\r  OFI {s['normalized_ofi']:+6.2f} | "
                f"delta {s['delta']:+8.0f} | "
                f"book {s['book_imbalance']:+.2f} | "
                f"vol {s['volume']:>7.0f} | "
                f"events {sum(w.count for w in writers.values()):>7,}",
                end="", flush=True,
            )

    def on_trade(msg):
        writers["trades"].write(msg)
        try:
            d = msg[1] if isinstance(msg, list) and len(msg) > 1 else msg
            entries = d if isinstance(d, list) else [d]
            for e in entries:
                # CME supplies an aggressor flag; use it rather than
                # inferring, which is strictly more accurate.
                side = e.get("type")
                is_buy = None if side is None else (int(side) == 0)
                flow.on_trade(TradeEvent(
                    timestamp=time.time(),
                    price=float(e["price"]),
                    size=float(e["volume"]),
                    is_buy_aggressor=is_buy,
                ))
        except (KeyError, TypeError, ValueError):
            pass

    def on_depth(msg):
        writers["depth"].write(msg)

    hub = (
        HubConnectionBuilder()
        .with_url(f"{MARKET_HUB}?access_token={token}",
                  options={"skip_negotiation": True})
        .with_automatic_reconnect(
            {"type": "raw", "keep_alive_interval": 10, "reconnect_interval": 5}
        )
        .build()
    )

    hub.on("GatewayQuote", on_quote)
    hub.on("GatewayTrade", on_trade)
    hub.on("GatewayDepth", on_depth)
    hub.on_open(lambda: (
        print("connected — subscribing"),
        hub.send("SubscribeContractQuotes", [contract_id]),
        hub.send("SubscribeContractTrades", [contract_id]),
        hub.send("SubscribeContractMarketDepth", [contract_id]),
    ))
    hub.on_close(lambda: print("\ndisconnected"))

    hub.start()

    try:
        while _running:
            time.sleep(0.5)
    finally:
        try:
            hub.stop()
        except Exception:
            pass
        total = 0
        for name, w in writers.items():
            total += w.count
            w.close()
            print(f"  {name:>7}: {w.count:>8,} events -> {w.path.name}")
        print(f"  total  : {total:,} events")
        if total == 0:
            print(
                "\nNo events captured. Check that the market is open and "
                "that your API subscription includes market data."
            )


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
