# Setup and operating notes

`START_HERE.txt` covers the basics. This is the detail.

## Requirements

Python **3.9 or newer**. Check with `python3 --version` (Mac) or
`python --version` (Windows).

On Windows, install from python.org and **tick "Add Python to PATH"** during
install. Almost every Windows problem with this project traces back to that
checkbox.

## Install

**Mac / Linux**

```bash
cd ~/Desktop/topstep_bot
bash setup.sh
```

**Windows** — double-click `setup.bat`

Setup asks for your username and API key and writes them to a `.env` file
for you. There is nothing to edit by hand.

To change credentials later, delete `.env` and run setup again.

## Running

| | Mac / Linux | Windows |
|---|---|---|
| Safe mode (no real orders) | `bash go.sh` | double-click `go.bat` |
| Real orders | `bash go.sh --live --risk 75` | double-click `go-live.bat` |
| Download price history | `bash getdata.sh` | double-click `getdata.bat` |

Options you can add on Mac/Linux:

```bash
bash go.sh --symbol MNQ                      # trade Micro Nasdaq instead
bash go.sh --strategy trend_pullback         # different strategy
bash go.sh --risk 50                         # dollars risked per trade
bash go.sh --account 100k                    # if you have a $100K Combine
```

Strategies available: `opening_range_breakout`, `trend_pullback`,
`vwap_reversion`. Instruments: `MES`, `MNQ`, `ES`, `NQ`.

## Stopping

**Ctrl+C** in the window. This closes any open position before exiting.

Do not just close the window. That orphans an open trade with nothing
watching it, and the drawdown limit does not care that your bot is gone.

## What safe mode actually does

It is not a simulation of your account — it is your real account, read-only.
It authenticates, reads your true balance and open positions, builds bars
from live market data, runs the strategy, and sizes every would-be position
against the real rule engine. The only thing it does not do is transmit the
order.

Everything lands in `logs/session.log`. After two weeks you will have a real
record of what the bot wanted to do, which is the cheapest possible way to
find out whether it is worth trusting.

## Topstep rules that affect how you run this

- **Your own computer only.** No VPS, no VPN, no remote servers. Topstep's
  API documentation states that all trading activity must originate from
  your personal device, and violating it risks removal from the program.
- **Keep the machine awake** for the session. A sleeping Mac is a stopped
  bot, possibly with a position open.
- **No high-frequency trading**, and nothing designed to exploit the
  favourable fills of the simulated evaluation environment. The strategies
  here hold positions for minutes and are well inside the line.

## If more than one person runs this

Two accounts running the same bot on the same settings will place
near-identical trades seconds apart. Prop firms look for exactly that:

- TradeDay: "If multiple users are making the same trades, then all the
  accounts will be shut down, and the users suspended."
- MyFundedFutures prohibits traders copying one another's entries and
  exits, and bans shared devices, with permanent restriction as the penalty.

Copying between accounts **you personally own** is allowed at Topstep. The
same automation on **different people's** accounts is not the same thing.

If two of you are running it, use different settings. Different instrument
is the cleanest split:

```bash
# Person A
bash go.sh --symbol MES --strategy opening_range_breakout

# Person B
bash go.sh --symbol MNQ --strategy trend_pullback
```

Those accounts will never produce comparable fills.

## Credentials

Your API key can place and cancel real orders. Treat it like a password.

- Never email, message, or screenshot it.
- Each person generates their own in their own TopstepX settings.
- If you set this up on a second computer, generate a **separate key** for
  it, so a lost laptop means revoking one key rather than all of them.
- `.env` is excluded from git by `.gitignore` and never leaves your machine.

## Never run two instances against one account

Two copies running against the same account double every order. Your real
position becomes twice what the rule engine believes it is, which silently
disables the drawdown protection that is the whole point of this project.

One machine, one instance. If you switch computers, stop the first one and
confirm it flattened before starting the second.

## What this is, honestly

The rule engine and risk layer are thoroughly tested — 32 unit tests written
against Topstep's documented behaviour, covering the trailing drawdown, the
daily loss limit, the consistency objective and position sizing.

The three strategies are **not validated**. No one has demonstrated that any
of them has an edge on real market data. The framework will faithfully
execute a losing strategy.

Run it in safe mode. Read the logs. Decide for yourself.
